--
-- PostgreSQL database dump
--

\restrict GHr4FT6Q3Ov0iGZlUVgjFynHeFkLdjbP2mRXv6VdUCCxwilZ7P2Mqn2TyHqgLrH

-- Dumped from database version 17.10 (Debian 17.10-1.pgdg13+1)
-- Dumped by pg_dump version 17.10 (Debian 17.10-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: remnashop
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO remnashop;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: remnashop
--

COMMENT ON SCHEMA public IS '';


--
-- Name: broadcast_audience; Type: TYPE; Schema: public; Owner: remnashop
--

CREATE TYPE public.broadcast_audience AS ENUM (
    'ALL',
    'PLAN',
    'SUBSCRIBED',
    'UNSUBSCRIBED',
    'EXPIRED',
    'TRIAL'
);


ALTER TYPE public.broadcast_audience OWNER TO remnashop;

--
-- Name: broadcast_message_status; Type: TYPE; Schema: public; Owner: remnashop
--

CREATE TYPE public.broadcast_message_status AS ENUM (
    'SENT',
    'FAILED',
    'EDITED',
    'DELETED',
    'PENDING'
);


ALTER TYPE public.broadcast_message_status OWNER TO remnashop;

--
-- Name: broadcast_status; Type: TYPE; Schema: public; Owner: remnashop
--

CREATE TYPE public.broadcast_status AS ENUM (
    'PROCESSING',
    'COMPLETED',
    'CANCELED',
    'DELETED',
    'ERROR'
);


ALTER TYPE public.broadcast_status OWNER TO remnashop;

--
-- Name: currency; Type: TYPE; Schema: public; Owner: remnashop
--

CREATE TYPE public.currency AS ENUM (
    'USD',
    'XTR',
    'RUB'
);


ALTER TYPE public.currency OWNER TO remnashop;

--
-- Name: locale; Type: TYPE; Schema: public; Owner: remnashop
--

CREATE TYPE public.locale AS ENUM (
    'AR',
    'AZ',
    'BE',
    'CS',
    'DE',
    'EN',
    'ES',
    'FA',
    'FR',
    'HE',
    'HI',
    'ID',
    'IT',
    'JA',
    'KK',
    'KO',
    'MS',
    'NL',
    'PL',
    'PT',
    'RO',
    'RU',
    'SR',
    'TR',
    'UK',
    'UZ',
    'VI',
    'BG',
    'DA',
    'EL',
    'FI',
    'HU',
    'NO',
    'SV',
    'TG',
    'TH',
    'ZH'
);


ALTER TYPE public.locale OWNER TO remnashop;

--
-- Name: payment_gateway_type; Type: TYPE; Schema: public; Owner: remnashop
--

CREATE TYPE public.payment_gateway_type AS ENUM (
    'TELEGRAM_STARS',
    'YOOKASSA',
    'YOOMONEY',
    'CRYPTOMUS',
    'HELEKET',
    'CRYPTOPAY',
    'FREEKASSA',
    'MULENPAY',
    'PAYMASTER',
    'PLATEGA',
    'ROBOKASSA',
    'URLPAY',
    'WATA',
    'VALUTIX'
);


ALTER TYPE public.payment_gateway_type OWNER TO remnashop;

--
-- Name: plan_availability; Type: TYPE; Schema: public; Owner: remnashop
--

CREATE TYPE public.plan_availability AS ENUM (
    'ALL',
    'NEW',
    'EXISTING',
    'INVITED',
    'ALLOWED',
    'LINK'
);


ALTER TYPE public.plan_availability OWNER TO remnashop;

--
-- Name: plan_traffic_limit_strategy; Type: TYPE; Schema: public; Owner: remnashop
--

CREATE TYPE public.plan_traffic_limit_strategy AS ENUM (
    'NO_RESET',
    'DAY',
    'WEEK',
    'MONTH',
    'MONTH_ROLLING'
);


ALTER TYPE public.plan_traffic_limit_strategy OWNER TO remnashop;

--
-- Name: plan_type; Type: TYPE; Schema: public; Owner: remnashop
--

CREATE TYPE public.plan_type AS ENUM (
    'TRAFFIC',
    'DEVICES',
    'BOTH',
    'UNLIMITED'
);


ALTER TYPE public.plan_type OWNER TO remnashop;

--
-- Name: promocode_availability; Type: TYPE; Schema: public; Owner: remnashop
--

CREATE TYPE public.promocode_availability AS ENUM (
    'ALL',
    'NEW',
    'EXISTING',
    'INVITED'
);


ALTER TYPE public.promocode_availability OWNER TO remnashop;

--
-- Name: promocode_reward_type; Type: TYPE; Schema: public; Owner: remnashop
--

CREATE TYPE public.promocode_reward_type AS ENUM (
    'DURATION',
    'TRAFFIC',
    'DEVICES',
    'SUBSCRIPTION',
    'PERSONAL_DISCOUNT',
    'PURCHASE_DISCOUNT'
);


ALTER TYPE public.promocode_reward_type OWNER TO remnashop;

--
-- Name: purchase_type; Type: TYPE; Schema: public; Owner: remnashop
--

CREATE TYPE public.purchase_type AS ENUM (
    'NEW',
    'RENEW',
    'CHANGE'
);


ALTER TYPE public.purchase_type OWNER TO remnashop;

--
-- Name: referral_level; Type: TYPE; Schema: public; Owner: remnashop
--

CREATE TYPE public.referral_level AS ENUM (
    'FIRST',
    'SECOND'
);


ALTER TYPE public.referral_level OWNER TO remnashop;

--
-- Name: referral_reward_type; Type: TYPE; Schema: public; Owner: remnashop
--

CREATE TYPE public.referral_reward_type AS ENUM (
    'POINTS',
    'EXTRA_DAYS'
);


ALTER TYPE public.referral_reward_type OWNER TO remnashop;

--
-- Name: subscription_status; Type: TYPE; Schema: public; Owner: remnashop
--

CREATE TYPE public.subscription_status AS ENUM (
    'ACTIVE',
    'DISABLED',
    'LIMITED',
    'EXPIRED',
    'DELETED'
);


ALTER TYPE public.subscription_status OWNER TO remnashop;

--
-- Name: traffic_limit_strategy; Type: TYPE; Schema: public; Owner: remnashop
--

CREATE TYPE public.traffic_limit_strategy AS ENUM (
    'NO_RESET',
    'DAY',
    'WEEK',
    'MONTH'
);


ALTER TYPE public.traffic_limit_strategy OWNER TO remnashop;

--
-- Name: transaction_status; Type: TYPE; Schema: public; Owner: remnashop
--

CREATE TYPE public.transaction_status AS ENUM (
    'PENDING',
    'COMPLETED',
    'CANCELED',
    'REFUNDED',
    'FAILED'
);


ALTER TYPE public.transaction_status OWNER TO remnashop;

--
-- Name: user_role; Type: TYPE; Schema: public; Owner: remnashop
--

CREATE TYPE public.user_role AS ENUM (
    'DEV',
    'ADMIN',
    'USER',
    'PREVIEW',
    'OWNER',
    'SYSTEM'
);


ALTER TYPE public.user_role OWNER TO remnashop;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: ad_links; Type: TABLE; Schema: public; Owner: remnashop
--

CREATE TABLE public.ad_links (
    id integer NOT NULL,
    name character varying(128) NOT NULL,
    code character varying(64) NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT timezone('UTC'::text, now()) NOT NULL,
    updated_at timestamp with time zone DEFAULT timezone('UTC'::text, now()) NOT NULL
);


ALTER TABLE public.ad_links OWNER TO remnashop;

--
-- Name: ad_links_id_seq; Type: SEQUENCE; Schema: public; Owner: remnashop
--

CREATE SEQUENCE public.ad_links_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ad_links_id_seq OWNER TO remnashop;

--
-- Name: ad_links_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: remnashop
--

ALTER SEQUENCE public.ad_links_id_seq OWNED BY public.ad_links.id;


--
-- Name: admin_audit_log; Type: TABLE; Schema: public; Owner: remnashop
--

CREATE TABLE public.admin_audit_log (
    id integer NOT NULL,
    actor character varying(120) NOT NULL,
    method character varying(10) NOT NULL,
    path character varying(300) NOT NULL,
    status integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.admin_audit_log OWNER TO remnashop;

--
-- Name: admin_audit_log_id_seq; Type: SEQUENCE; Schema: public; Owner: remnashop
--

CREATE SEQUENCE public.admin_audit_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.admin_audit_log_id_seq OWNER TO remnashop;

--
-- Name: admin_audit_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: remnashop
--

ALTER SEQUENCE public.admin_audit_log_id_seq OWNED BY public.admin_audit_log.id;


--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: remnashop
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO remnashop;

--
-- Name: broadcast_messages; Type: TABLE; Schema: public; Owner: remnashop
--

CREATE TABLE public.broadcast_messages (
    id integer NOT NULL,
    broadcast_id integer NOT NULL,
    user_telegram_id bigint,
    message_id bigint,
    status public.broadcast_message_status NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE public.broadcast_messages OWNER TO remnashop;

--
-- Name: broadcast_messages_id_seq; Type: SEQUENCE; Schema: public; Owner: remnashop
--

CREATE SEQUENCE public.broadcast_messages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.broadcast_messages_id_seq OWNER TO remnashop;

--
-- Name: broadcast_messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: remnashop
--

ALTER SEQUENCE public.broadcast_messages_id_seq OWNED BY public.broadcast_messages.id;


--
-- Name: broadcasts; Type: TABLE; Schema: public; Owner: remnashop
--

CREATE TABLE public.broadcasts (
    id integer NOT NULL,
    task_id uuid NOT NULL,
    status public.broadcast_status NOT NULL,
    audience public.broadcast_audience NOT NULL,
    total_count integer NOT NULL,
    success_count integer NOT NULL,
    failed_count integer NOT NULL,
    payload jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT timezone('UTC'::text, now()) NOT NULL,
    updated_at timestamp with time zone DEFAULT timezone('UTC'::text, now()) NOT NULL
);


ALTER TABLE public.broadcasts OWNER TO remnashop;

--
-- Name: broadcasts_id_seq; Type: SEQUENCE; Schema: public; Owner: remnashop
--

CREATE SEQUENCE public.broadcasts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.broadcasts_id_seq OWNER TO remnashop;

--
-- Name: broadcasts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: remnashop
--

ALTER SEQUENCE public.broadcasts_id_seq OWNED BY public.broadcasts.id;


--
-- Name: payment_gateways; Type: TABLE; Schema: public; Owner: remnashop
--

CREATE TABLE public.payment_gateways (
    id integer NOT NULL,
    order_index integer NOT NULL,
    type public.payment_gateway_type NOT NULL,
    currency public.currency NOT NULL,
    is_active boolean NOT NULL,
    settings jsonb
);


ALTER TABLE public.payment_gateways OWNER TO remnashop;

--
-- Name: payment_gateways_id_seq; Type: SEQUENCE; Schema: public; Owner: remnashop
--

CREATE SEQUENCE public.payment_gateways_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.payment_gateways_id_seq OWNER TO remnashop;

--
-- Name: payment_gateways_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: remnashop
--

ALTER SEQUENCE public.payment_gateways_id_seq OWNED BY public.payment_gateways.id;


--
-- Name: plan_durations; Type: TABLE; Schema: public; Owner: remnashop
--

CREATE TABLE public.plan_durations (
    id integer NOT NULL,
    days integer NOT NULL,
    plan_id integer NOT NULL,
    order_index integer NOT NULL
);


ALTER TABLE public.plan_durations OWNER TO remnashop;

--
-- Name: plan_durations_id_seq; Type: SEQUENCE; Schema: public; Owner: remnashop
--

CREATE SEQUENCE public.plan_durations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.plan_durations_id_seq OWNER TO remnashop;

--
-- Name: plan_durations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: remnashop
--

ALTER SEQUENCE public.plan_durations_id_seq OWNED BY public.plan_durations.id;


--
-- Name: plan_prices; Type: TABLE; Schema: public; Owner: remnashop
--

CREATE TABLE public.plan_prices (
    id integer NOT NULL,
    currency public.currency NOT NULL,
    price numeric(10,2) NOT NULL,
    plan_duration_id integer NOT NULL
);


ALTER TABLE public.plan_prices OWNER TO remnashop;

--
-- Name: plan_prices_id_seq; Type: SEQUENCE; Schema: public; Owner: remnashop
--

CREATE SEQUENCE public.plan_prices_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.plan_prices_id_seq OWNER TO remnashop;

--
-- Name: plan_prices_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: remnashop
--

ALTER SEQUENCE public.plan_prices_id_seq OWNED BY public.plan_prices.id;


--
-- Name: plans; Type: TABLE; Schema: public; Owner: remnashop
--

CREATE TABLE public.plans (
    id integer NOT NULL,
    order_index integer NOT NULL,
    is_active boolean NOT NULL,
    type public.plan_type NOT NULL,
    availability public.plan_availability NOT NULL,
    name character varying NOT NULL,
    traffic_limit integer NOT NULL,
    device_limit integer NOT NULL,
    allowed_telegram_ids bigint[] DEFAULT '{}'::bigint[] NOT NULL,
    internal_squads uuid[] NOT NULL,
    created_at timestamp with time zone DEFAULT timezone('UTC'::text, now()) NOT NULL,
    updated_at timestamp with time zone DEFAULT timezone('UTC'::text, now()) NOT NULL,
    description character varying,
    tag character varying,
    traffic_limit_strategy public.plan_traffic_limit_strategy DEFAULT 'NO_RESET'::public.plan_traffic_limit_strategy NOT NULL,
    external_squad uuid,
    is_trial boolean NOT NULL,
    public_code character varying NOT NULL,
    allowed_emails text[] DEFAULT '{}'::text[] NOT NULL
);


ALTER TABLE public.plans OWNER TO remnashop;

--
-- Name: plans_id_seq; Type: SEQUENCE; Schema: public; Owner: remnashop
--

CREATE SEQUENCE public.plans_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.plans_id_seq OWNER TO remnashop;

--
-- Name: plans_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: remnashop
--

ALTER SEQUENCE public.plans_id_seq OWNED BY public.plans.id;


--
-- Name: promocode_activations; Type: TABLE; Schema: public; Owner: remnashop
--

CREATE TABLE public.promocode_activations (
    id integer NOT NULL,
    promocode_id integer NOT NULL,
    user_id integer NOT NULL,
    activated_at timestamp with time zone DEFAULT timezone('UTC'::text, now()) NOT NULL
);


ALTER TABLE public.promocode_activations OWNER TO remnashop;

--
-- Name: promocode_activations_id_seq; Type: SEQUENCE; Schema: public; Owner: remnashop
--

CREATE SEQUENCE public.promocode_activations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.promocode_activations_id_seq OWNER TO remnashop;

--
-- Name: promocode_activations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: remnashop
--

ALTER SEQUENCE public.promocode_activations_id_seq OWNED BY public.promocode_activations.id;


--
-- Name: promocodes; Type: TABLE; Schema: public; Owner: remnashop
--

CREATE TABLE public.promocodes (
    id integer NOT NULL,
    code character varying NOT NULL,
    is_active boolean NOT NULL,
    reward_type public.promocode_reward_type NOT NULL,
    reward integer,
    plan_snapshot jsonb,
    availability public.promocode_availability NOT NULL,
    expires_at timestamp with time zone,
    max_activations integer,
    created_at timestamp with time zone DEFAULT timezone('UTC'::text, now()) NOT NULL,
    updated_at timestamp with time zone DEFAULT timezone('UTC'::text, now()) NOT NULL,
    is_reusable boolean DEFAULT false NOT NULL
);


ALTER TABLE public.promocodes OWNER TO remnashop;

--
-- Name: promocodes_id_seq; Type: SEQUENCE; Schema: public; Owner: remnashop
--

CREATE SEQUENCE public.promocodes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.promocodes_id_seq OWNER TO remnashop;

--
-- Name: promocodes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: remnashop
--

ALTER SEQUENCE public.promocodes_id_seq OWNED BY public.promocodes.id;


--
-- Name: referral_rewards; Type: TABLE; Schema: public; Owner: remnashop
--

CREATE TABLE public.referral_rewards (
    id integer NOT NULL,
    referral_id integer NOT NULL,
    type public.referral_reward_type NOT NULL,
    amount integer NOT NULL,
    is_issued boolean NOT NULL,
    created_at timestamp with time zone DEFAULT timezone('UTC'::text, now()) NOT NULL,
    updated_at timestamp with time zone DEFAULT timezone('UTC'::text, now()) NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE public.referral_rewards OWNER TO remnashop;

--
-- Name: referral_rewards_id_seq; Type: SEQUENCE; Schema: public; Owner: remnashop
--

CREATE SEQUENCE public.referral_rewards_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.referral_rewards_id_seq OWNER TO remnashop;

--
-- Name: referral_rewards_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: remnashop
--

ALTER SEQUENCE public.referral_rewards_id_seq OWNED BY public.referral_rewards.id;


--
-- Name: referrals; Type: TABLE; Schema: public; Owner: remnashop
--

CREATE TABLE public.referrals (
    id integer NOT NULL,
    level public.referral_level NOT NULL,
    created_at timestamp with time zone DEFAULT timezone('UTC'::text, now()) NOT NULL,
    updated_at timestamp with time zone DEFAULT timezone('UTC'::text, now()) NOT NULL,
    referrer_id integer NOT NULL,
    referred_id integer NOT NULL
);


ALTER TABLE public.referrals OWNER TO remnashop;

--
-- Name: referrals_id_seq; Type: SEQUENCE; Schema: public; Owner: remnashop
--

CREATE SEQUENCE public.referrals_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.referrals_id_seq OWNER TO remnashop;

--
-- Name: referrals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: remnashop
--

ALTER SEQUENCE public.referrals_id_seq OWNED BY public.referrals.id;


--
-- Name: settings; Type: TABLE; Schema: public; Owner: remnashop
--

CREATE TABLE public.settings (
    id integer NOT NULL,
    default_currency public.currency NOT NULL,
    referral jsonb DEFAULT '{"enable": true, "level": 1, "accrual_strategy": "ON_FIRST_PAYMENT", "reward": {"type": "EXTRA_DAYS", "strategy": "AMOUNT", "config": {"1": 5}}}'::json NOT NULL,
    access jsonb NOT NULL,
    requirements jsonb NOT NULL,
    notifications jsonb NOT NULL,
    menu jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT timezone('UTC'::text, now()) NOT NULL,
    updated_at timestamp with time zone DEFAULT timezone('UTC'::text, now()) NOT NULL,
    backup jsonb NOT NULL,
    blacklist jsonb NOT NULL,
    extra jsonb DEFAULT '{}'::jsonb NOT NULL
);


ALTER TABLE public.settings OWNER TO remnashop;

--
-- Name: settings_id_seq; Type: SEQUENCE; Schema: public; Owner: remnashop
--

CREATE SEQUENCE public.settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.settings_id_seq OWNER TO remnashop;

--
-- Name: settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: remnashop
--

ALTER SEQUENCE public.settings_id_seq OWNED BY public.settings.id;


--
-- Name: subscriptions; Type: TABLE; Schema: public; Owner: remnashop
--

CREATE TABLE public.subscriptions (
    id integer NOT NULL,
    user_remna_id uuid NOT NULL,
    status public.subscription_status NOT NULL,
    is_trial boolean NOT NULL,
    traffic_limit integer NOT NULL,
    device_limit integer NOT NULL,
    internal_squads uuid[] NOT NULL,
    expire_at timestamp with time zone NOT NULL,
    url character varying NOT NULL,
    plan_snapshot jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT timezone('UTC'::text, now()) NOT NULL,
    updated_at timestamp with time zone DEFAULT timezone('UTC'::text, now()) NOT NULL,
    external_squad uuid,
    traffic_limit_strategy public.plan_traffic_limit_strategy NOT NULL,
    tag character varying,
    user_id integer NOT NULL,
    device_single_reset_at timestamp with time zone,
    device_all_reset_at timestamp with time zone,
    link_reset_at timestamp with time zone,
    disabled_by_channel_leave boolean DEFAULT false NOT NULL
);


ALTER TABLE public.subscriptions OWNER TO remnashop;

--
-- Name: subscriptions_id_seq; Type: SEQUENCE; Schema: public; Owner: remnashop
--

CREATE SEQUENCE public.subscriptions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.subscriptions_id_seq OWNER TO remnashop;

--
-- Name: subscriptions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: remnashop
--

ALTER SEQUENCE public.subscriptions_id_seq OWNED BY public.subscriptions.id;


--
-- Name: support_messages; Type: TABLE; Schema: public; Owner: remnashop
--

CREATE TABLE public.support_messages (
    id integer NOT NULL,
    ticket_id integer NOT NULL,
    sender character varying(10) NOT NULL,
    body text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.support_messages OWNER TO remnashop;

--
-- Name: support_messages_id_seq; Type: SEQUENCE; Schema: public; Owner: remnashop
--

CREATE SEQUENCE public.support_messages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.support_messages_id_seq OWNER TO remnashop;

--
-- Name: support_messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: remnashop
--

ALTER SEQUENCE public.support_messages_id_seq OWNED BY public.support_messages.id;


--
-- Name: support_tickets; Type: TABLE; Schema: public; Owner: remnashop
--

CREATE TABLE public.support_tickets (
    id integer NOT NULL,
    user_id integer NOT NULL,
    subject character varying(200) NOT NULL,
    status character varying(20) DEFAULT 'open'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.support_tickets OWNER TO remnashop;

--
-- Name: support_tickets_id_seq; Type: SEQUENCE; Schema: public; Owner: remnashop
--

CREATE SEQUENCE public.support_tickets_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.support_tickets_id_seq OWNER TO remnashop;

--
-- Name: support_tickets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: remnashop
--

ALTER SEQUENCE public.support_tickets_id_seq OWNED BY public.support_tickets.id;


--
-- Name: transactions; Type: TABLE; Schema: public; Owner: remnashop
--

CREATE TABLE public.transactions (
    id integer NOT NULL,
    payment_id uuid NOT NULL,
    status public.transaction_status NOT NULL,
    is_test boolean NOT NULL,
    purchase_type public.purchase_type NOT NULL,
    gateway_type public.payment_gateway_type NOT NULL,
    pricing jsonb NOT NULL,
    currency public.currency NOT NULL,
    plan_snapshot jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT timezone('UTC'::text, now()) NOT NULL,
    updated_at timestamp with time zone DEFAULT timezone('UTC'::text, now()) NOT NULL,
    user_id integer NOT NULL,
    gateway_display_name character varying,
    payment_method character varying
);


ALTER TABLE public.transactions OWNER TO remnashop;

--
-- Name: transactions_id_seq; Type: SEQUENCE; Schema: public; Owner: remnashop
--

CREATE SEQUENCE public.transactions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.transactions_id_seq OWNER TO remnashop;

--
-- Name: transactions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: remnashop
--

ALTER SEQUENCE public.transactions_id_seq OWNED BY public.transactions.id;


--
-- Name: user_oauth_providers; Type: TABLE; Schema: public; Owner: remnashop
--

CREATE TABLE public.user_oauth_providers (
    id integer NOT NULL,
    user_id integer NOT NULL,
    provider character varying(32) NOT NULL,
    provider_id character varying(255) NOT NULL,
    created_at timestamp with time zone DEFAULT timezone('UTC'::text, now()) NOT NULL,
    updated_at timestamp with time zone DEFAULT timezone('UTC'::text, now()) NOT NULL
);


ALTER TABLE public.user_oauth_providers OWNER TO remnashop;

--
-- Name: user_oauth_providers_id_seq; Type: SEQUENCE; Schema: public; Owner: remnashop
--

CREATE SEQUENCE public.user_oauth_providers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_oauth_providers_id_seq OWNER TO remnashop;

--
-- Name: user_oauth_providers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: remnashop
--

ALTER SEQUENCE public.user_oauth_providers_id_seq OWNED BY public.user_oauth_providers.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: remnashop
--

CREATE TABLE public.users (
    id integer NOT NULL,
    telegram_id bigint,
    username character varying(32),
    name character varying NOT NULL,
    role public.user_role NOT NULL,
    language public.locale NOT NULL,
    personal_discount integer NOT NULL,
    purchase_discount integer NOT NULL,
    is_blocked boolean NOT NULL,
    is_bot_blocked boolean NOT NULL,
    current_subscription_id integer,
    created_at timestamp with time zone DEFAULT timezone('UTC'::text, now()) NOT NULL,
    updated_at timestamp with time zone DEFAULT timezone('UTC'::text, now()) NOT NULL,
    referral_code character varying(64) NOT NULL,
    points integer DEFAULT 0 NOT NULL,
    is_rules_accepted boolean NOT NULL,
    is_trial_available boolean NOT NULL,
    email character varying(255),
    password_hash character varying(512),
    is_email_verified boolean NOT NULL,
    pending_email character varying(255),
    email_verification_code_hash character varying(128),
    email_verification_expires_at timestamp with time zone,
    auth_type character varying(20) NOT NULL,
    ad_link_id integer,
    referral_code_reset_at timestamp with time zone
);


ALTER TABLE public.users OWNER TO remnashop;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: remnashop
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO remnashop;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: remnashop
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: ad_links id; Type: DEFAULT; Schema: public; Owner: remnashop
--

ALTER TABLE ONLY public.ad_links ALTER COLUMN id SET DEFAULT nextval('public.ad_links_id_seq'::regclass);


--
-- Name: admin_audit_log id; Type: DEFAULT; Schema: public; Owner: remnashop
--

ALTER TABLE ONLY public.admin_audit_log ALTER COLUMN id SET DEFAULT nextval('public.admin_audit_log_id_seq'::regclass);


--
-- Name: broadcast_messages id; Type: DEFAULT; Schema: public; Owner: remnashop
--

ALTER TABLE ONLY public.broadcast_messages ALTER COLUMN id SET DEFAULT nextval('public.broadcast_messages_id_seq'::regclass);


--
-- Name: broadcasts id; Type: DEFAULT; Schema: public; Owner: remnashop
--

ALTER TABLE ONLY public.broadcasts ALTER COLUMN id SET DEFAULT nextval('public.broadcasts_id_seq'::regclass);


--
-- Name: payment_gateways id; Type: DEFAULT; Schema: public; Owner: remnashop
--

ALTER TABLE ONLY public.payment_gateways ALTER COLUMN id SET DEFAULT nextval('public.payment_gateways_id_seq'::regclass);


--
-- Name: plan_durations id; Type: DEFAULT; Schema: public; Owner: remnashop
--

ALTER TABLE ONLY public.plan_durations ALTER COLUMN id SET DEFAULT nextval('public.plan_durations_id_seq'::regclass);


--
-- Name: plan_prices id; Type: DEFAULT; Schema: public; Owner: remnashop
--

ALTER TABLE ONLY public.plan_prices ALTER COLUMN id SET DEFAULT nextval('public.plan_prices_id_seq'::regclass);


--
-- Name: plans id; Type: DEFAULT; Schema: public; Owner: remnashop
--

ALTER TABLE ONLY public.plans ALTER COLUMN id SET DEFAULT nextval('public.plans_id_seq'::regclass);


--
-- Name: promocode_activations id; Type: DEFAULT; Schema: public; Owner: remnashop
--

ALTER TABLE ONLY public.promocode_activations ALTER COLUMN id SET DEFAULT nextval('public.promocode_activations_id_seq'::regclass);


--
-- Name: promocodes id; Type: DEFAULT; Schema: public; Owner: remnashop
--

ALTER TABLE ONLY public.promocodes ALTER COLUMN id SET DEFAULT nextval('public.promocodes_id_seq'::regclass);


--
-- Name: referral_rewards id; Type: DEFAULT; Schema: public; Owner: remnashop
--

ALTER TABLE ONLY public.referral_rewards ALTER COLUMN id SET DEFAULT nextval('public.referral_rewards_id_seq'::regclass);


--
-- Name: referrals id; Type: DEFAULT; Schema: public; Owner: remnashop
--

ALTER TABLE ONLY public.referrals ALTER COLUMN id SET DEFAULT nextval('public.referrals_id_seq'::regclass);


--
-- Name: settings id; Type: DEFAULT; Schema: public; Owner: remnashop
--

ALTER TABLE ONLY public.settings ALTER COLUMN id SET DEFAULT nextval('public.settings_id_seq'::regclass);


--
-- Name: subscriptions id; Type: DEFAULT; Schema: public; Owner: remnashop
--

ALTER TABLE ONLY public.subscriptions ALTER COLUMN id SET DEFAULT nextval('public.subscriptions_id_seq'::regclass);


--
-- Name: support_messages id; Type: DEFAULT; Schema: public; Owner: remnashop
--

ALTER TABLE ONLY public.support_messages ALTER COLUMN id SET DEFAULT nextval('public.support_messages_id_seq'::regclass);


--
-- Name: support_tickets id; Type: DEFAULT; Schema: public; Owner: remnashop
--

ALTER TABLE ONLY public.support_tickets ALTER COLUMN id SET DEFAULT nextval('public.support_tickets_id_seq'::regclass);


--
-- Name: transactions id; Type: DEFAULT; Schema: public; Owner: remnashop
--

ALTER TABLE ONLY public.transactions ALTER COLUMN id SET DEFAULT nextval('public.transactions_id_seq'::regclass);


--
-- Name: user_oauth_providers id; Type: DEFAULT; Schema: public; Owner: remnashop
--

ALTER TABLE ONLY public.user_oauth_providers ALTER COLUMN id SET DEFAULT nextval('public.user_oauth_providers_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: remnashop
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: ad_links; Type: TABLE DATA; Schema: public; Owner: remnashop
--

COPY public.ad_links (id, name, code, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: admin_audit_log; Type: TABLE DATA; Schema: public; Owner: remnashop
--

COPY public.admin_audit_log (id, actor, method, path, status, created_at) FROM stdin;
1	@Aleksandr_Goriainov	POST	/api/v1/admin/support/tickets/1/status	200	2026-06-28 18:00:34.271648+00
2	@Aleksandr_Goriainov	PUT	/api/v1/admin/apps	200	2026-06-28 18:04:41.242094+00
\.


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: remnashop
--

COPY public.alembic_version (version_num) FROM stdin;
0040
\.


--
-- Data for Name: broadcast_messages; Type: TABLE DATA; Schema: public; Owner: remnashop
--

COPY public.broadcast_messages (id, broadcast_id, user_telegram_id, message_id, status, user_id) FROM stdin;
147	6	1394034854	10993	SENT	21
148	6	8078468447	10994	SENT	19
149	6	5256051267	11000	SENT	13
150	6	5566641771	11005	SENT	717
151	6	6205390666	10998	SENT	11
152	6	1640268421	10997	SENT	8
153	6	478979333	10999	SENT	12
154	6	8261668113	10990	SENT	14
155	6	8097606820	10989	SENT	694
156	6	5887257461	10988	SENT	700
157	6	6300464896	11003	SENT	698
158	6	8777277767	11001	SENT	822
159	6	1337030857	10992	SENT	18
160	6	1301243503	10986	SENT	3
161	6	1489283201	10995	SENT	22
162	6	462113585	11004	SENT	23
163	6	1349626770	10996	SENT	702
164	6	7450035785	11002	SENT	42
165	6	7172951429	10991	SENT	43
166	6	5572930262	10987	SENT	26
167	6	7380841579	11007	SENT	44
168	6	8274401525	11006	SENT	718
169	6	7288750002	11008	SENT	45
170	6	7455994994	11009	SENT	46
171	6	7491024356	11010	SENT	47
172	6	7122366076	11011	SENT	48
173	6	6503498484	11014	SENT	49
174	6	7417244324	11012	SENT	50
175	6	5566835452	11018	SENT	51
176	6	6487412221	11013	SENT	27
177	6	7321695838	11016	SENT	52
178	6	7137332170	11019	SENT	53
179	6	7488466797	11015	SENT	676
180	6	2016406877	11017	SENT	29
181	6	5986546413	11020	SENT	30
182	6	8543938635	\N	FAILED	792
183	6	5581255609	11022	SENT	25
184	6	5305665179	11021	SENT	687
185	6	5334269724	11024	SENT	15
186	6	8143932381	11023	SENT	31
187	6	1177696065	11031	SENT	33
188	6	5594197564	11025	SENT	16
189	6	1115561743	11032	SENT	728
190	6	1771582738	11026	SENT	7
191	6	880601228	11028	SENT	20
192	6	8380465191	11027	SENT	17
193	6	233781889	11030	SENT	10
194	6	799081841	11029	SENT	9
195	6	7038893979	11033	SENT	34
196	6	7391948218	11035	SENT	35
197	6	7187512358	11036	SENT	36
198	6	7410555375	11034	SENT	37
199	6	6487602590	11040	SENT	38
200	6	6554193113	11038	SENT	39
201	6	7190243719	11037	SENT	40
202	6	7499529675	11039	SENT	41
203	6	7144442403	11042	SENT	54
204	6	6757922624	11043	SENT	55
205	6	7128362025	11041	SENT	56
206	6	7285725177	11044	SENT	57
207	6	6854004170	11046	SENT	58
208	6	7072859207	11045	SENT	59
209	6	7185451514	11054	SENT	60
210	6	7223675208	11047	SENT	61
211	6	7338428345	11053	SENT	62
212	6	7295987638	11058	SENT	63
213	6	7276629524	11055	SENT	64
214	6	7492372845	11057	SENT	65
215	6	7307890386	11052	SENT	66
216	6	7231927002	11056	SENT	67
217	6	1452534244	11064	SENT	4
218	6	7351740982	11063	SENT	68
219	6	7061189280	11060	SENT	71
220	6	7319867279	11062	SENT	74
221	6	6411120039	11059	SENT	81
222	6	7384490069	11061	SENT	92
223	6	7398212280	11050	SENT	107
224	6	7433869293	11048	SENT	128
225	6	7486177728	11051	SENT	154
226	6	7332486092	11049	SENT	191
227	6	7413630065	11066	SENT	241
228	6	7354866904	11068	SENT	300
229	6	7417621134	11067	SENT	359
230	6	7394365009	11069	SENT	418
231	6	7480599636	11072	SENT	477
232	6	2067224852	11074	SENT	664
233	6	1705091148	11065	SENT	719
234	6	6159205362	11070	SENT	695
235	6	5014160544	11078	SENT	619
236	6	1590513029	11071	SENT	729
237	6	7738883042	11075	SENT	703
238	6	6793204759	11076	SENT	704
239	6	7685702678	11082	SENT	705
240	6	7626879649	11073	SENT	706
241	6	5992905982	11080	SENT	707
242	6	7340129004	11077	SENT	69
243	6	6996445188	11081	SENT	72
244	6	7430129719	11079	SENT	75
245	6	7354194922	11083	SENT	79
246	6	7133030596	11084	SENT	84
247	6	6958467224	11086	SENT	95
248	6	7228818009	11085	SENT	111
249	6	7477498200	11087	SENT	132
250	6	7119233548	11089	SENT	159
251	6	6904058698	11090	SENT	196
252	6	7297960774	11092	SENT	247
253	6	6617954808	11094	SENT	306
254	6	7287319665	11091	SENT	366
255	6	7267885936	11103	SENT	425
256	6	6843364768	11095	SENT	484
257	6	8750176301	11088	SENT	665
258	6	865516063	11104	SENT	720
259	6	852409517	11099	SENT	730
260	6	7613640229	11098	SENT	689
261	6	5170224742	11093	SENT	794
262	6	5480077164	11096	SENT	696
263	6	6950538855	11102	SENT	826
264	6	5381951943	11097	SENT	710
265	6	7560014900	11100	SENT	711
266	6	6748820752	11101	SENT	70
267	6	7480940229	11107	SENT	73
268	6	7077460072	11106	SENT	76
269	6	6883471731	11105	SENT	77
270	6	6788251292	11122	SENT	78
271	6	7399645099	11108	SENT	80
272	6	7081936228	11110	SENT	82
273	6	7479343577	11109	SENT	83
274	6	7336115488	11111	SENT	85
275	6	7078573519	11113	SENT	86
276	6	7270320670	11112	SENT	87
277	6	7302644015	11114	SENT	88
278	6	6490138552	11117	SENT	89
279	6	7224443453	11124	SENT	90
280	6	6737205642	11116	SENT	91
281	6	7292243830	11115	SENT	93
282	6	6938294583	11119	SENT	94
283	6	7221896728	11118	SENT	96
284	6	7113311819	11123	SENT	97
285	6	6712822171	11120	SENT	98
286	6	7117931610	11121	SENT	99
287	6	6912688847	11125	SENT	100
288	6	7217808692	11128	SENT	101
289	6	7411731871	11127	SENT	102
290	6	7032147482	11126	SENT	103
291	6	7256161644	11136	SENT	104
292	6	7356073196	11129	SENT	105
293	6	7279002114	11130	SENT	106
294	6	6819629081	11131	SENT	108
295	6	7414434083	11133	SENT	109
296	6	7448056782	11132	SENT	110
297	6	6819104727	11134	SENT	112
298	6	7146428273	11135	SENT	113
299	6	6513101232	11141	SENT	114
300	6	6831988322	11144	SENT	115
301	6	7385458403	11137	SENT	116
302	6	7483947461	11138	SENT	117
303	6	7281842976	11140	SENT	118
304	6	7364825145	11139	SENT	119
305	6	7250351029	11142	SENT	120
306	6	7259733413	11143	SENT	121
307	6	7357787447	11146	SENT	122
308	6	7467253710	11147	SENT	123
309	6	7390027772	11145	SENT	124
310	6	7280023532	11156	SENT	125
311	6	7408005329	11154	SENT	126
312	6	7203645209	11148	SENT	127
313	6	7497076469	11149	SENT	129
314	6	7402642250	11150	SENT	130
315	6	7398189598	11159	SENT	131
316	6	7210201658	11153	SENT	133
317	6	7129912346	11158	SENT	134
318	6	6695311415	11152	SENT	135
319	6	7293375733	11151	SENT	136
320	6	6856781049	11155	SENT	137
321	6	7263883783	11163	SENT	138
322	6	7345328988	11164	SENT	139
323	6	7335435107	11160	SENT	140
327	6	7472076728	11166	SENT	143
328	6	6955637268	11165	SENT	172
329	6	7241693219	11169	SENT	214
330	6	7017217935	11171	SENT	265
331	6	7366497366	11173	SENT	324
332	6	7002587286	11170	SENT	383
333	6	7272638101	11174	SENT	442
334	6	7335384411	11172	SENT	501
335	6	931779414	11180	SENT	722
336	6	175189326	11181	SENT	690
347	6	7341332557	11187	SENT	224
348	6	7275715624	11185	SENT	259
349	6	7262621586	11200	SENT	275
350	6	7337281368	11186	SENT	318
351	6	7265568579	11196	SENT	334
352	6	7216789683	11197	SENT	377
353	6	6903175433	11195	SENT	393
354	6	7463228093	11202	SENT	435
367	6	7186586540	11205	SENT	225
368	6	7372217440	11206	SENT	276
369	6	6808370611	11212	SENT	335
370	6	7479224907	11215	SENT	394
371	6	7451393448	11207	SENT	453
372	6	7336596100	11210	SENT	512
373	6	1083060921	11219	SENT	724
374	6	806465974	11211	SENT	692
375	6	912237048	11220	SENT	733
376	6	1040358746	11213	SENT	829
377	6	7405150363	11214	SENT	148
378	6	7009754328	11217	SENT	181
379	6	7322936602	11216	SENT	227
380	6	7424107413	11218	SENT	277
381	6	7225475227	11208	SENT	336
382	6	7278064469	11222	SENT	395
387	6	490107533	11225	SENT	726
388	6	985794662	11226	SENT	830
389	6	7320198281	11224	SENT	149
390	6	7069077029	11229	SENT	184
391	6	7178769654	11234	SENT	234
392	6	6812847389	11239	SENT	289
393	6	7458198444	11231	SENT	348
394	6	7445856809	11232	SENT	407
395	6	7045231912	11233	SENT	466
396	6	7050075079	11230	SENT	525
397	6	8341525065	11236	SENT	682
398	6	5196355976	11235	SENT	831
399	6	7468367470	11238	SENT	150
400	6	7354966146	11240	SENT	151
401	6	7105211061	11237	SENT	185
402	6	7102805530	11228	SENT	190
407	6	7345173335	11245	SENT	351
408	6	1522905492	11244	SENT	610
409	6	6607571464	11254	SENT	358
410	6	6317918580	11246	SENT	410
411	6	7494212450	11252	SENT	417
412	6	7475039772	11247	SENT	469
413	6	7394563013	11249	SENT	476
414	6	228833161	11251	SENT	672
415	6	5226836717	11253	SENT	683
416	6	6500276672	11248	SENT	802
417	6	7699352527	11250	SENT	737
418	6	7165553695	11256	SENT	152
419	6	6573150121	11255	SENT	187
420	6	7234202457	11261	SENT	237
421	6	7398903961	11258	SENT	296
422	6	7049252962	11260	SENT	356
427	6	8406041826	11271	SENT	684
428	6	7395037907	11265	SENT	153
429	6	7492788624	11264	SENT	188
430	6	7066731611	11270	SENT	239
431	6	7057039169	11268	SENT	298
432	6	6748887010	11266	SENT	357
433	6	7260657319	11269	SENT	416
434	6	7352100625	11272	SENT	475
435	6	7369764310	11274	SENT	155
436	6	7034019132	11283	SENT	192
437	6	7472715901	11273	SENT	243
438	6	7287242628	11275	SENT	302
439	6	7439819306	11276	SENT	361
440	6	7421675547	11280	SENT	420
441	6	1330562493	11267	SENT	479
442	6	1227051309	11277	SENT	835
447	6	6392111368	11284	SENT	303
448	6	7264265057	11285	SENT	362
449	6	7343598327	11289	SENT	421
450	6	6498115511	11286	SENT	480
451	6	7560357719	11302	SENT	741
452	6	408300874	11287	SENT	806
453	6	8426825252	11293	SENT	836
454	6	7467695816	11290	SENT	157
455	6	7248597399	11288	SENT	194
456	6	7234030910	11291	SENT	245
457	6	7198381183	11292	SENT	304
458	6	7248584120	11301	SENT	363
459	6	7316713996	11296	SENT	422
460	6	6768686529	11294	SENT	481
461	6	6988507363	11295	SENT	158
462	6	6853206923	11297	SENT	195
467	6	7448788759	11305	SENT	483
468	6	710012309	11306	SENT	838
469	6	5233422473	11313	SENT	743
470	6	1447080406	11304	SENT	808
471	6	367906205	11310	SENT	810
472	6	7285392010	11311	SENT	160
473	6	6546191298	11316	SENT	197
474	6	7253597290	11314	SENT	248
475	6	7274796723	11309	SENT	307
476	6	7394591101	11315	SENT	365
477	6	7286174077	11312	SENT	424
478	6	7440476426	11319	SENT	482
479	6	8666693791	\N	FAILED	745
480	6	6218027116	11320	SENT	746
481	6	1491940586	11308	SENT	809
482	6	7420598772	11307	SENT	161
487	6	7396385500	11323	SENT	426
488	6	7448858687	11324	SENT	485
489	6	6188491953	11325	SENT	811
490	6	551288028	11328	SENT	840
491	6	7489493064	11330	SENT	162
492	6	7346049541	11331	SENT	199
493	6	7491811013	11327	SENT	250
507	6	1408979993	11345	SENT	813
508	6	6305114719	11344	SENT	842
509	6	7453490673	11343	SENT	164
510	6	7351360835	11349	SENT	201
511	6	6833737453	11352	SENT	252
512	6	7472360536	11350	SENT	311
513	6	6773494532	11362	SENT	370
514	6	7176927120	11351	SENT	429
515	6	7260243414	11353	SENT	488
516	6	1325429451	11354	SENT	814
527	6	7132517841	11365	SENT	203
528	6	7400978359	11363	SENT	254
529	6	7104936886	11364	SENT	313
530	6	7391151265	11366	SENT	372
531	6	7428305063	11370	SENT	431
532	6	6444883211	11368	SENT	490
533	6	8766782393	11369	SENT	752
534	6	7843181300	11367	SENT	816
535	6	7431088278	11371	SENT	167
536	6	7167504078	11372	SENT	204
537	6	7438346139	11373	SENT	255
538	6	7062405915	11374	SENT	314
539	6	7020719005	11377	SENT	373
540	6	7353247648	11376	SENT	432
541	6	7408520048	11378	SENT	491
542	6	6255838509	11375	SENT	817
547	6	7483113939	11383	SENT	374
548	6	6753127049	11384	SENT	433
549	6	7013215746	11386	SENT	492
550	6	5116868592	11389	SENT	754
551	6	6804486744	11390	SENT	169
552	6	6888226470	11387	SENT	171
553	6	6949153488	11385	SENT	173
554	6	7280737377	11392	SENT	174
555	6	6423322805	11391	SENT	175
556	6	7218790478	11393	SENT	176
557	6	7497721621	11394	SENT	206
558	6	7241060297	11399	SENT	212
559	6	7389838892	11397	SENT	219
560	6	7410354048	11396	SENT	220
561	6	7409301268	11395	SENT	222
562	6	6926469043	11388	SENT	217
567	6	7404687839	11404	SENT	271
568	6	7174260970	11405	SENT	273
569	6	6858248295	11403	SENT	316
570	6	7369130617	11415	SENT	322
571	6	7216125388	11412	SENT	327
572	6	6837172151	11413	SENT	329
573	6	7493986530	11414	SENT	330
574	6	7475386990	11421	SENT	332
575	6	7232032870	11416	SENT	376
576	6	7307510835	11419	SENT	381
577	6	7209103418	11417	SENT	386
578	6	6849930782	11422	SENT	388
579	6	6433996072	11409	SENT	389
580	6	7122237892	11408	SENT	391
581	6	7276965181	11410	SENT	436
582	6	7226638120	11411	SENT	440
587	6	7465918207	11423	SENT	495
588	6	7453211768	11441	SENT	500
589	6	7317992389	11436	SENT	504
590	6	6954314423	11424	SENT	506
591	6	6606922596	11426	SENT	507
592	6	7010477957	11425	SENT	509
593	6	7383316244	11431	SENT	177
594	6	7319524003	11429	SENT	180
595	6	7294668602	11428	SENT	182
596	6	7231878023	11427	SENT	183
597	6	7466735922	11430	SENT	186
598	6	7338382935	11433	SENT	189
599	6	6996180060	11432	SENT	207
600	6	7331866625	11435	SENT	208
601	6	7365792037	11440	SENT	210
602	6	6974631796	11434	SENT	211
607	6	6700996795	11445	SENT	221
608	6	7047451651	11454	SENT	223
609	6	7435782158	11443	SENT	226
610	6	7252147772	11462	SENT	228
611	6	6846886157	11447	SENT	229
612	6	7067607532	11444	SENT	230
613	6	7202615296	11455	SENT	231
614	6	7447217681	11450	SENT	232
615	6	7112432693	11448	SENT	233
616	6	7472809344	11459	SENT	235
617	6	6985498584	11449	SENT	238
618	6	7418702199	11453	SENT	242
619	6	7227331186	11446	SENT	258
620	6	7313812923	11451	SENT	260
621	6	7278100939	11461	SENT	261
622	6	7437377141	11456	SENT	262
627	6	7325860999	11470	SENT	272
628	6	7090929231	11468	SENT	274
629	6	6441697181	11464	SENT	278
630	6	7198679153	11465	SENT	279
631	6	7198098954	11478	SENT	280
632	6	7343409963	11463	SENT	281
633	6	7276814834	11467	SENT	282
634	6	6308959854	11474	SENT	283
635	6	7464092625	11473	SENT	284
636	6	7295638836	11479	SENT	285
637	6	7476749427	11469	SENT	286
638	6	7233589765	11471	SENT	287
639	6	7421379882	11466	SENT	288
640	6	7138901894	11480	SENT	290
641	6	7482839312	11472	SENT	291
642	6	7462017304	11476	SENT	293
647	6	7295930733	11483	SENT	317
648	6	7213957980	11484	SENT	319
649	6	7324556223	11485	SENT	320
650	6	7167961722	11492	SENT	321
667	6	7196450715	11509	SENT	392
668	6	6608027146	11504	SENT	451
669	6	7081185112	11503	SENT	510
670	6	7251997613	11505	SENT	337
671	6	7419968661	11506	SENT	396
672	6	7085680005	11511	SENT	455
673	6	7309003219	11512	SENT	514
674	6	689317410	11510	SENT	760
675	6	7354137905	11520	SENT	338
676	6	7431685292	11518	SENT	397
677	6	7284593691	11513	SENT	456
678	6	6809238946	11514	SENT	515
687	6	7069608183	11526	SENT	517
688	6	1422360630	11523	SENT	764
689	6	7243330578	11534	SENT	341
690	6	7288951735	11525	SENT	400
691	6	7310233717	11524	SENT	460
692	6	7494052497	11530	SENT	518
693	6	752733455	11528	SENT	765
694	6	7261834773	11541	SENT	342
695	6	7422936014	11527	SENT	401
696	6	7308801729	11531	SENT	459
697	6	7020983929	11529	SENT	519
698	6	5960998575	11533	SENT	767
699	6	7256246595	11536	SENT	343
700	6	7373852535	11535	SENT	402
701	6	6733784728	11537	SENT	461
702	6	7243499323	11532	SENT	520
707	6	709558403	11544	SENT	769
708	6	1733848029	11543	SENT	345
709	6	7492588621	11545	SENT	404
710	6	7398894464	11548	SENT	463
711	6	7366857168	11558	SENT	522
712	6	352528406	11546	SENT	770
713	6	7499812563	11549	SENT	346
714	6	7427086431	11554	SENT	405
715	6	6992993264	11547	SENT	464
716	6	6798530185	11550	SENT	523
717	6	1345408323	11551	SENT	771
718	6	5029805473	11556	SENT	772
719	6	7437049904	11553	SENT	347
720	6	7072122551	11552	SENT	406
721	6	7309536805	11557	SENT	465
722	6	7056083171	11560	SENT	524
727	6	8469159321	11563	SENT	774
728	6	7421741513	11569	SENT	350
729	6	6673900884	11564	SENT	409
730	6	7382148216	11570	SENT	468
731	6	1105671913	11565	SENT	775
732	6	7300324897	11568	SENT	352
733	6	7279155897	11567	SENT	411
734	6	7224855820	11566	SENT	470
735	6	7248915665	11571	SENT	353
736	6	6937459770	11573	SENT	412
737	6	6976190975	11572	SENT	471
738	6	1028687205	11577	SENT	777
739	6	6751043630	11574	SENT	354
740	6	7158831461	11582	SENT	413
741	6	7335363341	11575	SENT	472
742	6	5389963337	11576	SENT	778
747	6	6315175943	11585	SENT	419
748	6	7283104880	11583	SENT	478
749	6	454283996	11586	SENT	780
750	6	7427274222	11584	SENT	375
751	6	7012594799	11588	SENT	434
752	6	7445387747	11587	SENT	493
753	6	6707485988	11602	SENT	781
754	6	6963760432	11599	SENT	378
755	6	7245932268	11592	SENT	437
756	6	7232242227	11597	SENT	496
757	6	5128813849	11589	SENT	782
758	6	7412173814	11596	SENT	379
759	6	6676770295	11591	SENT	438
760	6	7261246795	11594	SENT	497
761	6	5552137646	11590	SENT	783
762	6	6544143443	11593	SENT	380
767	6	6897613313	11607	SENT	441
768	6	7081094475	11610	SENT	499
769	6	1221520522	11609	SENT	785
770	6	7316858968	11612	SENT	384
771	6	7442336632	11614	SENT	443
772	6	7429463934	11613	SENT	502
773	6	7329338730	11618	SENT	526
774	6	7854702179	11616	SENT	527
775	6	5426883646	11611	SENT	528
776	6	8009219593	11615	SENT	529
777	6	8516357412	11620	SENT	530
778	6	7807708092	11617	SENT	531
779	6	8000780567	11619	SENT	532
780	6	8355295916	\N	FAILED	533
781	6	5829264272	11621	SENT	534
782	6	7467672955	11603	SENT	535
783	6	7250005250	11605	SENT	536
787	6	6433762255	11625	SENT	540
788	6	8491023535	11623	SENT	541
789	6	7121154402	11631	SENT	542
790	6	6885513166	11624	SENT	543
791	6	7516765087	11627	SENT	544
792	6	8140161679	11622	SENT	545
793	6	8171678958	11626	SENT	546
794	6	7848871738	11628	SENT	547
795	6	7046491058	11640	SENT	548
796	6	7336674839	11630	SENT	549
797	6	7734412686	11639	SENT	550
798	6	7040106645	11637	SENT	551
799	6	8151044917	11632	SENT	552
800	6	7598472648	11629	SENT	553
801	6	7153167875	11638	SENT	554
802	6	7282296280	11634	SENT	555
807	6	7177394111	11642	SENT	560
324	6	7227615305	11157	SENT	141
325	6	6902336319	11161	SENT	142
326	6	6536188029	11162	SENT	146
337	6	8760102889	11182	SENT	796
338	6	5343646622	11175	SENT	731
339	6	1551954657	11167	SENT	697
340	6	6657993130	11183	SENT	721
341	6	8793182428	11176	SENT	716
342	6	7396980070	11168	SENT	144
343	6	7120695040	11177	SENT	145
344	6	5733577611	11178	SENT	170
345	6	7440722694	11184	SENT	178
346	6	7005339027	11179	SENT	209
355	6	7305513383	11198	SENT	452
356	6	7084403761	11193	SENT	494
357	6	6842873070	11189	SENT	511
358	6	1806802248	11188	SENT	668
359	6	7183273066	11199	SENT	680
360	6	404604015	11201	SENT	732
361	6	8471315018	11203	SENT	693
362	6	8565949539	11204	SENT	797
363	6	6769353525	11192	SENT	798
364	6	6346924303	11191	SENT	828
365	6	7490793146	11194	SENT	147
366	6	7472855075	11190	SENT	179
383	6	7293629051	11221	SENT	454
827	6	7195029425	11663	SENT	580
828	6	7018221713	11662	SENT	581
829	6	6408197699	11668	SENT	786
830	6	7091331892	11664	SENT	582
831	6	6588223613	11676	SENT	787
832	6	8498235621	11666	SENT	583
833	6	8107450501	11667	SENT	788
834	6	8162704132	11665	SENT	584
835	6	7800678139	11681	SENT	600
836	6	7672696820	11669	SENT	591
837	6	1350241293	11673	SENT	588
838	6	916452371	11670	SENT	602
839	6	7855055693	11671	SENT	589
840	6	1391604133	11675	SENT	604
841	6	8282971952	11672	SENT	590
847	6	1069618544	11682	SENT	595
848	6	7974183527	11688	SENT	789
849	6	8385366235	11696	SENT	596
850	6	1283310992	11683	SENT	603
851	6	2088580170	11685	SENT	608
852	6	1500199751	11687	SENT	597
853	6	1673513385	11692	SENT	598
854	6	1126913612	11693	SENT	609
855	6	6330812062	11690	SENT	611
856	6	7604284279	11686	SENT	612
857	6	1337990151	11691	SENT	614
858	6	1828274009	11684	SENT	593
859	6	494365884	11694	SENT	615
860	6	780723842	11701	SENT	618
861	6	5164550236	11700	SENT	620
862	6	509319013	11697	SENT	621
867	6	761481167	11702	SENT	629
868	6	255376395	11704	SENT	630
869	6	7360577294	11703	SENT	631
870	6	485045145	11708	SENT	633
871	6	6268271665	11705	SENT	635
872	6	5192559473	11707	SENT	637
873	6	8241602716	11709	SENT	639
874	6	281014544	11711	SENT	643
875	6	5742548647	11715	SENT	644
876	6	6664864212	11710	SENT	646
877	6	6411014685	11706	SENT	650
878	6	320231603	11713	SENT	651
879	6	7350620147	11718	SENT	652
880	6	887017110	11717	SENT	653
881	6	7755964210	11720	SENT	654
882	6	8215202594	11719	SENT	657
887	6	1029563012	11726	SENT	843
888	6	6964140786	11722	SENT	886
889	6	465784461	11733	SENT	2
890	6	7133535965	11725	SENT	848
891	6	883048779	11723	SENT	699
892	6	7400410400	11738	SENT	845
893	6	8751699166	11734	SENT	860
894	6	6764064054	11724	SENT	862
895	6	731175585	11728	SENT	868
896	6	5478660660	11730	SENT	876
897	6	6942038979	11741	SENT	880
898	6	5148232689	11727	SENT	882
899	6	702329152	11729	SENT	844
900	6	287221365	11732	SENT	6
901	6	1748186781	11739	SENT	586
902	6	5165656284	11740	SENT	852
907	6	8649242665	11746	SENT	877
908	6	523781269	11749	SENT	5
909	6	887602580	11743	SENT	887
910	6	415662533	11750	SENT	793
911	6	8694347942	11742	SENT	24
912	6	1869012621	11751	SENT	587
913	6	7388690934	11745	SENT	891
914	6	7151220198	11752	SENT	849
915	6	5770084734	11744	SENT	896
916	6	6546168168	11753	SENT	863
917	6	8355507541	11756	SENT	866
918	6	8215599980	11754	SENT	870
919	6	8801320487	\N	FAILED	874
920	6	5839065733	11755	SENT	878
921	6	8096535121	11747	SENT	881
922	6	2085723465	11748	SENT	884
927	6	8572141190	11763	SENT	864
928	6	8997925575	11767	SENT	867
929	6	7974909704	11765	SENT	871
930	6	895474770	11766	SENT	875
931	6	286183586	11768	SENT	879
932	6	6152569431	11762	SENT	885
933	6	1178178774	11761	SENT	892
934	6	473315171	11764	SENT	1
384	6	7062738644	11223	SENT	513
385	6	5417439348	11209	SENT	681
386	6	7639895295	\N	FAILED	800
403	6	7283414970	11227	SENT	236
404	6	7409273983	11241	SENT	240
405	6	7368778364	11243	SENT	292
406	6	7496160754	11242	SENT	299
423	6	7136075143	11257	SENT	415
424	6	7427713419	11263	SENT	474
425	6	6676859774	11259	SENT	738
426	6	7256065839	11262	SENT	803
443	6	7969421911	11278	SENT	805
444	6	7223140853	11281	SENT	156
445	6	7439303716	11282	SENT	193
446	6	6900366567	11279	SENT	244
463	6	7379485576	11300	SENT	246
464	6	6926342074	11299	SENT	305
465	6	7166756544	11303	SENT	364
466	6	7390082222	11298	SENT	423
483	6	7153350558	11317	SENT	198
484	6	7463637838	11321	SENT	249
485	6	7185243080	11318	SENT	308
486	6	7026555924	11322	SENT	367
494	6	7073182162	11335	SENT	309
495	6	6880573207	11332	SENT	368
496	6	6659987306	11333	SENT	427
497	6	7311651807	11339	SENT	486
498	6	7949213444	11329	SENT	748
499	6	6788822166	11338	SENT	163
500	6	7394823778	11326	SENT	200
501	6	7341060537	11334	SENT	251
502	6	7376133712	11340	SENT	310
503	6	7431524586	11337	SENT	369
504	6	7346778778	11342	SENT	428
505	6	7431546240	11336	SENT	487
506	6	6885423909	11341	SENT	749
517	6	6676685293	11361	SENT	165
518	6	6647497786	11355	SENT	202
519	6	7251793091	11356	SENT	253
520	6	6737551380	11357	SENT	312
521	6	7252467539	11360	SENT	371
522	6	7415443356	11358	SENT	430
523	6	7445590293	11359	SENT	489
524	6	5406848018	11347	SENT	751
525	6	547092424	11348	SENT	815
526	6	7206411290	11346	SENT	166
543	6	7041721969	11380	SENT	168
544	6	7174001640	11382	SENT	205
545	6	7145794716	11379	SENT	256
546	6	7314028676	11381	SENT	315
563	6	7297212697	11401	SENT	257
564	6	7046446556	11402	SENT	263
565	6	7422975458	11398	SENT	268
566	6	7304272418	11400	SENT	270
583	6	7401889730	11407	SENT	445
584	6	7473642120	11406	SENT	447
585	6	7225128574	11418	SENT	448
586	6	7118147405	11420	SENT	450
603	6	7050217553	11438	SENT	213
604	6	6996892564	11442	SENT	215
605	6	7339664840	11437	SENT	216
606	6	7060725312	11439	SENT	218
623	6	7492081714	11452	SENT	264
624	6	7224885382	11457	SENT	266
625	6	7450519923	11458	SENT	267
626	6	7216267040	11460	SENT	269
643	6	7001618168	11477	SENT	294
644	6	7186646131	11475	SENT	295
645	6	7401129411	11482	SENT	297
646	6	7297179962	11481	SENT	301
651	6	7373995699	11490	SENT	323
652	6	7274312327	11496	SENT	325
653	6	5155080588	11493	SENT	326
654	6	7250506501	11491	SENT	385
655	6	7256806485	11486	SENT	444
656	6	7419121243	11502	SENT	503
657	6	7097624059	11494	SENT	328
658	6	7384759645	11495	SENT	387
659	6	6942709232	11498	SENT	446
660	6	6304941998	11489	SENT	505
661	6	7468010344	11501	SENT	331
662	6	7034119483	11500	SENT	390
663	6	7381145937	11488	SENT	449
664	6	7287003838	11487	SENT	508
665	6	8288903567	11499	SENT	758
666	6	7495540807	11497	SENT	333
679	6	675794841	11519	SENT	761
680	6	7154852056	11516	SENT	339
681	6	1469153541	11515	SENT	398
682	6	6428401153	11517	SENT	457
683	6	7383184988	11521	SENT	516
684	6	7185062327	11522	SENT	340
685	6	7095580222	11507	SENT	399
686	6	7446429372	11508	SENT	458
703	6	6824852392	11539	SENT	344
704	6	7012629137	11538	SENT	403
705	6	7289375783	11542	SENT	462
706	6	7419850022	11540	SENT	521
723	6	5313599796	11555	SENT	773
724	6	7243825400	11559	SENT	349
725	6	7280187785	11562	SENT	408
726	6	6853150279	11561	SENT	467
743	6	7290974807	11578	SENT	355
744	6	7135579755	11580	SENT	414
745	6	7361827579	11579	SENT	473
746	6	7293495542	11581	SENT	360
763	6	6419629922	11601	SENT	439
764	6	7361469081	11595	SENT	498
765	6	8275047119	11598	SENT	784
766	6	7264732300	11600	SENT	382
784	6	6461777900	11606	SENT	537
785	6	7983414106	11604	SENT	538
786	6	6706211091	11608	SENT	539
803	6	7080463218	11633	SENT	556
804	6	8376046597	11636	SENT	557
805	6	7164256686	11635	SENT	558
806	6	8084408762	11641	SENT	559
808	6	7149529652	11647	SENT	561
809	6	7933045332	11645	SENT	562
810	6	6684017436	11648	SENT	563
811	6	8254035931	11644	SENT	564
812	6	6502292993	11649	SENT	565
813	6	7293674242	11646	SENT	566
814	6	6963098061	11659	SENT	567
815	6	6831880540	11651	SENT	568
816	6	8571110267	11643	SENT	569
817	6	7983605104	11658	SENT	570
818	6	7298974125	11650	SENT	571
819	6	7053514879	11654	SENT	572
820	6	7242206399	11660	SENT	573
821	6	7054013745	11652	SENT	574
822	6	7030287724	11661	SENT	575
823	6	7001124531	11657	SENT	576
824	6	8373230461	11655	SENT	577
825	6	7192492417	11653	SENT	578
826	6	5117923037	11656	SENT	579
842	6	6307415263	11674	SENT	605
843	6	527518219	11677	SENT	606
844	6	1091125294	11679	SENT	592
845	6	6765325326	11678	SENT	607
846	6	5579251958	11680	SENT	594
863	6	5566793783	11698	SENT	623
864	6	628021852	11699	SENT	625
865	6	5403644730	11695	SENT	627
866	6	1338122293	11689	SENT	628
883	6	6423801290	11721	SENT	658
884	6	1100663269	11712	SENT	659
885	6	5769471083	11716	SENT	660
886	6	5133983597	11714	SENT	661
903	6	1074834722	11737	SENT	857
904	6	8728809415	11731	SENT	861
905	6	6601748619	11736	SENT	677
906	6	8412209882	11735	SENT	873
923	6	1154744011	11757	SENT	847
924	6	5689271324	11760	SENT	850
925	6	1658016034	11758	SENT	853
926	6	7981061131	11759	SENT	856
\.


--
-- Data for Name: broadcasts; Type: TABLE DATA; Schema: public; Owner: remnashop
--

COPY public.broadcasts (id, task_id, status, audience, total_count, success_count, failed_count, payload, created_at, updated_at) FROM stdin;
6	65306193-c584-419f-a185-fa9a675d09a0	COMPLETED	ALL	788	783	5	{"media": null, "i18n_key": "raw-message", "media_type": null, "i18n_kwargs": {"content": "🚀 <b>Новый личный кабинет Begemot VPN</b>\\nТеперь управлять подпиской стало проще.\\n🌐 <b>cabinet.begemot.cc</b> работает <b>без VPN</b>, поэтому вы всегда сможете:\\n✅ Продлить подписку\\n✅ Купить новый тариф\\n✅ Оплатить доступ самостоятельно\\n✅ Восстановить доступ даже без Telegram\\nБольше не нужно искать бота или ждать ответа поддержки. Достаточно открыть сайт, выбрать тариф и оплатить его — доступ активируется автоматически.\\n🔗 <b>cabinet.begemot.cc</b>\\n<b>Безопасный интернет должен быть доступен всегда.</b> 🦛"}, "delete_after": null, "reply_markup": null, "message_effect": null, "disable_notification": false, "disable_default_markup": false}	2026-06-23 19:23:32.965429+00	2026-06-23 19:23:56.877067+00
\.


--
-- Data for Name: payment_gateways; Type: TABLE DATA; Schema: public; Owner: remnashop
--

COPY public.payment_gateways (id, order_index, type, currency, is_active, settings) FROM stdin;
8	9	MULENPAY	RUB	f	{"type": "MULENPAY", "api_key": null, "shop_id": null, "vat_code": null, "secret_key": null}
9	10	PAYMASTER	RUB	f	{"type": "PAYMASTER", "api_key": null, "merchant_id": null}
10	11	PLATEGA	RUB	t	{"type": "PLATEGA", "api_key": "enc_gAAAAABp50NBClzLc8be4WJSroJded4g3fbPu-nX_BkNgOP7d9bi0d2FeNv3xT0mkekAIue19CC19HVKfdfNmlak8jAjT6D26CUbVgx1ENfKG7AL75n9UTB-eauie0WkIBfCU-MkOeNgqWcTMef6SwzcNn6y0lVaNB_UDXHt6vsJiW45JgM-HsQwV77RmhlBAZ39UKKOjNW2QLzmffw3iosvfys_XArEjw==", "merchant_id": "d15e7e19-6d5b-40c8-b5dc-96f2b298f8a7", "payment_method": 2}
11	12	ROBOKASSA	RUB	f	{"type": "ROBOKASSA", "password1": null, "password2": null, "merchant_login": null}
12	13	URLPAY	RUB	f	{"type": "URLPAY", "api_key": null, "shop_id": null, "vat_code": null, "secret_key": null}
13	14	WATA	RUB	f	{"type": "WATA", "api_key": null}
1	1	TELEGRAM_STARS	XTR	t	{"type": "TELEGRAM_STARS", "display_name": null}
14	4	VALUTIX	RUB	f	{"type": "VALUTIX", "api_key": null, "display_name": null}
5	6	HELEKET	USD	t	{"type": "HELEKET", "api_key": "enc_gAAAAABp4ieNwncenK9rfAwmVCCZAwqGS3vmFpcI8Xbw2E3TAZnaXGC5PF0eU53uibAxoN_hfGbIMyfbiuik6EAgZHadHdzG2x3pk93HgUAHoiqKrC-W7ZhGc7xsgtVlkOqvgsZUdIWc8yzO7F3DpKp0dQfP60ZClDs_2F0i_BXvlJGCKw7zjn8KZGtwGZ7HO0RN2fJvWRVjHich3GdIpHqt96OoBTExqyrIRwk-lcZDHSa_OSRjANgwUNcAEpPT0-IXiNWWtifC", "merchant_id": "72ca0139-8626-4432-a59f-70b09d3b948e"}
3	3	YOOMONEY	RUB	t	{"type": "YOOMONEY", "wallet_id": "4100119508468667", "secret_key": "enc_gAAAAABqDpIMUEDRZ9BHYDyphNuohgDDqn4Zdd8GMoC8zX0uTb9nFhmV0YKNRmP0jb_xBbj61_uW_XavN2rvrrMl2bemwFilzOQH_Dqaz4B0b_k7xMSMYGg="}
4	5	CRYPTOMUS	USD	f	{"type": "CRYPTOMUS", "api_key": null, "merchant_id": null}
6	7	CRYPTOPAY	USD	f	{"type": "CRYPTOPAY", "api_key": null}
7	8	FREEKASSA	RUB	f	{"type": "FREEKASSA", "api_key": "enc_gAAAAABp5KktzSawroHvaHJC6AGoLRPNpGHmFQ3CKujhHqWtxocIhim_BkmoxEzYVB36MHjzLkYfEc2q3aqNUtle4QtI5rjiuqDgxjSwhExvd_AmPgh3RtLdIpQqRWe_rJmUqfUDzLV7", "shop_id": 72303, "customer_ip": "35,44", "secret_word_2": "enc_gAAAAABp575xF_2fUo-KbcJwWakFVHOAcj37N7CAU8nR8Zoo0_eXOXvqmxtcFqBUc-4C-j3378lcZ3i1wH0i4pOSYRbuvg6Bog==", "customer_email": "alex161rus2020@yandex.ru", "payment_system_id": 1}
2	2	YOOKASSA	RUB	f	{"type": "YOOKASSA", "api_key": null, "shop_id": "Ryuiee", "customer": null, "vat_code": null}
\.


--
-- Data for Name: plan_durations; Type: TABLE DATA; Schema: public; Owner: remnashop
--

COPY public.plan_durations (id, days, plan_id, order_index) FROM stdin;
423	30	12	1
424	60	12	2
425	90	12	3
426	180	12	4
427	365	12	5
428	30	13	1
429	60	13	2
430	90	13	3
431	180	13	4
432	365	13	5
438	30	15	1
439	60	15	2
440	90	15	3
441	180	15	4
442	365	15	5
293	3	11	0
294	30	10	0
295	60	10	0
296	7	6	0
458	30	14	1
459	60	14	2
460	90	14	3
461	180	14	4
462	365	14	5
482	30	16	1
483	60	16	2
484	90	16	3
485	180	16	4
486	365	16	5
487	30	18	1
488	60	18	2
489	90	18	3
490	180	18	4
491	365	18	5
\.


--
-- Data for Name: plan_prices; Type: TABLE DATA; Schema: public; Owner: remnashop
--

COPY public.plan_prices (id, currency, price, plan_duration_id) FROM stdin;
1267	USD	1.59	423
1268	XTR	72.00	423
1269	RUB	129.00	423
1270	USD	2.99	424
1271	XTR	136.00	424
1272	RUB	239.00	424
1273	USD	4.29	425
1274	XTR	200.00	425
1275	RUB	349.00	425
1276	USD	7.99	426
1277	XTR	376.00	426
1278	RUB	659.00	426
1279	USD	14.99	427
1280	XTR	714.00	427
1281	RUB	1249.00	427
1282	USD	2.99	428
1283	XTR	136.00	428
1284	RUB	239.00	428
1285	USD	5.49	429
1286	XTR	256.00	429
1287	RUB	449.00	429
1288	USD	7.99	430
1289	XTR	364.00	430
1290	RUB	639.00	430
1291	USD	14.99	431
1292	XTR	690.00	431
1293	RUB	1209.00	431
1294	USD	27.99	432
1295	XTR	1312.00	432
1296	RUB	2299.00	432
1372	USD	4.29	458
1373	XTR	194.00	458
1374	RUB	339.00	458
1375	USD	7.99	459
1376	XTR	370.00	459
1377	RUB	649.00	459
1378	USD	11.49	460
1379	XTR	530.00	460
1380	RUB	929.00	460
1381	USD	21.99	461
1382	XTR	1004.00	461
1383	RUB	1759.00	461
1384	USD	41.99	462
1385	XTR	1912.00	462
1386	RUB	3349.00	462
1312	USD	5.49	438
1313	XTR	252.00	438
1314	RUB	439.00	438
1315	USD	10.49	439
1316	XTR	480.00	439
1317	RUB	839.00	439
1318	USD	14.99	440
1319	XTR	684.00	440
1320	RUB	1199.00	440
1321	USD	27.99	441
1322	XTR	1300.00	441
1323	RUB	2279.00	441
1324	USD	53.99	442
1325	XTR	2484.00	442
1326	RUB	4349.00	442
877	USD	0.20	293
878	XTR	6.00	293
879	RUB	10.00	293
880	USD	7.50	294
881	XTR	400.00	294
882	RUB	600.00	294
883	USD	15.00	295
884	XTR	800.00	295
885	RUB	1200.00	295
886	USD	0.01	296
887	XTR	0.00	296
888	RUB	2.00	296
1444	USD	6.49	482
1445	XTR	298.00	482
1446	RUB	519.00	482
1447	USD	12.49	483
1448	XTR	570.00	483
1449	RUB	999.00	483
1450	USD	17.99	484
1451	XTR	822.00	484
1452	RUB	1439.00	484
1453	USD	33.99	485
1454	XTR	1564.00	485
1455	RUB	2739.00	485
1456	USD	64.99	486
1457	XTR	3000.00	486
1458	RUB	5249.00	486
1459	USD	9.99	487
1460	XTR	456.00	487
1461	RUB	799.00	487
1462	USD	18.99	488
1463	XTR	856.00	488
1464	RUB	1499.00	488
1465	USD	26.99	489
1466	XTR	1228.00	489
1467	RUB	2149.00	489
1468	USD	50.99	490
1469	XTR	2342.00	490
1470	RUB	4099.00	490
1471	USD	99.99	491
1472	XTR	4570.00	491
1473	RUB	7999.00	491
\.


--
-- Data for Name: plans; Type: TABLE DATA; Schema: public; Owner: remnashop
--

COPY public.plans (id, order_index, is_active, type, availability, name, traffic_limit, device_limit, allowed_telegram_ids, internal_squads, created_at, updated_at, description, tag, traffic_limit_strategy, external_squad, is_trial, public_code, allowed_emails) FROM stdin;
12	4	t	DEVICES	ALL	👤 SOLO · 1 📱	0	1	{}	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-04-27 12:13:12.817009+00	2026-04-28 14:46:00.516924+00	1 устройство	\N	NO_RESET	\N	f	c1SCzWMn	{}
13	5	t	DEVICES	ALL	👥 DUO · 2 📱 − выгоднее	0	2	{}	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-04-27 12:13:12.842995+00	2026-04-28 14:46:20.985792+00	2 устройства	\N	NO_RESET	\N	f	IieQAL69	{}
11	1	t	BOTH	NEW	Пробный период	5	1	{}	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-04-27 10:00:50.787198+00	2026-04-27 12:13:36.801038+00	\N	\N	NO_RESET	\N	t	bbhOJxSH	{}
15	7	t	DEVICES	ALL	👨‍👩‍👧 FAMILY · 4 📱	0	4	{}	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-04-27 12:13:12.881072+00	2026-04-28 14:47:05.955326+00	4 устройства	\N	NO_RESET	\N	f	h2f4YqgO	{}
14	6	t	DEVICES	ALL	🏠 HOME · 3 📱 ⭐ Хит	0	3	{}	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-04-27 12:13:12.863174+00	2026-04-28 14:49:29.372711+00	3 устройства · самый популярный тариф	\N	NO_RESET	\N	f	RVBQESQH	{}
16	8	t	DEVICES	ALL	🧑‍💻 TEAM · 5 📱 максимум выгоды🔥	0	5	{}	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-04-27 12:13:12.897544+00	2026-05-20 19:22:20.506058+00	5 устройств · максимум выгоды	\N	NO_RESET	\N	f	LmavhByb	{}
18	9	t	DEVICES	ALL	🚀 UNLIMITED · до 10 📱	0	10	{}	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-04-27 12:21:37.40566+00	2026-05-20 19:22:20.506058+00	До 10 устройств · максимум возможностей	BEST_VALUE	NO_RESET	\N	f	bqk36wdL	{}
10	2	t	DEVICES	ALLOWED	Канатбек	0	7	{1301243503}	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-04-27 06:56:43.895609+00	2026-04-27 12:13:36.801038+00	\N	\N	NO_RESET	\N	f	uwAMmn9A	{}
6	3	f	BOTH	ALLOWED	Тест	100	1	{473315171}	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-04-19 06:16:00.947639+00	2026-04-27 12:13:36.801038+00	\N	\N	NO_RESET	\N	f	x1U9u0vE	{}
\.


--
-- Data for Name: promocode_activations; Type: TABLE DATA; Schema: public; Owner: remnashop
--

COPY public.promocode_activations (id, promocode_id, user_id, activated_at) FROM stdin;
\.


--
-- Data for Name: promocodes; Type: TABLE DATA; Schema: public; Owner: remnashop
--

COPY public.promocodes (id, code, is_active, reward_type, reward, plan_snapshot, availability, expires_at, max_activations, created_at, updated_at, is_reusable) FROM stdin;
\.


--
-- Data for Name: referral_rewards; Type: TABLE DATA; Schema: public; Owner: remnashop
--

COPY public.referral_rewards (id, referral_id, type, amount, is_issued, created_at, updated_at, user_id) FROM stdin;
\.


--
-- Data for Name: referrals; Type: TABLE DATA; Schema: public; Owner: remnashop
--

COPY public.referrals (id, level, created_at, updated_at, referrer_id, referred_id) FROM stdin;
1	FIRST	2026-04-28 11:18:51.447201+00	2026-04-28 11:18:51.447201+00	619	717
2	FIRST	2026-05-01 15:31:10.905045+00	2026-05-01 15:31:10.905045+00	586	765
3	FIRST	2026-05-03 15:23:12.613259+00	2026-05-03 15:23:12.613259+00	797	798
4	FIRST	2026-05-31 17:01:04.783852+00	2026-05-31 17:01:04.783852+00	610	857
\.


--
-- Data for Name: settings; Type: TABLE DATA; Schema: public; Owner: remnashop
--

COPY public.settings (id, default_currency, referral, access, requirements, notifications, menu, created_at, updated_at, backup, blacklist, extra) FROM stdin;
1	RUB	{"level": 2, "enable": true, "reward": {"type": "POINTS", "config": {"1": 7, "2": 14}, "strategy": "AMOUNT"}, "accrual_strategy": "ON_EACH_PAYMENT"}	{"mode": "PUBLIC", "payments_allowed": true, "registration_allowed": true}	{"channel_id": null, "rules_link": "https://telegra.ph/Begemot-04-18-3", "channel_link": "https://t.me/begemot_vpn_channel", "rules_required": true, "channel_required": false}	{"routes": {}, "settings": {"SYSTEM": true, "EXPIRED": true, "LIMITED": true, "BOT_UPDATE": true, "SUBSCRIPTION": true, "BOT_LIFECYCLE": true, "TRIAL_ACTIVATED": true, "USER_REGISTERED": true, "EXPIRES_IN_1_DAY": true, "EXPIRED_1_DAY_AGO": true, "EXPIRES_IN_2_DAYS": true, "EXPIRES_IN_3_DAYS": true, "REFERRAL_ATTACHED": true, "NODE_STATUS_CHANGED": true, "PROMOCODE_ACTIVATED": true, "NODE_TRAFFIC_REACHED": true, "USER_DEVICES_UPDATED": true, "USER_FIRST_CONNECTION": true, "REFERRAL_REWARD_RECEIVED": true, "USER_REVOKED_SUBSCRIPTION": true}, "default_route": {"chat_id": null, "thread_id": null}}	{"buttons": [{"text": "Админка", "type": "WEB_APP", "index": 1, "payload": "https://github.com/snoups/remnashop", "is_active": false, "required_role": 4}, {"text": "Защита Happ", "type": "URL", "index": 2, "payload": "https://routing.help", "is_active": false, "required_role": 1}, {"text": "Политика кондефициальности", "type": "WEB_APP", "index": 3, "payload": "https://telegra.ph/Politika-konfidencialnosti-04-01-26", "is_active": false, "required_role": 1}, {"text": "AI-CHAT", "type": "URL", "index": 4, "payload": "https://t.me/begemot_ai_bot", "is_active": false, "required_role": 1}, {"text": "Пользовательское соглашение", "type": "WEB_APP", "index": 5, "payload": "https://telegra.ph/Polzovatelskoe-soglashenie-04-01-19", "is_active": false, "required_role": 1}, {"text": "Защита INCY", "type": "URL", "index": 6, "payload": "https://incy.routing.help/", "is_active": false, "required_role": 1}]}	2026-04-16 06:35:34.284501+00	2026-06-20 20:11:59.521996+00	{"enabled": true, "max_files": 7, "send_to_chat": true, "interval_hours": 24}	{"sources": [], "blocked_ids": []}	{}
\.


--
-- Data for Name: subscriptions; Type: TABLE DATA; Schema: public; Owner: remnashop
--

COPY public.subscriptions (id, user_remna_id, status, is_trial, traffic_limit, device_limit, internal_squads, expire_at, url, plan_snapshot, created_at, updated_at, external_squad, traffic_limit_strategy, tag, user_id, device_single_reset_at, device_all_reset_at, link_reset_at, disabled_by_channel_leave) FROM stdin;
224	e7fd3e0a-ffc3-4c76-a1cc-945b497a1862	ACTIVE	f	0	7	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-07-22 13:56:56.33+00	https://sub.begemot.cc/_uGqT2UyxKvqoXvZ	{"id": 10, "tag": null, "name": "Канатбек", "type": "DEVICES", "duration": 30, "is_trial": false, "device_limit": 7, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-05-16 13:56:56.319497+00	2026-06-22 06:24:52.353817+00	\N	NO_RESET	\N	3	\N	\N	\N	f
279	44d0a446-001c-4ca6-b08e-2110428b86ef	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-06-26 12:52:34.677+00	https://sub.begemot.cc/U5fjKDB3eX8A1C_G	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b"], "traffic_limit_strategy": "NO_RESET"}	2026-06-23 12:52:34.662063+00	2026-06-26 12:53:00.105315+00	\N	NO_RESET	\N	793	\N	\N	\N	f
281	91302088-d808-4d72-b132-884651ffa7c5	ACTIVE	f	0	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-07-26 15:44:37.741+00	https://sub.begemot.cc/fqRTRd2YeFgz37um	{"id": 12, "tag": null, "name": "👤 SOLO · 1 📱", "type": "DEVICES", "duration": 30, "is_trial": false, "device_limit": 1, "traffic_limit": 0, "external_squad": null, "internal_squads": ["f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b"], "traffic_limit_strategy": "NO_RESET"}	2026-06-26 15:44:37.730632+00	2026-06-26 15:44:37.730632+00	\N	NO_RESET	\N	903	\N	\N	\N	f
1	b6d48bc2-5e7b-4cce-80b5-c6d50e1fa180	DELETED	f	10	1	{7d3c2f79-92d4-4384-b5e0-4dadb7cda374}	2026-04-23 17:22:12.175+00	https://sub.begemot.cc/oDRTReG3CXd_zpgy	{"id": 3, "tag": "23", "name": "Пробный период", "type": "BOTH", "duration": 7, "is_trial": false, "device_limit": 1, "traffic_limit": 10, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-16 17:22:12.162056+00	2026-04-16 17:25:29.154517+00	\N	NO_RESET	23	1	\N	\N	\N	f
282	4f374fac-59d9-4a92-a5a2-2f94c0a4742f	ACTIVE	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-06-30 03:52:42.547+00	https://sub.begemot.cc/wso3_YJSF_h1d9N1	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b"], "traffic_limit_strategy": "NO_RESET"}	2026-06-27 03:52:42.493355+00	2026-06-27 03:52:42.493355+00	\N	NO_RESET	\N	894	\N	\N	\N	f
3	dc290af8-5e6a-471e-9034-2bc579b1d09d	DELETED	f	0	0	{7d3c2f79-92d4-4384-b5e0-4dadb7cda374}	2099-04-16 14:12:48+00	https://sub.begemot.cc/uxQXFm_0p6mf2n6s	{"id": -1, "tag": null, "name": "IMPORTED", "type": "UNLIMITED", "duration": 0, "is_trial": false, "device_limit": 0, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-16 18:40:48.164868+00	2026-04-17 16:33:35.551323+00	\N	NO_RESET	\N	2	\N	\N	\N	f
232	802edd51-a120-4326-8026-6eed75738631	ACTIVE	f	0	3	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-08-17 15:48:12.259+00	https://sub.begemot.cc/WjkQP730tPopRKrP	{"id": 14, "tag": null, "name": "🏠 HOME · 3 📱 ⭐ Хит", "type": "DEVICES", "duration": 90, "is_trial": false, "device_limit": 3, "traffic_limit": 0, "external_squad": null, "internal_squads": ["f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b"], "traffic_limit_strategy": "NO_RESET"}	2026-05-19 15:48:12.255809+00	2026-05-19 15:48:12.255809+00	\N	NO_RESET	\N	6	\N	\N	\N	f
23	2169cfa2-3059-4c11-8763-56bd0f25fe25	DELETED	f	0	1	{7d3c2f79-92d4-4384-b5e0-4dadb7cda374}	2026-05-18 17:23:28.526+00	https://sub.begemot.cc/bmw_nkLTnbSbqcRr	{"id": 1, "tag": null, "name": "Персональный", "type": "DEVICES", "duration": 30, "is_trial": false, "device_limit": 1, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-18 17:23:28.517334+00	2026-05-14 06:19:15.524432+00	\N	NO_RESET	\N	15	\N	\N	\N	f
21	dd3a25f5-81e9-4b82-bc9d-3cc74939ad1c	ACTIVE	f	0	1	{7d3c2f79-92d4-4384-b5e0-4dadb7cda374}	2026-05-18 15:52:20.764+00	https://sub.begemot.cc/vTAwCYq_1hUjcwbP	{"id": 1, "tag": null, "name": "Персональный", "type": "DEVICES", "duration": 14, "is_trial": false, "device_limit": 1, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-18 15:52:16.881211+00	2026-04-18 15:52:20.813985+00	\N	NO_RESET	\N	5	\N	\N	\N	f
25	c8840626-42b2-4f91-9ccb-a9ac29720ed4	ACTIVE	f	0	1	{7d3c2f79-92d4-4384-b5e0-4dadb7cda374}	2026-05-19 12:45:01.925+00	https://sub.begemot.cc/xvkgmjpo6WVSZgHw	{"id": 1, "tag": null, "name": "Персональный", "type": "DEVICES", "duration": 30, "is_trial": false, "device_limit": 1, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-19 12:45:01.908741+00	2026-04-19 14:25:02.825308+00	\N	NO_RESET	\N	26	\N	\N	\N	f
280	97ec6e92-34b4-46e8-a626-7b863e0d879e	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-06-27 06:39:14.713+00	https://sub.begemot.cc/aNCTxBUHWA4EP12N	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b"], "traffic_limit_strategy": "NO_RESET"}	2026-06-24 06:39:14.702681+00	2026-06-27 06:39:30.083823+00	\N	NO_RESET	\N	877	\N	\N	\N	f
26	6a16dcc2-2ec5-4e13-b9d8-35d504d8e999	ACTIVE	f	0	0	{7d3c2f79-92d4-4384-b5e0-4dadb7cda374}	2026-04-26 13:23:56.091+00	https://sub.begemot.cc/Bm76uYGD1jqATyv5	{"id": 6, "tag": null, "name": "Тест", "type": "BOTH", "duration": 7, "is_trial": false, "device_limit": 1, "traffic_limit": 100, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-19 13:23:55.998255+00	2026-04-19 19:52:54.758276+00	\N	NO_RESET	\N	1	\N	\N	\N	f
231	b8abf8f0-4e4d-4cd5-9d03-c4e2f3981cc0	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-05-22 15:37:09.639+00	https://sub.begemot.cc/eWVzVBTLSNBwF8Q0	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b"], "traffic_limit_strategy": "NO_RESET"}	2026-05-19 15:37:09.63544+00	2026-05-22 15:37:30.064809+00	\N	NO_RESET	\N	24	\N	\N	\N	f
33	6a16dcc2-2ec5-4e13-b9d8-35d504d8e999	ACTIVE	f	0	3	{7d3c2f79-92d4-4384-b5e0-4dadb7cda374}	2027-04-20 06:22:41.826+00	https://sub.begemot.cc/Bm76uYGD1jqATyv5	{"id": 2, "tag": null, "name": "Семейный 3 📱", "type": "DEVICES", "duration": 365, "is_trial": false, "device_limit": 3, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-20 06:22:41.801162+00	2026-04-20 06:22:41.801162+00	\N	NO_RESET	\N	1	\N	\N	\N	f
234	29e6195e-7af9-43b8-bbda-d16008330ca4	ACTIVE	f	0	2	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-07-18 19:20:26.977+00	https://sub.begemot.cc/w2CY2uNgKSvfnA9B	{"id": 13, "tag": null, "name": "👥 DUO · 2 📱 − выгоднее", "type": "DEVICES", "duration": 60, "is_trial": false, "device_limit": 2, "traffic_limit": 0, "external_squad": null, "internal_squads": ["f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b"], "traffic_limit_strategy": "NO_RESET"}	2026-05-19 19:20:26.971613+00	2026-05-19 19:20:26.971613+00	\N	NO_RESET	\N	587	\N	\N	\N	f
14	b903036e-b1f0-436a-b9e0-ce0750dbd7c0	DELETED	t	10	1	{7d3c2f79-92d4-4384-b5e0-4dadb7cda374}	2026-04-24 09:18:44.026+00	https://sub.begemot.cc/ULb0Hwkc_bxqWeKy	{"id": 3, "tag": "23", "name": "Пробный период", "type": "BOTH", "duration": 7, "is_trial": true, "device_limit": 1, "traffic_limit": 10, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-17 09:18:44.01766+00	2026-04-20 14:04:54.013076+00	\N	NO_RESET	23	16	\N	\N	\N	f
47	e7fd3e0a-ffc3-4c76-a1cc-945b497a1862	ACTIVE	f	0	4	{7d3c2f79-92d4-4384-b5e0-4dadb7cda374}	2026-05-22 11:48:47.482+00	https://sub.begemot.cc/_uGqT2UyxKvqoXvZ	{"id": 8, "tag": null, "name": "Семейный 4📱", "type": "DEVICES", "duration": 30, "is_trial": false, "device_limit": 4, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-22 11:48:47.451886+00	2026-04-22 11:48:47.451886+00	\N	NO_RESET	\N	3	\N	\N	\N	f
43	29e6195e-7af9-43b8-bbda-d16008330ca4	DELETED	f	0	2	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-07-18 19:20:26.977+00	https://sub.begemot.cc/w2CY2uNgKSvfnA9B	{"id": 1, "tag": null, "name": "Персональный 📱", "type": "DEVICES", "duration": 30, "is_trial": false, "device_limit": 1, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-21 14:39:42.411536+00	2026-05-19 19:20:27.01275+00	\N	NO_RESET	\N	587	\N	\N	\N	f
51	26b8182f-51ce-4642-abd9-d82b593ca56d	DELETED	f	0	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-05-23 10:51:00.188+00	https://sub.begemot.cc/qRqzaFsd8XUuCh0E	{"id": 1, "tag": null, "name": "Личный", "type": "DEVICES", "duration": 30, "is_trial": false, "device_limit": 1, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-23 10:51:00.13191+00	2026-05-24 11:38:11.015281+00	\N	NO_RESET	\N	593	\N	\N	\N	f
46	6a16dcc2-2ec5-4e13-b9d8-35d504d8e999	DELETED	f	0	5	{7d3c2f79-92d4-4384-b5e0-4dadb7cda374}	2027-04-22 11:21:15.4+00	https://sub.begemot.cc/Bm76uYGD1jqATyv5	{"id": 9, "tag": null, "name": "Команда 5📱", "type": "DEVICES", "duration": 365, "is_trial": false, "device_limit": 5, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-22 11:21:15.388361+00	2026-04-24 16:20:45.197046+00	\N	NO_RESET	\N	1	\N	\N	\N	f
38	0da84436-bdea-49a9-94f1-6426001c350f	ACTIVE	f	0	2	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-06-19 14:25:09.684+00	https://sub.begemot.cc/XLt6oDFC5Cp883Mo	{"id": 7, "tag": null, "name": "Пара📱", "type": "BOTH", "duration": 30, "is_trial": false, "device_limit": 2, "traffic_limit": 100, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-20 13:53:02.151671+00	2026-05-20 14:25:09.714838+00	\N	NO_RESET	\N	7	\N	\N	\N	f
240	42021f09-b188-4cde-9711-2842de69befd	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-05-26 14:10:01.483+00	https://sub.begemot.cc/z6RApAAkrHQ8VdS8	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b"], "traffic_limit_strategy": "NO_RESET"}	2026-05-23 14:10:01.469688+00	2026-05-26 14:10:30.071622+00	\N	NO_RESET	\N	848	\N	\N	\N	f
253	4e48e0fa-f25b-41ea-8027-2eda8167a447	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-06-03 17:01:10.594+00	https://sub.begemot.cc/LP2C41M7_ssAE6Sq	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b"], "traffic_limit_strategy": "NO_RESET"}	2026-05-31 17:01:10.582222+00	2026-06-03 17:01:30.113508+00	\N	NO_RESET	\N	857	\N	\N	\N	f
142	37bdca58-c98a-4082-912d-5cb9b086182f	ACTIVE	f	0	3	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2027-05-23 19:20:25.446+00	https://sub.begemot.cc/Jc5f7uUwGB32en4a	{"id": 14, "tag": null, "name": "🏠 HOME · 3 📱 ⭐ Хит", "type": "DEVICES", "duration": 30, "is_trial": false, "device_limit": 3, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-29 15:17:28.015567+00	2026-05-23 19:20:25.476422+00	\N	NO_RESET	\N	586	\N	\N	\N	f
254	b4bd7958-90de-45e2-b2a1-353749206437	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-06-03 18:44:19.081+00	https://sub.begemot.cc/s4_1pEt-VeGMYtem	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b"], "traffic_limit_strategy": "NO_RESET"}	2026-05-31 18:44:19.067015+00	2026-06-03 18:44:30.053503+00	\N	NO_RESET	\N	858	\N	\N	\N	f
122	67d1617f-5189-41e4-b8b2-52f4aebdaa14	ACTIVE	f	0	10	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2027-05-20 18:04:13.309+00	https://sub.begemot.cc/VT4YE2Lw9nuUXGRe	{"id": 18, "tag": "BEST_VALUE", "name": "🚀 UNLIMITED · до 10 устройств", "type": "DEVICES", "duration": 365, "is_trial": false, "device_limit": 10, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-27 12:21:56.939386+00	2026-05-20 18:04:13.344521+00	\N	NO_RESET	BEST_VALUE	1	\N	\N	\N	f
153	eaa25f1f-d293-46e0-b5f3-3de66aa0a4fc	ACTIVE	t	0	1	{7d3c2f79-92d4-4384-b5e0-4dadb7cda374}	2026-06-02 11:42:43.589+00	https://sub.begemot.cc/LMR2rq0VGahGf23u	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-30 11:37:00.272299+00	2026-05-03 11:42:43.722921+00	\N	NO_RESET	\N	743	\N	\N	\N	f
236	67d1617f-5189-41e4-b8b2-52f4aebdaa14	ACTIVE	f	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-05-24 20:54:57.752+00	https://sub.begemot.cc/VT4YE2Lw9nuUXGRe	{"id": 18, "tag": "BEST_VALUE", "name": "🚀 UNLIMITED · до 10 📱", "type": "DEVICES", "duration": 365, "is_trial": false, "device_limit": 10, "traffic_limit": 0, "external_squad": null, "internal_squads": ["f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b"], "traffic_limit_strategy": "NO_RESET"}	2026-05-20 18:04:13.289065+00	2026-05-21 20:54:57.854068+00	\N	MONTH	BEST_VALUE	1	\N	\N	\N	f
59	c373bc68-3dd0-4738-a603-3ff53f17e1ad	ACTIVE	t	0	1	{7d3c2f79-92d4-4384-b5e0-4dadb7cda374}	2026-05-26 09:16:49.451+00	https://sub.begemot.cc/8kqBB1Q17j7TLMSz	{"id": 3, "tag": "23", "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-24 21:15:30.052778+00	2026-04-26 09:16:49.548529+00	\N	NO_RESET	\N	610	\N	\N	\N	f
267	87068e1e-07c1-4556-bc46-d53b617e3e4a	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-06-12 10:34:03.864+00	https://sub.begemot.cc/QRp0AagY20N5b2mG	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b"], "traffic_limit_strategy": "NO_RESET"}	2026-06-09 10:34:03.845962+00	2026-06-12 10:34:30.062477+00	\N	NO_RESET	\N	879	\N	\N	\N	f
242	e388b528-bf46-4eb6-ae82-034c92977575	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-05-27 08:24:56.629+00	https://sub.begemot.cc/aDtQrCs11vNVUmDB	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b"], "traffic_limit_strategy": "NO_RESET"}	2026-05-24 08:24:56.61873+00	2026-05-27 08:25:00.08691+00	\N	NO_RESET	\N	849	\N	\N	\N	f
255	3cdb1211-b7e3-426e-991c-9e93b922d1fc	ACTIVE	f	0	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-07-01 15:44:39.948+00	https://sub.begemot.cc/akM9bX2WT9od-mbz	{"id": 12, "tag": null, "name": "👤 SOLO · 1 📱", "type": "DEVICES", "duration": 30, "is_trial": false, "device_limit": 1, "traffic_limit": 0, "external_squad": null, "internal_squads": ["f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b"], "traffic_limit_strategy": "NO_RESET"}	2026-06-01 15:44:39.916358+00	2026-06-01 15:44:39.916358+00	\N	NO_RESET	\N	845	\N	\N	\N	f
268	dd3a25f5-81e9-4b82-bc9d-3cc74939ad1c	ACTIVE	f	0	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-09-09 16:32:59.332+00	https://sub.begemot.cc/vTAwCYq_1hUjcwbP	{"id": 12, "tag": null, "name": "👤 SOLO · 1 📱", "type": "DEVICES", "duration": 90, "is_trial": false, "device_limit": 1, "traffic_limit": 0, "external_squad": null, "internal_squads": ["f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b"], "traffic_limit_strategy": "NO_RESET"}	2026-06-11 16:32:59.193719+00	2026-06-11 16:32:59.193719+00	\N	NO_RESET	\N	5	\N	\N	\N	f
111	e7fd3e0a-ffc3-4c76-a1cc-945b497a1862	EXPIRED	f	0	7	{7d3c2f79-92d4-4384-b5e0-4dadb7cda374}	2026-05-13 06:57:13.757+00	https://sub.begemot.cc/_uGqT2UyxKvqoXvZ	{"id": 10, "tag": null, "name": "Канатбек", "type": "DEVICES", "duration": 30, "is_trial": false, "device_limit": 7, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-27 06:57:13.711521+00	2026-05-13 06:57:30.166607+00	\N	NO_RESET	\N	3	\N	\N	\N	f
222	dd3a25f5-81e9-4b82-bc9d-3cc74939ad1c	DELETED	f	0	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-09-09 16:32:59.332+00	https://sub.begemot.cc/vTAwCYq_1hUjcwbP	{"id": 12, "tag": null, "name": "👤 SOLO · 1 📱", "type": "DEVICES", "duration": 30, "is_trial": false, "device_limit": 1, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-05-15 16:03:57.44973+00	2026-06-11 16:32:59.460228+00	\N	NO_RESET	\N	5	\N	\N	\N	f
114	3bc9b7ff-4d67-49ea-93f1-8961192bb49a	DELETED	t	5	1	{7d3c2f79-92d4-4384-b5e0-4dadb7cda374}	2026-04-30 10:05:20.259+00	https://sub.begemot.cc/v3Je1HzW29qngovN	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-27 10:05:20.247987+00	2026-04-27 10:06:05.353054+00	\N	NO_RESET	\N	24	\N	\N	\N	f
276	353c433b-58f5-4e64-95f1-75cc0ac68232	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-06-20 19:20:44.888+00	https://sub.begemot.cc/bPo96W1Z5-YJNJp-	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b"], "traffic_limit_strategy": "NO_RESET"}	2026-06-17 19:20:44.878386+00	2026-06-20 19:21:00.211372+00	\N	NO_RESET	\N	885	\N	\N	\N	f
277	e7a6f331-4b02-4922-af55-613c5a8a69ea	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-06-21 10:26:57.471+00	https://sub.begemot.cc/e36HzCa7TaLm3XLU	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b"], "traffic_limit_strategy": "NO_RESET"}	2026-06-18 10:26:57.466997+00	2026-06-21 10:27:00.181191+00	\N	NO_RESET	\N	886	\N	\N	\N	f
244	df49488c-f1b9-4af6-bfeb-ddb5f756c364	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-05-27 11:31:40.187+00	https://sub.begemot.cc/owrwjSJgb8PdcStY	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b"], "traffic_limit_strategy": "NO_RESET"}	2026-05-24 11:31:40.174394+00	2026-05-27 11:32:00.085129+00	\N	NO_RESET	\N	851	\N	\N	\N	f
257	78940403-f2da-43ba-a3f3-28efffa54177	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-06-05 07:53:57.778+00	https://sub.begemot.cc/U6oRgLqZXcg0yz_V	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b"], "traffic_limit_strategy": "NO_RESET"}	2026-06-02 07:53:57.769183+00	2026-06-05 07:54:00.092118+00	\N	NO_RESET	\N	863	\N	\N	\N	f
274	cd665a1b-dbd7-41dd-989a-8d326e5ed519	ACTIVE	f	0	2	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-12-14 06:14:39.882+00	https://sub.begemot.cc/C80QDXeAusXBVSup	{"id": 13, "tag": null, "name": "👥 DUO · 2 📱 − выгоднее", "type": "DEVICES", "duration": 180, "is_trial": false, "device_limit": 2, "traffic_limit": 0, "external_squad": null, "internal_squads": ["f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b"], "traffic_limit_strategy": "NO_RESET"}	2026-06-17 06:14:39.85623+00	2026-06-17 06:14:39.85623+00	\N	NO_RESET	\N	10	\N	\N	\N	f
138	c95df7a4-c61a-4959-a2b2-758be3f6a438	ACTIVE	t	0	1	{7d3c2f79-92d4-4384-b5e0-4dadb7cda374}	2026-05-30 07:29:36.325+00	https://sub.begemot.cc/CDqQtvH2Qe7z5J8S	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-29 00:27:32.689745+00	2026-04-30 07:29:36.444272+00	\N	NO_RESET	\N	728	\N	\N	\N	f
185	eaa25f1f-d293-46e0-b5f3-3de66aa0a4fc	EXPIRED	f	0	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-06-02 11:42:43.589+00	https://sub.begemot.cc/LMR2rq0VGahGf23u	{"id": 12, "tag": null, "name": "👤 SOLO · 1 📱", "type": "DEVICES", "duration": 30, "is_trial": false, "device_limit": 1, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-05-03 11:42:43.440102+00	2026-06-02 11:43:00.097549+00	\N	NO_RESET	\N	743	\N	\N	\N	f
209	16387dfb-1bda-4c97-98eb-30f329facb73	DELETED	t	5	1	{7d3c2f79-92d4-4384-b5e0-4dadb7cda374}	2026-05-12 18:21:38.484+00	https://sub.begemot.cc/Yhx5_kEr9Dy96gc9	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-05-09 18:21:38.456465+00	2026-05-11 18:37:23.494156+00	\N	NO_RESET	\N	603	\N	\N	\N	f
32	52cb1c2d-afbf-4343-9bc2-6c30f98fdd33	DELETED	f	0	3	{7d3c2f79-92d4-4384-b5e0-4dadb7cda374}	2026-06-17 05:52:04.689+00	https://sub.begemot.cc/Kua42QjcE9wHtFqa	{"id": 2, "tag": null, "name": "Семейный 3 📱", "type": "DEVICES", "duration": 30, "is_trial": false, "device_limit": 3, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-20 05:50:14.679319+00	2026-05-18 05:52:04.785702+00	\N	NO_RESET	\N	17	\N	\N	\N	f
210	ee7cceeb-93af-4ad7-8a07-04b2d6cf5f83	ACTIVE	f	0	2	{7d3c2f79-92d4-4384-b5e0-4dadb7cda374}	2026-08-08 05:30:32.334+00	https://sub.begemot.cc/2oY9_f1FuuQW0dRR	{"id": 13, "tag": null, "name": "👥 DUO · 2 📱 − выгоднее", "type": "DEVICES", "duration": 90, "is_trial": false, "device_limit": 2, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-05-10 05:30:32.325111+00	2026-05-10 05:30:32.325111+00	\N	NO_RESET	\N	829	\N	\N	\N	f
245	26b8182f-51ce-4642-abd9-d82b593ca56d	EXPIRED	f	0	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-06-23 11:38:11.049+00	https://sub.begemot.cc/qRqzaFsd8XUuCh0E	{"id": 12, "tag": null, "name": "👤 SOLO · 1 📱", "type": "DEVICES", "duration": 30, "is_trial": false, "device_limit": 1, "traffic_limit": 0, "external_squad": null, "internal_squads": ["f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b"], "traffic_limit_strategy": "NO_RESET"}	2026-05-24 11:38:11.015281+00	2026-06-23 11:38:30.143013+00	\N	NO_RESET	\N	593	\N	\N	\N	f
2	6486e173-2b38-4ee0-ba56-c80dc851b661	DELETED	f	10	1	{7d3c2f79-92d4-4384-b5e0-4dadb7cda374}	2026-04-23 17:23:24.512+00	https://sub.begemot.cc/8QqGXtevRr7zGFcU	{"id": 3, "tag": "23", "name": "Пробный период", "type": "BOTH", "duration": 7, "is_trial": false, "device_limit": 1, "traffic_limit": 10, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-16 17:23:24.501272+00	2026-04-16 18:19:40.17908+00	\N	NO_RESET	23	2	\N	\N	\N	f
4	e7fd3e0a-ffc3-4c76-a1cc-945b497a1862	ACTIVE	f	0	3	{7d3c2f79-92d4-4384-b5e0-4dadb7cda374}	2026-05-16 20:31:45.051+00	https://sub.begemot.cc/_uGqT2UyxKvqoXvZ	{"id": 2, "tag": null, "name": "Семейный", "type": "DEVICES", "duration": 30, "is_trial": false, "device_limit": 3, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-16 20:31:45.039462+00	2026-04-16 20:31:45.039462+00	\N	NO_RESET	\N	3	\N	\N	\N	f
229	89cfcdf7-69ed-477c-8a66-d69c5799b733	ACTIVE	f	0	10	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2027-05-19 15:33:56.072+00	https://sub.begemot.cc/LdAyV7U5dZXgDWxV	{"id": 18, "tag": "BEST_VALUE", "name": "🚀 UNLIMITED · до 10 📱", "type": "DEVICES", "duration": 30, "is_trial": false, "device_limit": 10, "traffic_limit": 0, "external_squad": null, "internal_squads": ["f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b"], "traffic_limit_strategy": "NO_RESET"}	2026-05-19 15:33:47.04424+00	2026-05-19 15:33:56.092859+00	\N	NO_RESET	BEST_VALUE	2	\N	\N	\N	f
230	89cfcdf7-69ed-477c-8a66-d69c5799b733	ACTIVE	f	0	10	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2027-05-19 15:33:56.072+00	https://sub.begemot.cc/LdAyV7U5dZXgDWxV	{"id": 18, "tag": "BEST_VALUE", "name": "🚀 UNLIMITED · до 10 📱", "type": "DEVICES", "duration": 365, "is_trial": false, "device_limit": 10, "traffic_limit": 0, "external_squad": null, "internal_squads": ["f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b"], "traffic_limit_strategy": "NO_RESET"}	2026-05-19 15:33:56.068459+00	2026-05-19 15:33:56.068459+00	\N	NO_RESET	BEST_VALUE	2	\N	\N	\N	f
7	da3d6213-d753-4bcb-b61f-481a96c62805	DELETED	f	0	0	{7d3c2f79-92d4-4384-b5e0-4dadb7cda374}	2099-04-16 13:54:03+00	https://sub.begemot.cc/_-3Rp0Z_7AuHhdkJ	{"id": -1, "tag": null, "name": "IMPORTED", "type": "UNLIMITED", "duration": 0, "is_trial": false, "device_limit": 0, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-17 05:04:47.305513+00	2026-04-17 07:35:34.73726+00	\N	NO_RESET	\N	1	\N	\N	\N	f
11	da3d6213-d753-4bcb-b61f-481a96c62805	ACTIVE	f	0	1	{7d3c2f79-92d4-4384-b5e0-4dadb7cda374}	2026-05-01 07:35:34.814+00	https://sub.begemot.cc/_-3Rp0Z_7AuHhdkJ	{"id": 1, "tag": null, "name": "Персональный", "type": "DEVICES", "duration": 14, "is_trial": false, "device_limit": 1, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-17 07:35:34.73726+00	2026-04-17 07:35:34.73726+00	\N	NO_RESET	\N	1	\N	\N	\N	f
12	da3d6213-d753-4bcb-b61f-481a96c62805	DELETED	f	0	1	{7d3c2f79-92d4-4384-b5e0-4dadb7cda374}	2027-04-17 07:39:47.133+00	https://sub.begemot.cc/_-3Rp0Z_7AuHhdkJ	{"id": 1, "tag": null, "name": "Персональный", "type": "DEVICES", "duration": 365, "is_trial": false, "device_limit": 1, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-17 07:39:47.123814+00	2026-04-17 08:29:23.991264+00	\N	NO_RESET	\N	1	\N	\N	\N	f
13	6a16dcc2-2ec5-4e13-b9d8-35d504d8e999	DELETED	f	100	1	{7d3c2f79-92d4-4384-b5e0-4dadb7cda374}	2026-04-26 13:23:56.091+00	https://sub.begemot.cc/Bm76uYGD1jqATyv5	{"id": 1, "tag": null, "name": "Персональный", "type": "DEVICES", "duration": 14, "is_trial": false, "device_limit": 1, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-17 08:33:02.836947+00	2026-04-19 13:23:56.197818+00	\N	NO_RESET	\N	1	\N	\N	\N	f
8	1d8daf46-e0ed-46d1-9ec7-7e704b457b41	DELETED	t	0	1	{7d3c2f79-92d4-4384-b5e0-4dadb7cda374}	2026-05-19 17:24:52.436+00	https://sub.begemot.cc/BUeaPMSqbuGyYcg0	{"id": 3, "tag": "23", "name": "Пробный период", "type": "BOTH", "duration": 7, "is_trial": true, "device_limit": 1, "traffic_limit": 10, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-17 05:46:57.662691+00	2026-04-19 17:24:52.531311+00	\N	NO_RESET	\N	13	\N	\N	\N	f
6	c480b54e-a202-4c06-911d-d350f9d038d0	DELETED	f	0	2	{7d3c2f79-92d4-4384-b5e0-4dadb7cda374}	2026-05-17 04:58:02.014+00	https://sub.begemot.cc/S1auDef-DZ5wqt4-	{"id": 1, "tag": null, "name": "Персональный", "type": "DEVICES", "duration": 30, "is_trial": false, "device_limit": 1, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-17 04:58:01.999647+00	2026-04-20 13:52:53.196705+00	\N	NO_RESET	\N	7	\N	\N	\N	f
9	cd665a1b-dbd7-41dd-989a-8d326e5ed519	DELETED	f	999999	2	{7d3c2f79-92d4-4384-b5e0-4dadb7cda374}	2026-06-19 16:31:16.691+00	https://sub.begemot.cc/C80QDXeAusXBVSup	{"id": 3, "tag": "23", "name": "Пробный период", "type": "BOTH", "duration": 7, "is_trial": true, "device_limit": 1, "traffic_limit": 10, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-17 06:02:34.109328+00	2026-04-20 16:31:16.779257+00	\N	NO_RESET	\N	10	\N	\N	\N	f
31	802edd51-a120-4326-8026-6eed75738631	ACTIVE	f	0	3	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-08-17 15:48:12.259+00	https://sub.begemot.cc/WjkQP730tPopRKrP	{"id": 2, "tag": null, "name": "Семейный 3 📱", "type": "DEVICES", "duration": 30, "is_trial": false, "device_limit": 3, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-19 17:44:50.510004+00	2026-05-19 15:48:12.281626+00	\N	NO_RESET	\N	6	\N	\N	\N	f
237	3cdb1211-b7e3-426e-991c-9e93b922d1fc	DELETED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-05-24 12:31:28.943+00	https://sub.begemot.cc/akM9bX2WT9od-mbz	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b"], "traffic_limit_strategy": "NO_RESET"}	2026-05-21 12:31:28.940861+00	2026-06-01 15:44:39.916358+00	\N	NO_RESET	\N	845	\N	\N	\N	f
239	5d774c88-8be5-4cf4-af27-398eb75959d9	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-05-25 08:23:05.414+00	https://sub.begemot.cc/fLfVv-obzwhFDyuP	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b"], "traffic_limit_strategy": "NO_RESET"}	2026-05-22 08:23:05.404469+00	2026-05-25 08:23:30.052493+00	\N	NO_RESET	\N	846	\N	\N	\N	f
175	9f29282b-440d-46e8-ab59-f8bc6eb47369	DELETED	f	0	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-06-01 11:32:17.165+00	https://sub.begemot.cc/ZU1z19pa6ADgYfv3	{"id": 12, "tag": null, "name": "👤 SOLO · 1 📱", "type": "DEVICES", "duration": 30, "is_trial": false, "device_limit": 1, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-05-02 11:32:17.150731+00	2026-05-30 10:34:46.39851+00	\N	NO_RESET	\N	699	\N	\N	\N	f
251	9f29282b-440d-46e8-ab59-f8bc6eb47369	ACTIVE	f	0	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-08-28 10:34:46.448+00	https://sub.begemot.cc/ZU1z19pa6ADgYfv3	{"id": 12, "tag": null, "name": "👤 SOLO · 1 📱", "type": "DEVICES", "duration": 90, "is_trial": false, "device_limit": 1, "traffic_limit": 0, "external_squad": null, "internal_squads": ["f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b"], "traffic_limit_strategy": "NO_RESET"}	2026-05-30 10:34:46.39851+00	2026-05-30 10:34:46.39851+00	\N	NO_RESET	\N	699	\N	\N	\N	f
263	4a9944b7-3cbe-4b95-93c4-5a8adf72ec20	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-06-08 15:58:26.178+00	https://sub.begemot.cc/tPPx1Mz3QTDY8e-8	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b"], "traffic_limit_strategy": "NO_RESET"}	2026-06-05 15:58:26.163435+00	2026-06-08 15:58:30.124548+00	\N	NO_RESET	\N	870	\N	\N	\N	f
246	07b20bb3-77b3-45cd-920a-caf7a9efa9a5	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-05-29 08:35:26.398+00	https://sub.begemot.cc/tbq8tBgf9taxSjj7	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b"], "traffic_limit_strategy": "NO_RESET"}	2026-05-26 08:35:26.395082+00	2026-05-29 08:35:30.135185+00	\N	NO_RESET	\N	853	\N	\N	\N	f
233	b903036e-b1f0-436a-b9e0-ce0750dbd7c0	ACTIVE	f	0	3	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-07-18 19:03:03.854+00	https://sub.begemot.cc/ULb0Hwkc_bxqWeKy	{"id": 14, "tag": null, "name": "🏠 HOME · 3 📱 ⭐ Хит", "type": "DEVICES", "duration": 30, "is_trial": false, "device_limit": 3, "traffic_limit": 0, "external_squad": null, "internal_squads": ["f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b"], "traffic_limit_strategy": "NO_RESET"}	2026-05-19 19:03:03.82674+00	2026-06-18 04:35:13.632938+00	\N	NO_RESET	\N	16	\N	\N	\N	f
42	37bdca58-c98a-4082-912d-5cb9b086182f	ACTIVE	f	0	2	{7d3c2f79-92d4-4384-b5e0-4dadb7cda374}	2026-05-21 12:22:29.241+00	https://sub.begemot.cc/Jc5f7uUwGB32en4a	{"id": 7, "tag": null, "name": "Пара📱", "type": "DEVICES", "duration": 30, "is_trial": false, "device_limit": 2, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-21 12:22:29.205672+00	2026-04-21 12:22:29.205672+00	\N	NO_RESET	\N	586	\N	\N	\N	f
150	c95df7a4-c61a-4959-a2b2-758be3f6a438	DELETED	f	0	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-05-30 07:29:36.325+00	https://sub.begemot.cc/CDqQtvH2Qe7z5J8S	{"id": 12, "tag": null, "name": "👤 SOLO · 1 📱", "type": "DEVICES", "duration": 30, "is_trial": false, "device_limit": 1, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-30 07:29:36.2239+00	2026-05-30 13:55:33.162319+00	\N	NO_RESET	\N	728	\N	\N	\N	f
27	c8840626-42b2-4f91-9ccb-a9ac29720ed4	DELETED	f	0	2	{7d3c2f79-92d4-4384-b5e0-4dadb7cda374}	2026-05-19 14:35:05.897+00	https://sub.begemot.cc/xvkgmjpo6WVSZgHw	{"id": 7, "tag": null, "name": "Пара📱", "type": "BOTH", "duration": 30, "is_trial": false, "device_limit": 2, "traffic_limit": 100, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-19 14:35:05.887883+00	2026-05-17 18:07:16.055879+00	\N	NO_RESET	\N	26	\N	\N	\N	f
252	c95df7a4-c61a-4959-a2b2-758be3f6a438	ACTIVE	f	0	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-06-29 13:55:33.185+00	https://sub.begemot.cc/CDqQtvH2Qe7z5J8S	{"id": 12, "tag": null, "name": "👤 SOLO · 1 📱", "type": "DEVICES", "duration": 30, "is_trial": false, "device_limit": 1, "traffic_limit": 0, "external_squad": null, "internal_squads": ["f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b"], "traffic_limit_strategy": "NO_RESET"}	2026-05-30 13:55:33.162319+00	2026-05-30 13:55:33.162319+00	\N	NO_RESET	\N	728	\N	\N	\N	f
264	bbae249d-0268-4a0a-95cb-a1d7217c3923	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-06-10 07:55:29.807+00	https://sub.begemot.cc/kLHpQSTFWoopMp12	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b"], "traffic_limit_strategy": "NO_RESET"}	2026-06-07 07:55:29.797356+00	2026-06-10 07:55:30.099849+00	\N	NO_RESET	\N	871	\N	\N	\N	f
228	00bd5cae-38fd-4e6f-8154-918e131bc70a	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-05-21 14:39:05.422+00	https://sub.begemot.cc/jkTD4ESX9aucPhsE	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-05-18 14:39:05.411042+00	2026-05-21 14:39:30.052742+00	\N	NO_RESET	\N	842	\N	\N	\N	f
247	b822f331-75fa-4358-924f-c7417f93f845	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-05-29 15:00:00.514+00	https://sub.begemot.cc/W9rKX_KNBft0ynvg	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b"], "traffic_limit_strategy": "NO_RESET"}	2026-05-26 15:00:00.501606+00	2026-05-29 15:00:30.059609+00	\N	NO_RESET	\N	854	\N	\N	\N	f
259	d0463f40-eff7-48f4-adef-c5908efac7f2	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-06-05 13:35:33.919+00	https://sub.begemot.cc/ckJnJFrfATm5npYq	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b"], "traffic_limit_strategy": "NO_RESET"}	2026-06-02 13:35:33.909618+00	2026-06-05 13:36:00.056192+00	\N	NO_RESET	\N	865	\N	\N	\N	f
248	c373bc68-3dd0-4738-a603-3ff53f17e1ad	EXPIRED	f	0	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-06-26 19:04:09.045+00	https://sub.begemot.cc/8kqBB1Q17j7TLMSz	{"id": 12, "tag": null, "name": "👤 SOLO · 1 📱", "type": "DEVICES", "duration": 30, "is_trial": false, "device_limit": 1, "traffic_limit": 0, "external_squad": null, "internal_squads": ["f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b"], "traffic_limit_strategy": "NO_RESET"}	2026-05-27 19:04:09.025717+00	2026-06-26 19:04:30.055001+00	\N	NO_RESET	\N	610	\N	\N	\N	f
238	67d1617f-5189-41e4-b8b2-52f4aebdaa14	ACTIVE	f	0	10	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2030-01-16 14:29:14.055+00	https://sub.begemot.cc/kRxc8Pv-Ga5dVCHj	{"id": 18, "tag": "BEST_VALUE", "name": "🚀 UNLIMITED · до 10 📱", "type": "DEVICES", "duration": 365, "is_trial": false, "device_limit": 10, "traffic_limit": 0, "external_squad": null, "internal_squads": ["f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b"], "traffic_limit_strategy": "NO_RESET"}	2026-05-21 21:03:31.179512+00	2026-06-23 18:48:27.875401+00	\N	NO_RESET	BEST_VALUE	1	2026-06-23 18:48:27.924239+00	\N	2026-06-22 11:22:35.120854+00	f
50	26b8182f-51ce-4642-abd9-d82b593ca56d	DELETED	t	5	1	{7d3c2f79-92d4-4384-b5e0-4dadb7cda374}	2026-04-26 10:39:57.209+00	https://sub.begemot.cc/qRqzaFsd8XUuCh0E	{"id": 3, "tag": "23", "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-23 10:39:57.195334+00	2026-04-23 10:51:00.13191+00	\N	NO_RESET	23	593	\N	\N	\N	f
270	e951a4f3-38f9-4a3c-8933-16a87bdef184	ACTIVE	f	0	3	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-07-12 06:38:54.028+00	https://sub.begemot.cc/J-o-PG8PNLB4GvEZ	{"id": 14, "tag": null, "name": "🏠 HOME · 3 📱 ⭐ Хит", "type": "DEVICES", "duration": 30, "is_trial": false, "device_limit": 3, "traffic_limit": 0, "external_squad": null, "internal_squads": ["f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b"], "traffic_limit_strategy": "NO_RESET"}	2026-06-12 06:38:53.989779+00	2026-06-12 06:38:53.989779+00	\N	NO_RESET	\N	20	\N	\N	\N	f
15	6d1cdc68-ea0b-47e3-bbef-83a8e71ae087	ACTIVE	t	0	1	{7d3c2f79-92d4-4384-b5e0-4dadb7cda374}	2026-05-07 11:11:21.777+00	https://sub.begemot.cc/Vd10xsXTvNDMvJFg	{"id": 3, "tag": "23", "name": "Пробный период", "type": "BOTH", "duration": 7, "is_trial": true, "device_limit": 1, "traffic_limit": 10, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-17 10:52:53.054064+00	2026-04-23 11:11:21.848378+00	\N	NO_RESET	\N	18	\N	\N	\N	f
265	2f9280a5-2ccf-48b7-8fcd-9b4ccba2be03	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-06-10 22:55:59.355+00	https://sub.begemot.cc/625t21sJXVL42QdD	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b"], "traffic_limit_strategy": "NO_RESET"}	2026-06-07 22:55:59.342024+00	2026-06-10 22:56:00.074807+00	\N	NO_RESET	\N	874	\N	\N	\N	f
271	50389bba-c616-4b19-8bb1-a96d1816fc44	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-06-15 08:55:17.602+00	https://sub.begemot.cc/YF_6ydv_gP4U35gy	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b"], "traffic_limit_strategy": "NO_RESET"}	2026-06-12 08:55:17.598038+00	2026-06-15 08:55:30.105805+00	\N	NO_RESET	\N	882	\N	\N	\N	f
266	e0e17f74-2c20-4319-8d15-41fd57be6206	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-06-12 03:49:08.037+00	https://sub.begemot.cc/QtB7a_C9dRXDurrd	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b"], "traffic_limit_strategy": "NO_RESET"}	2026-06-09 03:49:08.024321+00	2026-06-12 03:49:30.038627+00	\N	NO_RESET	\N	876	\N	\N	\N	f
217	7793d113-2ef7-45ab-988c-66f68160a387	EXPIRED	f	0	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-06-12 12:38:18.354+00	https://sub.begemot.cc/81g5-_YT3oXTf48k	{"id": 12, "tag": null, "name": "👤 SOLO · 1 📱", "type": "DEVICES", "duration": 30, "is_trial": false, "device_limit": 1, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-05-13 12:38:18.251071+00	2026-06-12 12:38:30.081496+00	\N	NO_RESET	\N	608	\N	\N	\N	f
235	0da84436-bdea-49a9-94f1-6426001c350f	ACTIVE	f	0	2	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-07-19 14:25:09.684+00	https://sub.begemot.cc/XLt6oDFC5Cp883Mo	{"id": 13, "tag": null, "name": "👥 DUO · 2 📱 − выгоднее", "type": "DEVICES", "duration": 30, "is_trial": false, "device_limit": 2, "traffic_limit": 0, "external_squad": null, "internal_squads": ["f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b"], "traffic_limit_strategy": "NO_RESET"}	2026-05-20 14:25:09.679853+00	2026-06-18 18:32:32.637574+00	\N	NO_RESET	\N	7	\N	\N	\N	f
241	37bdca58-c98a-4082-912d-5cb9b086182f	ACTIVE	f	0	3	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2027-06-26 19:54:39.61+00	https://sub.begemot.cc/Jc5f7uUwGB32en4a	{"id": 14, "tag": null, "name": "🏠 HOME · 3 📱 ⭐ Хит", "type": "DEVICES", "duration": 365, "is_trial": false, "device_limit": 3, "traffic_limit": 0, "external_squad": null, "internal_squads": ["f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b"], "traffic_limit_strategy": "NO_RESET"}	2026-05-23 19:20:25.435751+00	2026-06-01 19:57:18.758892+00	\N	MONTH	\N	586	\N	\N	\N	f
272	1c916439-d41a-46f4-acc4-c1dacf9ce10a	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-06-17 14:54:28.183+00	https://sub.begemot.cc/sSm73XxZoj59UNE7	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b"], "traffic_limit_strategy": "NO_RESET"}	2026-06-14 14:54:28.17947+00	2026-06-17 14:54:30.114243+00	\N	NO_RESET	\N	883	\N	\N	\N	f
273	52cb1c2d-afbf-4343-9bc2-6c30f98fdd33	ACTIVE	f	0	3	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-08-16 05:58:59.274+00	https://sub.begemot.cc/Kua42QjcE9wHtFqa	{"id": 14, "tag": null, "name": "🏠 HOME · 3 📱 ⭐ Хит", "type": "DEVICES", "duration": 60, "is_trial": false, "device_limit": 3, "traffic_limit": 0, "external_squad": null, "internal_squads": ["f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b"], "traffic_limit_strategy": "NO_RESET"}	2026-06-17 05:58:59.247598+00	2026-06-17 05:58:59.247598+00	\N	NO_RESET	\N	17	\N	\N	\N	f
113	8703efe4-c990-4961-9db4-8410ae9b612c	DELETED	t	5	1	{7d3c2f79-92d4-4384-b5e0-4dadb7cda374}	2026-04-30 09:51:54.225+00	https://sub.begemot.cc/fnpVz3ZCJZLnV2Ha	{"id": 3, "tag": "23", "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-27 09:51:54.214313+00	2026-04-27 09:53:02.683825+00	\N	NO_RESET	23	24	\N	\N	\N	f
206	7793d113-2ef7-45ab-988c-66f68160a387	DELETED	t	5	1	{7d3c2f79-92d4-4384-b5e0-4dadb7cda374}	2026-05-11 19:08:58.948+00	https://sub.begemot.cc/81g5-_YT3oXTf48k	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-05-08 19:08:58.916061+00	2026-05-13 12:38:18.251071+00	\N	NO_RESET	\N	608	\N	\N	\N	f
18	e951a4f3-38f9-4a3c-8933-16a87bdef184	DELETED	f	0	3	{7d3c2f79-92d4-4384-b5e0-4dadb7cda374}	2026-05-17 17:49:40.047+00	https://sub.begemot.cc/J-o-PG8PNLB4GvEZ	{"id": 2, "tag": null, "name": "Семейный", "type": "DEVICES", "duration": 30, "is_trial": false, "device_limit": 3, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-17 17:49:40.029425+00	2026-05-14 18:56:14.743084+00	\N	NO_RESET	\N	20	\N	\N	\N	f
55	67d1617f-5189-41e4-b8b2-52f4aebdaa14	ACTIVE	f	0	5	{7d3c2f79-92d4-4384-b5e0-4dadb7cda374}	2027-04-27 12:19:32.275+00	https://sub.begemot.cc/VT4YE2Lw9nuUXGRe	{"id": 9, "tag": null, "name": "Команда 5📱", "type": "DEVICES", "duration": 365, "is_trial": false, "device_limit": 5, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-24 16:23:00.493927+00	2026-04-27 12:19:32.351252+00	\N	NO_RESET	\N	1	\N	\N	\N	f
20	daec057e-a131-4947-b885-6a9c12420d5d	DELETED	f	0	3	{7d3c2f79-92d4-4384-b5e0-4dadb7cda374}	2026-08-15 09:10:08.521+00	https://sub.begemot.cc/wvvCfV6zQMThdspv	{"id": 2, "tag": null, "name": "Семейный", "type": "DEVICES", "duration": 30, "is_trial": false, "device_limit": 3, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-18 15:51:36.967653+00	2026-05-17 09:10:08.653125+00	\N	NO_RESET	\N	4	\N	\N	\N	f
116	67d1617f-5189-41e4-b8b2-52f4aebdaa14	ACTIVE	f	0	4	{7d3c2f79-92d4-4384-b5e0-4dadb7cda374}	2027-04-27 12:20:28.81+00	https://sub.begemot.cc/VT4YE2Lw9nuUXGRe	{"id": 16, "tag": null, "name": "🧑‍💻 TEAM · 5 устройств 🔥 максимум выгоды", "type": "DEVICES", "duration": 365, "is_trial": false, "device_limit": 5, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-27 12:19:32.264916+00	2026-04-27 12:20:28.861852+00	\N	NO_RESET	\N	1	\N	\N	\N	f
112	9f29282b-440d-46e8-ab59-f8bc6eb47369	EXPIRED	t	5	1	{7d3c2f79-92d4-4384-b5e0-4dadb7cda374}	2026-04-30 09:38:31.496+00	https://sub.begemot.cc/ZU1z19pa6ADgYfv3	{"id": 3, "tag": "23", "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-27 09:38:31.463941+00	2026-04-30 09:39:00.194151+00	\N	NO_RESET	23	699	\N	\N	\N	f
117	67d1617f-5189-41e4-b8b2-52f4aebdaa14	ACTIVE	f	0	3	{7d3c2f79-92d4-4384-b5e0-4dadb7cda374}	2027-04-27 12:20:34.291+00	https://sub.begemot.cc/VT4YE2Lw9nuUXGRe	{"id": 15, "tag": null, "name": "👨‍👩‍👧 FAMILY · 4 устройства", "type": "DEVICES", "duration": 365, "is_trial": false, "device_limit": 4, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-27 12:20:28.799968+00	2026-04-27 12:20:34.361501+00	\N	NO_RESET	\N	1	\N	\N	\N	f
249	4c206408-c48b-4ba5-8752-c92612659523	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-05-31 17:09:43.048+00	https://sub.begemot.cc/YBf_Q8TxZtCAMAyj	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b"], "traffic_limit_strategy": "NO_RESET"}	2026-05-28 17:09:43.042954+00	2026-05-31 17:10:00.051109+00	\N	NO_RESET	\N	855	\N	\N	\N	f
261	10bd3729-e995-449a-a314-70701a4b78be	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-06-06 11:01:42.305+00	https://sub.begemot.cc/QpCdm83v9kXXQ8Qk	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b"], "traffic_limit_strategy": "NO_RESET"}	2026-06-03 11:01:42.293567+00	2026-06-06 11:02:00.063503+00	\N	NO_RESET	\N	868	\N	\N	\N	f
52	6d1cdc68-ea0b-47e3-bbef-83a8e71ae087	DELETED	f	0	3	{7d3c2f79-92d4-4384-b5e0-4dadb7cda374}	2026-11-03 05:48:39.43+00	https://sub.begemot.cc/Vd10xsXTvNDMvJFg	{"id": 1, "tag": null, "name": "Личный", "type": "DEVICES", "duration": 14, "is_trial": false, "device_limit": 1, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-23 11:11:21.749618+00	2026-05-07 05:48:39.586202+00	\N	NO_RESET	\N	18	\N	\N	\N	f
213	16387dfb-1bda-4c97-98eb-30f329facb73	ACTIVE	f	0	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-08-09 18:37:23.607+00	https://sub.begemot.cc/Yhx5_kEr9Dy96gc9	{"id": 12, "tag": null, "name": "👤 SOLO · 1 📱", "type": "DEVICES", "duration": 90, "is_trial": false, "device_limit": 1, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-05-11 18:37:23.494156+00	2026-05-19 08:07:10.423159+00	\N	NO_RESET	\N	603	\N	\N	\N	f
118	67d1617f-5189-41e4-b8b2-52f4aebdaa14	ACTIVE	f	0	2	{7d3c2f79-92d4-4384-b5e0-4dadb7cda374}	2027-04-27 12:20:37.867+00	https://sub.begemot.cc/VT4YE2Lw9nuUXGRe	{"id": 14, "tag": null, "name": "🏠 HOME · 3 устройства ⭐ выбор большинства", "type": "DEVICES", "duration": 365, "is_trial": false, "device_limit": 3, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-27 12:20:34.250402+00	2026-04-27 12:20:37.90286+00	\N	NO_RESET	\N	1	\N	\N	\N	f
243	04c36e20-1856-40e2-a9af-a4f4908811e3	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-05-27 09:23:29.803+00	https://sub.begemot.cc/a4nNkxE6NEu8ad97	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b"], "traffic_limit_strategy": "NO_RESET"}	2026-05-24 09:23:29.799409+00	2026-05-27 09:23:30.105959+00	\N	NO_RESET	\N	850	\N	\N	\N	f
119	67d1617f-5189-41e4-b8b2-52f4aebdaa14	ACTIVE	f	0	1	{7d3c2f79-92d4-4384-b5e0-4dadb7cda374}	2027-04-27 12:20:41.908+00	https://sub.begemot.cc/VT4YE2Lw9nuUXGRe	{"id": 13, "tag": null, "name": "👥 DUO · 2 устройства − выгоднее", "type": "DEVICES", "duration": 365, "is_trial": false, "device_limit": 2, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-27 12:20:37.855577+00	2026-04-27 12:20:41.940036+00	\N	NO_RESET	\N	1	\N	\N	\N	f
120	67d1617f-5189-41e4-b8b2-52f4aebdaa14	ACTIVE	f	0	4	{7d3c2f79-92d4-4384-b5e0-4dadb7cda374}	2026-05-27 12:20:45.255+00	https://sub.begemot.cc/VT4YE2Lw9nuUXGRe	{"id": 12, "tag": null, "name": "👤 SOLO · 1 устройство", "type": "DEVICES", "duration": 365, "is_trial": false, "device_limit": 1, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-27 12:20:41.899562+00	2026-04-27 12:20:45.283+00	\N	NO_RESET	\N	1	\N	\N	\N	f
121	67d1617f-5189-41e4-b8b2-52f4aebdaa14	ACTIVE	f	0	4	{7d3c2f79-92d4-4384-b5e0-4dadb7cda374}	2026-05-27 12:20:45.255+00	https://sub.begemot.cc/VT4YE2Lw9nuUXGRe	{"id": 15, "tag": null, "name": "👨‍👩‍👧 FAMILY · 4 устройства", "type": "DEVICES", "duration": 30, "is_trial": false, "device_limit": 4, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-27 12:20:45.244947+00	2026-04-27 12:20:45.244947+00	\N	NO_RESET	\N	1	\N	\N	\N	f
256	d004b922-ec2d-4bf0-b5b7-14dabe8c2ee5	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-06-04 19:34:32.973+00	https://sub.begemot.cc/Nvvu90cPoLpWykH2	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b"], "traffic_limit_strategy": "NO_RESET"}	2026-06-01 19:34:32.960365+00	2026-06-04 19:35:00.0622+00	\N	NO_RESET	\N	861	\N	\N	\N	f
269	e09b1238-43d2-40ec-8f6b-b33e4f9d4610	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-06-14 19:32:12.906+00	https://sub.begemot.cc/QmyZKA-cFevRr5-V	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b"], "traffic_limit_strategy": "NO_RESET"}	2026-06-11 19:32:12.899424+00	2026-06-14 19:32:30.080308+00	\N	NO_RESET	\N	881	\N	\N	\N	f
258	ab25ffee-39c7-4f9d-aec8-cee703ce0c86	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-06-05 07:57:37.157+00	https://sub.begemot.cc/rzN-fWdrvvr6WBuX	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b"], "traffic_limit_strategy": "NO_RESET"}	2026-06-02 07:57:37.14763+00	2026-06-05 07:58:00.056092+00	\N	NO_RESET	\N	864	\N	\N	\N	f
202	941f4d6d-5303-4dbf-9197-22ac11ef332a	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-05-09 21:04:34.449+00	https://sub.begemot.cc/0swvyKh3SAgjoqBp	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-05-06 21:04:34.412528+00	2026-05-19 08:07:10.446855+00	\N	NO_RESET	\N	822	\N	\N	\N	f
223	4feded5b-e0c8-4b43-9385-9be8ed5ffe87	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-05-19 07:59:41.926+00	https://sub.begemot.cc/hmbdhrSo-JdCXyNK	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-05-16 07:59:41.896955+00	2026-05-19 08:00:00.080824+00	\N	NO_RESET	\N	839	\N	\N	\N	f
221	521259ea-3193-4ace-b300-9c1310fdfd28	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-05-18 14:27:39.371+00	https://sub.begemot.cc/8mmmd0mYtfdHwtQX	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-05-15 14:27:39.359873+00	2026-05-19 08:07:10.388678+00	\N	NO_RESET	\N	837	\N	\N	\N	f
166	78da5026-d3f3-45c3-b6c4-12569be81021	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-05-04 16:48:37.983+00	https://sub.begemot.cc/Xa3mXaKKNha3AD6d	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-05-01 16:48:37.950878+00	2026-05-19 08:07:10.578821+00	\N	NO_RESET	\N	766	\N	\N	\N	f
151	c85d2b9e-ad38-41f8-a6ed-673df29209bb	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-05-03 08:05:17.617+00	https://sub.begemot.cc/hhyzbr8bFzm_xGFn	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-30 08:05:17.574125+00	2026-05-19 08:07:10.646564+00	\N	NO_RESET	\N	740	\N	\N	\N	f
148	e50a390d-2585-46c3-a768-e9025f97c969	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-05-03 01:17:39.239+00	https://sub.begemot.cc/mFbcobNLWyqFh5Mt	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-30 01:17:39.204332+00	2026-05-19 08:07:10.650211+00	\N	NO_RESET	\N	739	\N	\N	\N	f
133	4516844f-30a7-4448-ab9b-ce7a6b0cf6b4	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-05-01 14:02:28.788+00	https://sub.begemot.cc/GqJAG16PnCWoqCbs	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-28 14:02:28.779286+00	2026-05-19 08:07:10.709429+00	\N	NO_RESET	\N	719	\N	\N	\N	f
62	dc6247d9-f72b-4414-b70d-58342bc3a6bc	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-04-27 22:18:29.08+00	https://sub.begemot.cc/CXkEdAgnJDGmWhZq	{"id": 3, "tag": "23", "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-24 22:18:29.047914+00	2026-05-19 08:07:11.00016+00	\N	NO_RESET	23	613	\N	\N	\N	f
61	a2182848-aa29-4210-a5a8-bba0babec635	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-04-27 21:48:18.358+00	https://sub.begemot.cc/ShbnCBJMC3xSESuP	{"id": 3, "tag": "23", "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-24 21:48:18.329318+00	2026-05-19 08:07:11.004688+00	\N	NO_RESET	23	612	\N	\N	\N	f
37	642d4076-d13a-4726-8cb4-079d3055f7e0	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-04-23 09:50:39.538+00	https://sub.begemot.cc/NNKaFvm3qevZpsdQ	{"id": 3, "tag": "23", "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-20 09:50:39.498258+00	2026-05-19 08:07:11.085103+00	\N	NO_RESET	23	31	\N	\N	\N	f
36	62353234-dbf8-434b-a64d-0dde5754161f	ACTIVE	f	0	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-08-18 09:20:02.632+00	https://sub.begemot.cc/-G6vKbe-3-d9o8c6	{"id": 1, "tag": null, "name": "Персональный", "type": "DEVICES", "duration": 90, "is_trial": false, "device_limit": 1, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-20 09:20:02.567777+00	2026-05-19 08:07:11.090074+00	\N	NO_RESET	\N	25	\N	\N	\N	f
35	04edd423-0c08-4107-a1a3-92eefbbf4cea	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-04-23 08:22:30.463+00	https://sub.begemot.cc/rwf8m74w6SLMqy0M	{"id": 3, "tag": "23", "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-20 08:22:30.429863+00	2026-05-19 08:07:11.094227+00	\N	NO_RESET	23	30	\N	\N	\N	f
34	7f5ba7b2-de26-4005-9dbd-c1efefbc7e9d	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-04-23 06:33:33.468+00	https://sub.begemot.cc/fgPZeEVjALxNGGGv	{"id": 3, "tag": "23", "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-20 06:33:33.460136+00	2026-05-19 08:07:11.098191+00	\N	NO_RESET	23	29	\N	\N	\N	f
275	552128e8-10f0-45d9-8262-e96464a4c19b	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-06-20 08:37:02.063+00	https://sub.begemot.cc/nUxgF6LhTS9PtPrz	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b"], "traffic_limit_strategy": "NO_RESET"}	2026-06-17 08:37:02.056443+00	2026-06-20 08:37:30.132271+00	\N	NO_RESET	\N	884	\N	\N	\N	f
143	67cce491-2090-45f2-8fde-bf215f375ff8	ACTIVE	t	0	1	{7d3c2f79-92d4-4384-b5e0-4dadb7cda374}	2026-05-30 06:03:27.461+00	https://sub.begemot.cc/mB3NgRStSxSdN0N0	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-29 16:56:54.286175+00	2026-04-30 06:03:27.595561+00	\N	NO_RESET	\N	734	\N	\N	\N	f
22	dd3a25f5-81e9-4b82-bc9d-3cc74939ad1c	DELETED	f	0	1	{7d3c2f79-92d4-4384-b5e0-4dadb7cda374}	2026-05-18 15:52:20.764+00	https://sub.begemot.cc/vTAwCYq_1hUjcwbP	{"id": 1, "tag": null, "name": "Персональный", "type": "DEVICES", "duration": 30, "is_trial": false, "device_limit": 1, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-18 15:52:20.755378+00	2026-05-15 16:03:57.44973+00	\N	NO_RESET	\N	5	\N	\N	\N	f
17	89cfcdf7-69ed-477c-8a66-d69c5799b733	EXPIRED	f	0	1	{7d3c2f79-92d4-4384-b5e0-4dadb7cda374}	2026-05-02 20:18:00+00	https://sub.begemot.cc/LdAyV7U5dZXgDWxV	{"id": 1, "tag": null, "name": "Персональный", "type": "DEVICES", "duration": 365, "is_trial": false, "device_limit": 1, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-17 16:41:46.731656+00	2026-05-02 20:18:00.121233+00	\N	NO_RESET	\N	2	\N	\N	\N	f
260	ff262e4f-af2d-475b-988f-311677437f39	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-06-05 18:52:14.945+00	https://sub.begemot.cc/29y0T01QAMarvqh9	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b"], "traffic_limit_strategy": "NO_RESET"}	2026-06-02 18:52:14.934116+00	2026-06-05 18:52:30.047166+00	\N	NO_RESET	\N	866	\N	\N	\N	f
250	491f8154-d92f-4da2-a1f3-d4fa327f4842	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-06-01 22:40:50.638+00	https://sub.begemot.cc/Vy8y6z3aGs6vVHhe	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b"], "traffic_limit_strategy": "NO_RESET"}	2026-05-29 22:40:50.628465+00	2026-06-01 22:41:00.121535+00	\N	NO_RESET	\N	856	\N	\N	\N	f
196	4350edd7-8f62-47f1-ac1e-0207bcc4f9c4	EXPIRED	f	0	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-06-04 05:59:27.126+00	https://sub.begemot.cc/BTz64dA3sN2G0oYa	{"id": 12, "tag": null, "name": "👤 SOLO · 1 📱", "type": "DEVICES", "duration": 30, "is_trial": false, "device_limit": 1, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-05-05 05:59:27.045239+00	2026-06-04 05:59:30.072625+00	\N	NO_RESET	\N	816	\N	\N	\N	f
198	274247c4-5214-445e-916b-a28428423225	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-05-08 10:23:30.197+00	https://sub.begemot.cc/o7ne-LzwvdwUhMX2	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-05-05 10:23:30.188968+00	2026-05-19 08:07:10.463243+00	\N	NO_RESET	\N	819	\N	\N	\N	f
197	c5ad1903-a17c-4e67-8409-efe7ca4b80d0	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-05-08 08:39:44.711+00	https://sub.begemot.cc/L4R4YLfXqvoEga-6	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-05-05 08:39:44.698931+00	2026-05-19 08:07:10.467255+00	\N	NO_RESET	\N	817	\N	\N	\N	f
195	fcb5431a-059a-4ae5-8b13-e9b5e74a8bdb	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-05-07 17:37:25.907+00	https://sub.begemot.cc/yxJkGVN025B92W_o	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-05-04 17:37:25.871569+00	2026-05-19 08:07:10.475056+00	\N	NO_RESET	\N	812	\N	\N	\N	f
194	72ca0c39-3006-463e-83c4-b5cec02fabcc	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-05-07 16:45:33.296+00	https://sub.begemot.cc/SmxjmGEZ8we9M9oP	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-05-04 16:45:33.28158+00	2026-05-19 08:07:10.479023+00	\N	NO_RESET	\N	810	\N	\N	\N	f
193	dd4d5769-1a69-422b-8fa9-dadb21e5fc22	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-05-07 13:39:02.675+00	https://sub.begemot.cc/Qa8Y6XQXtz8GfNw7	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-05-04 13:39:02.644051+00	2026-05-19 08:07:10.482736+00	\N	NO_RESET	\N	805	\N	\N	\N	f
192	4b3555a6-50e0-4c26-981a-060dea7d6171	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-05-07 11:18:13.365+00	https://sub.begemot.cc/M9CezhdQKGy2xEod	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-05-04 11:18:13.331301+00	2026-05-19 08:07:10.48656+00	\N	NO_RESET	\N	803	\N	\N	\N	f
191	afd96b72-ae12-46c2-8fb4-3a507df18f7e	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-05-07 06:43:30.396+00	https://sub.begemot.cc/y9QHLwu6a6RA1L0S	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-05-04 06:43:30.353942+00	2026-05-19 08:07:10.490294+00	\N	NO_RESET	\N	801	\N	\N	\N	f
190	ddffddca-14f8-4a3e-bbee-3c655ee094a8	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-05-07 03:12:49.44+00	https://sub.begemot.cc/RUUpcpwSPs70zRJr	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-05-04 03:12:49.403328+00	2026-05-19 08:07:10.494158+00	\N	NO_RESET	\N	800	\N	\N	\N	f
278	98dbe015-3606-4e4e-825e-dfc134b87adf	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-06-22 10:44:43.475+00	https://sub.begemot.cc/R0_N2xkp0DXnJhnc	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b"], "traffic_limit_strategy": "NO_RESET"}	2026-06-19 10:44:43.471223+00	2026-06-22 10:45:00.116651+00	\N	NO_RESET	\N	888	\N	\N	\N	f
189	c03ff0d1-b7c4-452f-b139-bab5d1d34f0f	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-05-06 21:28:38.146+00	https://sub.begemot.cc/QLauJpWp9TmGZCZR	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-05-03 21:28:38.121625+00	2026-05-19 08:07:10.498021+00	\N	NO_RESET	\N	799	\N	\N	\N	f
188	53e21a6a-f23e-4565-aaaa-6fc47c2454f9	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-05-06 15:22:29.804+00	https://sub.begemot.cc/4MMP7Rh1fm29T3H_	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-05-03 15:22:29.770189+00	2026-05-19 08:07:10.501814+00	\N	NO_RESET	\N	797	\N	\N	\N	f
187	e329d268-effb-4f7a-a2e1-f61cbeda3111	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-05-06 12:33:12.037+00	https://sub.begemot.cc/B-0WXouJeawxuSTS	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-05-03 12:33:11.995898+00	2026-05-19 08:07:10.505657+00	\N	NO_RESET	\N	795	\N	\N	\N	f
186	04f86fe9-2502-4a56-a763-944e670caf9b	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-05-06 12:10:19.718+00	https://sub.begemot.cc/nYFy2dKVQEHR5pY8	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-05-03 12:10:19.68233+00	2026-05-19 08:07:10.511455+00	\N	NO_RESET	\N	794	\N	\N	\N	f
184	e42667e9-b2d9-4a61-bce0-6cdaab9bd039	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-05-06 07:41:12.257+00	https://sub.begemot.cc/YJAgwkwm4GKspMnB	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-05-03 07:41:12.213715+00	2026-05-19 08:07:10.516697+00	\N	NO_RESET	\N	790	\N	\N	\N	f
220	cf6bd6d9-3b72-4ab4-8eff-8b01c3b268ef	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-05-18 10:23:02.151+00	https://sub.begemot.cc/aDSesP72-8MqLwz9	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-05-15 10:23:02.116351+00	2026-05-19 08:07:10.394161+00	\N	NO_RESET	\N	836	\N	\N	\N	f
216	85f9724d-dd5f-403e-b9d4-78fb7cf3a6a5	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-05-15 04:46:37.611+00	https://sub.begemot.cc/3EKLA-DnnLYsPek9	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-05-12 04:46:37.584707+00	2026-05-19 08:07:10.399875+00	\N	NO_RESET	\N	834	\N	\N	\N	f
215	6ae85601-3789-417a-b0af-63a0e9ea11f3	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-05-15 02:51:27.782+00	https://sub.begemot.cc/vEFUMPYxodH3yEgz	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-05-12 02:51:27.753917+00	2026-05-19 08:07:10.405941+00	\N	NO_RESET	\N	833	\N	\N	\N	f
214	54c273b2-b440-4329-b808-135222c0d7be	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-05-14 23:45:01.288+00	https://sub.begemot.cc/SHpRyUF_czpX6EfY	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-05-11 23:45:01.253058+00	2026-05-19 08:07:10.410264+00	\N	NO_RESET	\N	832	\N	\N	\N	f
211	d519fcc8-eb97-4e92-89d3-d63440596726	ACTIVE	f	0	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-08-08 05:46:20.089+00	https://sub.begemot.cc/ccSuhnUUzF5W2asy	{"id": 12, "tag": null, "name": "👤 SOLO · 1 📱", "type": "DEVICES", "duration": 90, "is_trial": false, "device_limit": 1, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-05-10 05:46:20.077494+00	2026-05-19 08:07:10.414456+00	\N	NO_RESET	\N	830	\N	\N	\N	f
212	ee7cceeb-93af-4ad7-8a07-04b2d6cf5f83	ACTIVE	f	0	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-08-08 05:47:20.379+00	https://sub.begemot.cc/2oY9_f1FuuQW0dRR	{"id": 12, "tag": null, "name": "👤 SOLO · 1 📱", "type": "DEVICES", "duration": 90, "is_trial": false, "device_limit": 1, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-05-10 05:47:20.368658+00	2026-05-19 08:07:10.418657+00	\N	NO_RESET	\N	829	\N	\N	\N	f
208	19047b4b-ffa3-4b93-a3dc-36106507a964	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-05-12 11:42:20.244+00	https://sub.begemot.cc/9Vh68F6hjgqDGvu-	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-05-09 11:42:20.206201+00	2026-05-19 08:07:10.427418+00	\N	NO_RESET	\N	828	\N	\N	\N	f
207	f1fa360f-eff2-400a-8488-d920fc8210d9	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-05-12 09:38:13.848+00	https://sub.begemot.cc/zv0NC3hLRWaaE6jS	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-05-09 09:38:13.817642+00	2026-05-19 08:07:10.43133+00	\N	NO_RESET	\N	827	\N	\N	\N	f
205	4d6396d3-2fcc-4a0c-a858-521a5be21743	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-05-11 09:58:33.505+00	https://sub.begemot.cc/GoYrk9GyG3kR8t0t	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-05-08 09:58:33.480108+00	2026-05-19 08:07:10.438572+00	\N	NO_RESET	\N	826	\N	\N	\N	f
204	a9ab23d5-c9b5-4d56-9472-ef401da100d0	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-05-10 10:11:33.638+00	https://sub.begemot.cc/ddPfeYz_qpww6yug	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-05-07 10:11:33.602373+00	2026-05-19 08:07:10.4425+00	\N	NO_RESET	\N	824	\N	\N	\N	f
201	90063432-7b94-42f9-98e8-b13a317a623f	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-05-09 16:32:46.816+00	https://sub.begemot.cc/dekW_12y9Bj3LWML	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-05-06 16:32:46.784631+00	2026-05-19 08:07:10.450899+00	\N	NO_RESET	\N	821	\N	\N	\N	f
200	fabc6796-148b-41e7-9263-b1994db4d4f1	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-05-09 05:52:37.343+00	https://sub.begemot.cc/SHQRbx0N1ha6E8t-	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-05-06 05:52:37.299645+00	2026-05-19 08:07:10.454819+00	\N	NO_RESET	\N	820	\N	\N	\N	f
199	e288e614-db8d-46bb-9639-f6c17fe9e84e	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-05-08 18:11:15.64+00	https://sub.begemot.cc/0qKPoP9mUP1tcVPX	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-05-05 18:11:15.613219+00	2026-05-19 08:07:10.459292+00	\N	NO_RESET	\N	640	\N	\N	\N	f
183	cc9d9143-7c41-482a-9697-5c9ed7860f8d	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-05-06 06:59:55.325+00	https://sub.begemot.cc/8g5A4dXg2gV7otU3	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-05-03 06:59:55.295798+00	2026-05-19 08:07:10.521113+00	\N	NO_RESET	\N	781	\N	\N	\N	f
181	91b90078-f4e2-4df1-a249-7817f7428b41	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-05-05 16:51:27.189+00	https://sub.begemot.cc/Ln9rX143cWPS0bWE	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-05-02 16:51:27.153155+00	2026-05-19 08:07:10.526165+00	\N	NO_RESET	\N	787	\N	\N	\N	f
180	1ffe2c2d-66eb-48c2-b5d5-5d54278bd67a	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-05-05 16:28:33.571+00	https://sub.begemot.cc/Nk5q9dAHm4MWxYfa	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-05-02 16:28:33.5398+00	2026-05-19 08:07:10.530314+00	\N	NO_RESET	\N	786	\N	\N	\N	f
179	faa3049a-b78e-488a-a496-94db3b5592fa	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-05-05 14:53:32.941+00	https://sub.begemot.cc/Fwn91TGmAg9xHSBQ	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-05-02 14:53:32.909805+00	2026-05-19 08:07:10.53412+00	\N	NO_RESET	\N	721	\N	\N	\N	f
178	ecdcc4db-9b41-4471-9186-c427f61729e4	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-05-05 14:34:53.624+00	https://sub.begemot.cc/N52AUv_A-wX5-qUA	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-05-02 14:34:53.587818+00	2026-05-19 08:07:10.537836+00	\N	NO_RESET	\N	785	\N	\N	\N	f
177	c013a939-a1dc-4e3d-ae70-e1f1f63241ac	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-05-05 11:44:30.995+00	https://sub.begemot.cc/m9xpQBB12WCfPjbj	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-05-02 11:44:30.987161+00	2026-05-19 08:07:10.541685+00	\N	NO_RESET	\N	784	\N	\N	\N	f
176	394757c2-dc92-44ec-ab7e-fa79f41a7806	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-05-05 11:39:55.544+00	https://sub.begemot.cc/oXudhHg_E8rJ1C6a	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-05-02 11:39:55.504642+00	2026-05-19 08:07:10.545375+00	\N	NO_RESET	\N	783	\N	\N	\N	f
174	2d64d1ea-6be6-4e77-ac28-96cdf74e648b	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-05-05 11:30:25.558+00	https://sub.begemot.cc/BW1WqwZNZs6NApwf	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-05-02 11:30:25.543436+00	2026-05-19 08:07:10.549029+00	\N	NO_RESET	\N	782	\N	\N	\N	f
173	b1865ed4-9150-44ea-b04a-d698d85205b0	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-05-05 07:10:14.979+00	https://sub.begemot.cc/_1YwnyY0XzDejLeR	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-05-02 07:10:14.945288+00	2026-05-19 08:07:10.55254+00	\N	NO_RESET	\N	778	\N	\N	\N	f
172	c9b859b5-e45a-464e-b037-30e3ca835656	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-05-05 05:38:43.646+00	https://sub.begemot.cc/omEAT1SNNF0kjo1b	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-05-02 05:38:43.59997+00	2026-05-19 08:07:10.556101+00	\N	NO_RESET	\N	777	\N	\N	\N	f
171	51f592fa-984c-4346-8950-8a0cfff826f4	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-05-05 05:09:17.592+00	https://sub.begemot.cc/867dr_CPs8nF8H5Y	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-05-02 05:09:17.583043+00	2026-05-19 08:07:10.559698+00	\N	NO_RESET	\N	776	\N	\N	\N	f
170	cf016592-0d44-4daf-aa47-69455ccaa492	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-05-04 20:50:15.957+00	https://sub.begemot.cc/qrmcPmDAuyDHeS9X	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-05-01 20:50:15.90511+00	2026-05-19 08:07:10.563418+00	\N	NO_RESET	\N	774	\N	\N	\N	f
169	03924fa5-b557-453f-87aa-beee444f1042	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-05-04 20:09:36.197+00	https://sub.begemot.cc/hC6CAjy5B083AwRb	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-05-01 20:09:36.186464+00	2026-05-19 08:07:10.567195+00	\N	NO_RESET	\N	773	\N	\N	\N	f
168	93ef42c2-3724-49b9-9d5e-f7a28422b8c1	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-05-04 18:13:25.735+00	https://sub.begemot.cc/rhsf3Ud3mkTXX4wA	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-05-01 18:13:25.70094+00	2026-05-19 08:07:10.570959+00	\N	NO_RESET	\N	769	\N	\N	\N	f
167	8b97e839-3cb6-43ef-bc83-8948c9d1e458	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-05-04 17:15:24.353+00	https://sub.begemot.cc/GGVtjaU9VedLVowJ	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-05-01 17:15:24.343203+00	2026-05-19 08:07:10.5748+00	\N	NO_RESET	\N	767	\N	\N	\N	f
165	42f7ed6b-aeff-4616-bcd7-892b6d78eca7	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-05-04 16:17:26.453+00	https://sub.begemot.cc/Ecyqeu2voPR3Y0Bz	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-05-01 16:17:26.426584+00	2026-05-19 08:07:10.582747+00	\N	NO_RESET	\N	763	\N	\N	\N	f
164	427e9171-be59-4309-a9cb-08a531355401	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-05-04 14:46:34.563+00	https://sub.begemot.cc/FU2hRFwA6QsZK6LH	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-05-01 14:46:34.530318+00	2026-05-19 08:07:10.586984+00	\N	NO_RESET	\N	764	\N	\N	\N	f
163	69fdcf54-1dec-4823-8379-5797dd636901	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-05-04 12:34:27.707+00	https://sub.begemot.cc/R58NHWz9UE_pMyP2	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-05-01 12:34:27.66969+00	2026-05-19 08:07:10.590924+00	\N	NO_RESET	\N	761	\N	\N	\N	f
162	92668eaa-8f82-4d54-b909-489d4610729b	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-05-04 11:30:29.189+00	https://sub.begemot.cc/NkrGjDDzEAwkRsd8	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-05-01 11:30:29.153655+00	2026-05-19 08:07:10.595012+00	\N	NO_RESET	\N	744	\N	\N	\N	f
161	59ace944-b331-4e25-9ce9-d859d25db7dc	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-05-04 06:13:14.525+00	https://sub.begemot.cc/uvsWVbSqa0vp_LSS	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-05-01 06:13:14.515559+00	2026-05-19 08:07:10.599039+00	\N	NO_RESET	\N	759	\N	\N	\N	f
160	503a9a68-bdd2-45d5-9ce6-60dad4701e20	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-05-04 06:09:07.996+00	https://sub.begemot.cc/1Ed0SAtWP8GxZjtD	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-05-01 06:09:07.963863+00	2026-05-19 08:07:10.603581+00	\N	NO_RESET	\N	758	\N	\N	\N	f
159	a0d88ba5-c84d-4470-b82a-9378d39e00cc	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-05-03 19:53:53.538+00	https://sub.begemot.cc/Xk2Ub-fwC_VwSzgM	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-30 19:53:53.513317+00	2026-05-19 08:07:10.611985+00	\N	NO_RESET	\N	754	\N	\N	\N	f
158	a0019709-bce6-46b3-befe-f7f5a2cb912d	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-05-03 17:30:10.717+00	https://sub.begemot.cc/ZZUNGWtEqC9WAqfr	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-30 17:30:10.67531+00	2026-05-19 08:07:10.616907+00	\N	NO_RESET	\N	753	\N	\N	\N	f
157	e3822803-827d-44e4-baaa-17ec7b57ac2f	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-05-03 15:46:33.961+00	https://sub.begemot.cc/qrE24DqKsqhY7f0S	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-30 15:46:33.932468+00	2026-05-19 08:07:10.621306+00	\N	NO_RESET	\N	752	\N	\N	\N	f
156	328dbd13-e92e-426e-9800-cd058081c960	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-05-03 14:21:47.053+00	https://sub.begemot.cc/TPnmdhLjf4C-ANt9	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-30 14:21:47.016478+00	2026-05-19 08:07:10.625739+00	\N	NO_RESET	\N	750	\N	\N	\N	f
155	a7ca72e0-5c12-4d55-89b8-3dd6fd9f5fd2	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-05-03 13:47:40.136+00	https://sub.begemot.cc/cAsD5gtg4bSfHACM	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-30 13:47:40.09686+00	2026-05-19 08:07:10.629833+00	\N	NO_RESET	\N	749	\N	\N	\N	f
154	20095f71-0a76-4128-a195-be72fcd432b1	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-05-03 12:48:43.073+00	https://sub.begemot.cc/Mpw3MA-kSXov5aXt	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-30 12:48:43.036658+00	2026-05-19 08:07:10.633814+00	\N	NO_RESET	\N	748	\N	\N	\N	f
152	bd0d87c4-7926-4570-82fa-5bfa07a39656	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-05-03 09:44:36.896+00	https://sub.begemot.cc/x0BWXaxqw9E2pSSZ	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-30 09:44:36.864053+00	2026-05-19 08:07:10.64277+00	\N	NO_RESET	\N	742	\N	\N	\N	f
147	8a9fe763-c4ec-4fb5-a5ee-3cce21aa2856	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-05-02 18:55:25.764+00	https://sub.begemot.cc/gjF_K8JGo-p9LsDA	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-29 18:55:25.72672+00	2026-05-19 08:07:10.654199+00	\N	NO_RESET	\N	738	\N	\N	\N	f
146	198ab560-798e-4264-99ff-b9c006c5fa7a	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-05-02 17:51:56.782+00	https://sub.begemot.cc/0HNZfxKKapkRJPXo	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-29 17:51:56.742742+00	2026-05-19 08:07:10.658145+00	\N	NO_RESET	\N	737	\N	\N	\N	f
145	34a1d839-a685-4402-9b2b-688a444f50d5	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-05-02 17:27:43.465+00	https://sub.begemot.cc/RnXqy_6w8Y_1Lxsw	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-29 17:27:43.437631+00	2026-05-19 08:07:10.661843+00	\N	NO_RESET	\N	736	\N	\N	\N	f
144	70dda902-1549-4672-9eda-93591cf6b9e5	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-05-02 17:05:57.942+00	https://sub.begemot.cc/DJQtrNcy-u5L5x72	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-29 17:05:57.927737+00	2026-05-19 08:07:10.66545+00	\N	NO_RESET	\N	735	\N	\N	\N	f
141	82ae63da-3c80-4bce-8086-76846cf22595	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-05-02 15:13:08.509+00	https://sub.begemot.cc/V_6Zka8aQVwNwjXm	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-29 15:13:08.50027+00	2026-05-19 08:07:10.67476+00	\N	NO_RESET	\N	733	\N	\N	\N	f
140	343ce573-a008-4bc4-a6e7-04c1b9b91e2f	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-05-02 11:06:24.632+00	https://sub.begemot.cc/yra1sYzQKFrBA9kf	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-29 11:06:24.623775+00	2026-05-19 08:07:10.678904+00	\N	NO_RESET	\N	591	\N	\N	\N	f
139	68dcc089-e755-4707-acd3-21915b57e236	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-05-02 07:52:29.917+00	https://sub.begemot.cc/sNGYKnjYuzVuyJ_h	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-29 07:52:29.909046+00	2026-05-19 08:07:10.6839+00	\N	NO_RESET	\N	731	\N	\N	\N	f
137	77166dd8-0c3a-48fd-967c-629a0607c210	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-05-01 19:30:15.468+00	https://sub.begemot.cc/Aw50ErX_GKPL6t_Z	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-28 19:30:15.459987+00	2026-05-19 08:07:10.692773+00	\N	NO_RESET	\N	727	\N	\N	\N	f
136	c37e119a-d7bc-467c-9a1c-35280a79b5e1	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-05-01 18:09:59.132+00	https://sub.begemot.cc/2-Q2Aetn6h0hMwwd	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-28 18:09:59.123493+00	2026-05-19 08:07:10.696699+00	\N	NO_RESET	\N	725	\N	\N	\N	f
135	d6bc2214-01a5-4a80-8ce7-856daa5c8c83	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-05-01 15:34:02.123+00	https://sub.begemot.cc/Uy0CXB4deAcDzDt8	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-28 15:34:02.11465+00	2026-05-19 08:07:10.701284+00	\N	NO_RESET	\N	723	\N	\N	\N	f
134	d2152ae3-3bc5-4e21-9d7a-1f12a9dfd080	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-05-01 14:41:32.56+00	https://sub.begemot.cc/Fm5DcTGwKR5_t0ZF	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-28 14:41:32.551333+00	2026-05-19 08:07:10.705656+00	\N	NO_RESET	\N	720	\N	\N	\N	f
132	a1429713-477f-429d-93bc-66eb5ebd59cb	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-05-01 12:54:32.737+00	https://sub.begemot.cc/j_eHNhZGKj5b2rYE	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-28 12:54:32.728138+00	2026-05-19 08:07:10.713449+00	\N	NO_RESET	\N	718	\N	\N	\N	f
131	d443e1ec-33fd-429d-82d8-c6f238e18e47	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-05-01 11:18:55.713+00	https://sub.begemot.cc/L3nZo6tA6cQNXZNj	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-28 11:18:55.704955+00	2026-05-19 08:07:10.717788+00	\N	NO_RESET	\N	717	\N	\N	\N	f
130	68f50f5b-5634-471f-b11b-388fc9c4f585	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-05-01 08:28:18.738+00	https://sub.begemot.cc/P39vudXH8v8L-Z_r	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-28 08:28:18.706613+00	2026-05-19 08:07:10.721844+00	\N	NO_RESET	\N	716	\N	\N	\N	f
129	775c18f3-dc50-4de9-95d7-0d03ee589407	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-05-01 06:11:45.469+00	https://sub.begemot.cc/1Dnc8s3JaWpjSVTg	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-28 06:11:45.431633+00	2026-05-19 08:07:10.726322+00	\N	NO_RESET	\N	715	\N	\N	\N	f
128	0bdfaa26-0071-4a29-880d-98c1494cfe19	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-04-30 20:42:08.642+00	https://sub.begemot.cc/M_MNUbAudA1506rF	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-27 20:42:08.604654+00	2026-05-19 08:07:10.731562+00	\N	NO_RESET	\N	711	\N	\N	\N	f
127	724b14ea-1538-4024-823c-c7caf10c999b	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-04-30 17:15:49.622+00	https://sub.begemot.cc/SDB67msVaTV1CaMC	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-27 17:15:49.589807+00	2026-05-19 08:07:10.737071+00	\N	NO_RESET	\N	709	\N	\N	\N	f
126	afc3df02-6d5f-4ade-8104-c7f8545ffc5c	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-04-30 16:31:23.336+00	https://sub.begemot.cc/Up2uj9_kaQZDfQxk	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-27 16:31:23.30218+00	2026-05-19 08:07:10.744547+00	\N	NO_RESET	\N	708	\N	\N	\N	f
125	e599e651-20a6-427e-b6ec-b5ef15986471	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-04-30 16:09:24.867+00	https://sub.begemot.cc/T2wz3GdzC1cc73kq	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-27 16:09:24.83612+00	2026-05-19 08:07:10.751418+00	\N	NO_RESET	\N	707	\N	\N	\N	f
124	4e7afed7-0d23-4911-a108-fcf6d6e99231	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-04-30 13:54:33.641+00	https://sub.begemot.cc/yZCmtFXD48TBHt8X	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-27 13:54:33.622234+00	2026-05-19 08:07:10.756702+00	\N	NO_RESET	\N	705	\N	\N	\N	f
123	cef72d2f-f51e-4773-9c96-d665fd3b90eb	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-04-30 13:41:15.067+00	https://sub.begemot.cc/SpUvQm2v94_Q1n0e	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-27 13:41:15.037141+00	2026-05-19 08:07:10.76183+00	\N	NO_RESET	\N	704	\N	\N	\N	f
115	725e57a7-bf0c-419a-95ad-a0a7176c60e2	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-04-30 10:10:21.971+00	https://sub.begemot.cc/U8hL-g0MA8xgrmyA	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-27 10:10:21.960993+00	2026-05-19 08:07:10.767768+00	\N	NO_RESET	\N	701	\N	\N	\N	f
110	56b9ec22-be6e-4d9e-937b-95f65edf12b6	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-04-30 06:14:37.662+00	https://sub.begemot.cc/Gp-zw-3pENZ2WdLN	{"id": 3, "tag": "23", "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-27 06:14:37.623447+00	2026-05-19 08:07:10.7838+00	\N	NO_RESET	23	698	\N	\N	\N	f
109	b67da7ab-80db-451c-93fc-da71873d990e	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-04-30 03:24:26.453+00	https://sub.begemot.cc/_sesrbX9ECnE3TG-	{"id": 3, "tag": "23", "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-27 03:24:26.422952+00	2026-05-19 08:07:10.789238+00	\N	NO_RESET	23	697	\N	\N	\N	f
108	01620d20-cb81-4809-9b6c-60c0350240d7	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-04-29 23:22:23.826+00	https://sub.begemot.cc/-QFtgex5CEHf7HGB	{"id": 3, "tag": "23", "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-26 23:22:23.793824+00	2026-05-19 08:07:10.796235+00	\N	NO_RESET	23	696	\N	\N	\N	f
107	9cbd1044-b5fa-4d55-8595-4c52e3ca6f1b	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-04-29 22:29:30.443+00	https://sub.begemot.cc/hmV_X4UEC7wHw_3u	{"id": 3, "tag": "23", "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-26 22:29:30.407497+00	2026-05-19 08:07:10.803991+00	\N	NO_RESET	23	695	\N	\N	\N	f
106	f971901f-0f78-4871-9da3-da4785128b7d	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-04-29 15:19:04.7+00	https://sub.begemot.cc/f6kHa10u_qp_H5Y3	{"id": 3, "tag": "23", "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-26 15:19:04.674928+00	2026-05-19 08:07:10.810296+00	\N	NO_RESET	23	694	\N	\N	\N	f
105	0c5bcf34-14fc-49eb-803a-37357d92160b	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-04-29 13:51:37.622+00	https://sub.begemot.cc/jtx_1hwkzuKEmWU6	{"id": 3, "tag": "23", "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-26 13:51:37.589056+00	2026-05-19 08:07:10.815674+00	\N	NO_RESET	23	669	\N	\N	\N	f
104	9945d275-7173-4b67-a02d-0a8d5857b66a	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-04-29 13:14:13.253+00	https://sub.begemot.cc/9oNfMz5fe_E-WHyM	{"id": 3, "tag": "23", "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-26 13:14:13.24482+00	2026-05-19 08:07:10.820435+00	\N	NO_RESET	23	693	\N	\N	\N	f
103	fa0ae0bb-5a58-43f2-a2d3-50cb15dea215	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-04-29 13:14:11.762+00	https://sub.begemot.cc/xH6hsXvVFCzShBse	{"id": 3, "tag": "23", "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-26 13:14:11.753202+00	2026-05-19 08:07:10.825572+00	\N	NO_RESET	23	692	\N	\N	\N	f
102	f8886b17-61da-4cd8-a178-59ed9a17ad7c	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-04-29 12:20:40.199+00	https://sub.begemot.cc/69jRH_gyFrYKvXwj	{"id": 3, "tag": "23", "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-26 12:20:40.190737+00	2026-05-19 08:07:10.829969+00	\N	NO_RESET	23	690	\N	\N	\N	f
101	7bc534ad-1193-4b42-bfb0-e45426eddda2	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-04-29 11:52:11.41+00	https://sub.begemot.cc/nbzfeSdCX8qkjvch	{"id": 3, "tag": "23", "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-26 11:52:11.371254+00	2026-05-19 08:07:10.833838+00	\N	NO_RESET	23	689	\N	\N	\N	f
100	42ddabff-9fd6-44b4-b94f-ee8bef3b3e49	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-04-29 11:43:55.201+00	https://sub.begemot.cc/jsWe7fCVgx8VERHD	{"id": 3, "tag": "23", "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-26 11:43:55.190862+00	2026-05-19 08:07:10.837779+00	\N	NO_RESET	23	688	\N	\N	\N	f
99	3d941ab4-91d8-40ae-960f-334c5e0e4de9	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-04-29 11:41:16.699+00	https://sub.begemot.cc/zXwMrFEWaVzMnZbB	{"id": 3, "tag": "23", "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-26 11:41:16.664587+00	2026-05-19 08:07:10.842748+00	\N	NO_RESET	23	687	\N	\N	\N	f
98	4f046240-eff7-4c9d-a004-429a283429c8	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-04-29 11:09:57.961+00	https://sub.begemot.cc/BzYcCE3YMW9Q-pdj	{"id": 3, "tag": "23", "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-26 11:09:57.923973+00	2026-05-19 08:07:10.846885+00	\N	NO_RESET	23	685	\N	\N	\N	f
97	233db169-e964-4eeb-9d46-ea18d83c3765	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-04-29 10:56:30.484+00	https://sub.begemot.cc/s1acXf2kDbFdURnK	{"id": 3, "tag": "23", "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-26 10:56:30.450664+00	2026-05-19 08:07:10.850918+00	\N	NO_RESET	23	684	\N	\N	\N	f
96	b214b55b-5f24-48ab-a76a-7ffe6504aab6	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-04-29 10:03:23.499+00	https://sub.begemot.cc/VHNckbZhXV4d9JVG	{"id": 3, "tag": "23", "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-26 10:03:23.451366+00	2026-05-19 08:07:10.855302+00	\N	NO_RESET	23	682	\N	\N	\N	f
95	954ea2b3-3152-4c35-a6e9-5b36c6000e00	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-04-29 10:00:56.012+00	https://sub.begemot.cc/NGpp_qeCPoDZZrmZ	{"id": 3, "tag": "23", "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-26 10:00:55.974321+00	2026-05-19 08:07:10.860257+00	\N	NO_RESET	23	681	\N	\N	\N	f
93	52d296ec-3d6e-4643-92b0-75d5e9ad7d73	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-04-29 07:55:58.905+00	https://sub.begemot.cc/x2p9A7qccSLeH373	{"id": 3, "tag": "23", "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-26 07:55:58.880735+00	2026-05-19 08:07:10.86447+00	\N	NO_RESET	23	680	\N	\N	\N	f
92	50b67999-dab8-4aaa-adaf-979af50459c7	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-04-29 04:18:17.08+00	https://sub.begemot.cc/q6wu3FgEoqHP98Rj	{"id": 3, "tag": "23", "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-26 04:18:17.034152+00	2026-05-19 08:07:10.868628+00	\N	NO_RESET	23	676	\N	\N	\N	f
91	c074ea17-f1e2-4b6e-a506-e109fb0e9200	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-04-29 03:15:35.755+00	https://sub.begemot.cc/TonELnVG0hyEMJed	{"id": 3, "tag": "23", "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-26 03:15:35.730421+00	2026-05-19 08:07:10.873235+00	\N	NO_RESET	23	675	\N	\N	\N	f
90	eca5054d-ea6c-420a-9784-c26030825350	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-04-29 02:12:27.483+00	https://sub.begemot.cc/JEVnHgKDtyKcX5wD	{"id": 3, "tag": "23", "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-26 02:12:27.457994+00	2026-05-19 08:07:10.877302+00	\N	NO_RESET	23	674	\N	\N	\N	f
89	1827a00e-417c-4ff3-b03e-051f94fe98df	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-04-29 01:43:49.667+00	https://sub.begemot.cc/fg1Wzt5PGuCHha75	{"id": 3, "tag": "23", "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-26 01:43:49.658942+00	2026-05-19 08:07:10.881412+00	\N	NO_RESET	23	673	\N	\N	\N	f
88	337faa1b-225a-4dfc-b378-d98b5d3070d8	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-04-29 01:18:16.509+00	https://sub.begemot.cc/vUtj4J-y0wRRoZ1W	{"id": 3, "tag": "23", "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-26 01:18:16.484989+00	2026-05-19 08:07:10.886132+00	\N	NO_RESET	23	672	\N	\N	\N	f
87	c03488df-8d86-4936-b7bc-90e3fd80ac0d	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-04-28 23:01:01.285+00	https://sub.begemot.cc/g4-abusSKjYNtDmp	{"id": 3, "tag": "23", "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-25 23:01:01.23811+00	2026-05-19 08:07:10.890524+00	\N	NO_RESET	23	668	\N	\N	\N	f
86	919b23a7-b811-4b05-8e81-178edfbbe147	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-04-28 21:24:13.889+00	https://sub.begemot.cc/DGcuMp-_Tputwb7y	{"id": 3, "tag": "23", "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-25 21:24:13.880846+00	2026-05-19 08:07:10.894389+00	\N	NO_RESET	23	667	\N	\N	\N	f
85	7ca1dd02-3ee7-4ed2-932e-dbcb4e6b303f	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-04-28 21:02:52.166+00	https://sub.begemot.cc/zMD1f75j9CejAgTU	{"id": 3, "tag": "23", "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-25 21:02:52.138169+00	2026-05-19 08:07:10.89828+00	\N	NO_RESET	23	666	\N	\N	\N	f
84	af742d2a-63d0-4245-b7f6-4563c6e0b8d3	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-04-28 20:43:28.846+00	https://sub.begemot.cc/PE_mxS5rwxxoBM93	{"id": 3, "tag": "23", "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-25 20:43:28.814863+00	2026-05-19 08:07:10.903285+00	\N	NO_RESET	23	665	\N	\N	\N	f
83	5dc8fd51-fade-4a6a-a460-3efc1454aab7	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-04-28 20:09:24.147+00	https://sub.begemot.cc/QHc4_6hWmTNdc51P	{"id": 3, "tag": "23", "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-25 20:09:24.092943+00	2026-05-19 08:07:10.907313+00	\N	NO_RESET	23	664	\N	\N	\N	f
82	298c4149-1605-407b-9b0c-c137d9164ca1	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-04-28 16:11:27.94+00	https://sub.begemot.cc/F7XtFK-c6Z1m9cn4	{"id": 3, "tag": "23", "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-25 16:11:27.928458+00	2026-05-19 08:07:10.911213+00	\N	NO_RESET	23	662	\N	\N	\N	f
81	9f86ccc9-341c-4d9c-8ebe-77e11b18dc77	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-04-28 14:19:03.881+00	https://sub.begemot.cc/V6N04Me30mc4MQ5s	{"id": 3, "tag": "23", "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-25 14:19:03.863025+00	2026-05-19 08:07:10.914944+00	\N	NO_RESET	23	655	\N	\N	\N	f
80	c332b7a0-2200-43bd-ab97-246e4fbce9cf	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-04-28 13:24:16.177+00	https://sub.begemot.cc/pHpeEGGwGWqQx499	{"id": 3, "tag": "23", "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-25 13:24:16.144566+00	2026-05-19 08:07:10.919602+00	\N	NO_RESET	23	654	\N	\N	\N	f
79	6088dbbe-8cc2-4169-8388-8f20d5ea9ee6	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-04-28 12:46:22.786+00	https://sub.begemot.cc/s-oDNZM5qZv65Spb	{"id": 3, "tag": "23", "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-25 12:46:22.772888+00	2026-05-19 08:07:10.923841+00	\N	NO_RESET	23	651	\N	\N	\N	f
78	a9e72b48-fca5-4458-94d8-486d538da85d	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-04-28 12:17:14.493+00	https://sub.begemot.cc/6toaHAgRzpta4d28	{"id": 3, "tag": "23", "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-25 12:17:14.464926+00	2026-05-19 08:07:10.92771+00	\N	NO_RESET	23	649	\N	\N	\N	f
77	6301327d-a765-4a74-97c4-0894f3d12b0f	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-04-28 12:08:48.88+00	https://sub.begemot.cc/AkpSXYEsjexMFW7w	{"id": 3, "tag": "23", "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-25 12:08:48.849541+00	2026-05-19 08:07:10.933137+00	\N	NO_RESET	23	616	\N	\N	\N	f
76	2a9336f7-46f1-4b24-b3a8-2aa1c8eea833	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-04-28 11:05:13.785+00	https://sub.begemot.cc/varpkovbAvfogpLA	{"id": 3, "tag": "23", "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-25 11:05:13.752389+00	2026-05-19 08:07:10.938576+00	\N	NO_RESET	23	645	\N	\N	\N	f
75	2442c8ef-5bce-4411-b8c9-bad60fc8ebc8	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-04-28 10:46:41.665+00	https://sub.begemot.cc/N0HHRY68NRg7AsEt	{"id": 3, "tag": "23", "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-25 10:46:41.65692+00	2026-05-19 08:07:10.942733+00	\N	NO_RESET	23	644	\N	\N	\N	f
74	21a54135-af95-4399-ab54-559127de1455	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-04-28 10:20:23.238+00	https://sub.begemot.cc/7r7xjxu1xQHC6gHa	{"id": 3, "tag": "23", "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-25 10:20:23.229259+00	2026-05-19 08:07:10.946761+00	\N	NO_RESET	23	642	\N	\N	\N	f
73	7d08901b-4fc5-4fa7-a88c-0c347650cc91	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-04-28 10:08:41.879+00	https://sub.begemot.cc/QdCPX6aZvzG-QLq2	{"id": 3, "tag": "23", "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-25 10:08:41.867417+00	2026-05-19 08:07:10.951866+00	\N	NO_RESET	23	641	\N	\N	\N	f
72	44202f1b-18da-4cc5-896c-f129a7b3e87a	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-04-28 08:05:35.383+00	https://sub.begemot.cc/GqPKdUyn1YQVE8n3	{"id": 3, "tag": "23", "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-25 08:05:35.374046+00	2026-05-19 08:07:10.955828+00	\N	NO_RESET	23	635	\N	\N	\N	f
71	10d0f941-aa2b-44d6-8900-87af72207adf	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-04-28 08:04:11.016+00	https://sub.begemot.cc/LzgQc32azcN5AT2N	{"id": 3, "tag": "23", "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-25 08:04:10.981037+00	2026-05-19 08:07:10.959648+00	\N	NO_RESET	23	634	\N	\N	\N	f
70	ea9bc269-22c5-453e-9a1d-3ae86a0d0101	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-04-28 08:01:55.475+00	https://sub.begemot.cc/w0qjFZMoM6-K2J6W	{"id": 3, "tag": "23", "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-25 08:01:55.443661+00	2026-05-19 08:07:10.964146+00	\N	NO_RESET	23	633	\N	\N	\N	f
69	5bc5f3fe-8534-4dfc-ae6c-c76e1469efba	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-04-28 07:31:24.09+00	https://sub.begemot.cc/BtC14A-73Pa_LdDx	{"id": 3, "tag": "23", "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-25 07:31:24.079612+00	2026-05-19 08:07:10.968241+00	\N	NO_RESET	23	630	\N	\N	\N	f
68	17c15027-657b-48e7-8a79-882d977d43b2	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-04-28 07:18:27.03+00	https://sub.begemot.cc/ShfjvkUEj0yS0p1D	{"id": 3, "tag": "23", "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-25 07:18:26.986637+00	2026-05-19 08:07:10.972067+00	\N	NO_RESET	23	629	\N	\N	\N	f
67	9d80f810-20aa-4a4e-9787-c5957192caf9	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-04-28 07:07:28.369+00	https://sub.begemot.cc/F_msEfDjT5zZ2GbL	{"id": 3, "tag": "23", "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-25 07:07:28.358907+00	2026-05-19 08:07:10.975917+00	\N	NO_RESET	23	628	\N	\N	\N	f
66	7fc8e3af-a770-44d3-9efb-cb75695bf323	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-04-28 07:02:29.484+00	https://sub.begemot.cc/-WwHdKnnu63mguSn	{"id": 3, "tag": "23", "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-25 07:02:29.470948+00	2026-05-19 08:07:10.980625+00	\N	NO_RESET	23	627	\N	\N	\N	f
65	28f2b95c-47a0-4777-aa0d-2afe1fd3692a	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-04-28 06:58:26.101+00	https://sub.begemot.cc/aEC9K8Ze1-1eEFCT	{"id": 3, "tag": "23", "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-25 06:58:26.065663+00	2026-05-19 08:07:10.984634+00	\N	NO_RESET	23	617	\N	\N	\N	f
64	488d91e6-cf5d-439a-a92a-811b566216b2	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-04-28 05:18:35.496+00	https://sub.begemot.cc/339vK2GQRXcj_FzF	{"id": 3, "tag": "23", "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-25 05:18:35.466681+00	2026-05-19 08:07:10.990403+00	\N	NO_RESET	23	621	\N	\N	\N	f
63	97c7346a-8ce3-45e4-9e97-814c60f1e484	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-04-28 03:37:08.63+00	https://sub.begemot.cc/NTWDoB4ARbRHpt4a	{"id": 3, "tag": "23", "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-25 03:37:08.618008+00	2026-05-19 08:07:10.995575+00	\N	NO_RESET	23	619	\N	\N	\N	f
60	1f007111-4ae5-4ec4-a235-411f86b0166c	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-04-27 21:31:53.912+00	https://sub.begemot.cc/XEVR2K421_ZuPpbQ	{"id": 3, "tag": "23", "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-24 21:31:53.887842+00	2026-05-19 08:07:11.009227+00	\N	NO_RESET	23	611	\N	\N	\N	f
58	869ded7d-ac4f-40bd-93e4-59fa00bcbb6e	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-04-27 21:07:33.364+00	https://sub.begemot.cc/-AaVyxfVsE4S6uXA	{"id": 3, "tag": "23", "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-24 21:07:33.354956+00	2026-05-19 08:07:11.018393+00	\N	NO_RESET	23	609	\N	\N	\N	f
57	cc896a28-0697-43f2-bd4f-d8526c1eb085	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-04-27 20:18:35.46+00	https://sub.begemot.cc/hhepgWVcKy0UEmHK	{"id": 3, "tag": "23", "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-24 20:18:35.428181+00	2026-05-19 08:07:11.023124+00	\N	NO_RESET	23	601	\N	\N	\N	f
56	b813870d-564d-41d7-b1af-4efcfb4e7c72	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-04-27 17:11:00.924+00	https://sub.begemot.cc/pZsyqvVjqngeV7ew	{"id": 3, "tag": "23", "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-24 17:11:00.89147+00	2026-05-19 08:07:11.028425+00	\N	NO_RESET	23	600	\N	\N	\N	f
54	895d5c30-0df7-4a03-b3b1-0b65ee1b670d	ACTIVE	f	0	2	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-07-23 09:28:21.026+00	https://sub.begemot.cc/y5vs6fmuKY_TEXb_	{"id": 7, "tag": null, "name": "Пара📱", "type": "DEVICES", "duration": 90, "is_trial": false, "device_limit": 2, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-24 09:28:20.913059+00	2026-05-19 08:07:11.037045+00	\N	NO_RESET	\N	597	\N	\N	\N	f
53	f3931b3e-2a3d-4e1d-8606-6b0071180001	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-04-27 05:41:21.385+00	https://sub.begemot.cc/296tPjZskrwXEbFH	{"id": 3, "tag": "23", "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-24 05:41:21.355216+00	2026-05-19 08:07:11.041191+00	\N	NO_RESET	23	596	\N	\N	\N	f
49	ea36da6b-23db-4b95-8775-8284e5a3c8c6	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-04-26 10:33:49.465+00	https://sub.begemot.cc/uJgQPNs8aPd5dDc_	{"id": 3, "tag": "23", "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-23 10:33:49.434343+00	2026-05-19 08:07:11.050031+00	\N	NO_RESET	23	592	\N	\N	\N	f
48	78867e47-3c05-48ee-a24c-d676f93c93a4	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-04-25 12:37:14.86+00	https://sub.begemot.cc/23hSVMVgaP0EowMx	{"id": 3, "tag": "23", "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-22 12:37:14.826877+00	2026-05-19 08:07:11.054364+00	\N	NO_RESET	23	590	\N	\N	\N	f
45	e727c6a9-baf0-4cbd-95de-aa9e5bcf2577	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-04-25 07:59:45.813+00	https://sub.begemot.cc/zrP77u24W_zBbcSs	{"id": 3, "tag": "23", "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-22 07:59:45.788583+00	2026-05-19 08:07:11.059104+00	\N	NO_RESET	23	589	\N	\N	\N	f
44	d3f53eef-962f-4375-9a38-73e3f4e5cab5	EXPIRED	f	0	2	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-05-21 18:18:38.432+00	https://sub.begemot.cc/6vFPYBPU0Pb507kh	{"id": 7, "tag": null, "name": "Пара📱", "type": "DEVICES", "duration": 30, "is_trial": false, "device_limit": 2, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-21 18:18:38.414941+00	2026-05-21 18:19:00.063719+00	\N	NO_RESET	\N	588	\N	\N	\N	f
94	c373bc68-3dd0-4738-a603-3ff53f17e1ad	DELETED	f	0	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-05-26 09:16:49.451+00	https://sub.begemot.cc/8kqBB1Q17j7TLMSz	{"id": 1, "tag": null, "name": "Личный", "type": "DEVICES", "duration": 30, "is_trial": false, "device_limit": 1, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-26 09:16:49.363654+00	2026-05-27 19:04:09.025717+00	\N	NO_RESET	\N	610	\N	\N	\N	f
29	d2262566-27b2-422d-8479-92f0e47c1c16	EXPIRED	t	10	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-04-22 17:06:04.727+00	https://sub.begemot.cc/TARzASymapUNgmLj	{"id": 3, "tag": "23", "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 10, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-19 17:06:04.704502+00	2026-05-19 08:07:11.111681+00	\N	NO_RESET	23	28	\N	\N	\N	f
28	f7f26fb7-9979-4e26-86cc-463fd6f0863d	EXPIRED	t	10	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-04-22 16:26:09.317+00	https://sub.begemot.cc/K3qD-r_nA15E3evp	{"id": 3, "tag": "23", "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 10, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-19 16:26:09.285708+00	2026-05-19 08:07:11.115855+00	\N	NO_RESET	23	27	\N	\N	\N	f
226	c8840626-42b2-4f91-9ccb-a9ac29720ed4	ACTIVE	f	0	2	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-07-16 18:07:16.127+00	https://sub.begemot.cc/xvkgmjpo6WVSZgHw	{"id": 13, "tag": null, "name": "👥 DUO · 2 📱 − выгоднее", "type": "DEVICES", "duration": 60, "is_trial": false, "device_limit": 2, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-05-17 18:07:16.055879+00	2026-05-19 08:07:11.121052+00	\N	NO_RESET	\N	26	\N	\N	\N	f
24	40eebf28-b234-44de-8fb8-6a0de4c4bb03	EXPIRED	t	10	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-04-22 09:29:26.065+00	https://sub.begemot.cc/T5-RU4nPUK5JUYbp	{"id": 3, "tag": "23", "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 10, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-19 09:29:26.055073+00	2026-05-19 08:07:11.125596+00	\N	NO_RESET	23	21	\N	\N	\N	f
218	2169cfa2-3059-4c11-8763-56bd0f25fe25	ACTIVE	f	0	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-07-13 06:19:15.589+00	https://sub.begemot.cc/bmw_nkLTnbSbqcRr	{"id": 12, "tag": null, "name": "👤 SOLO · 1 📱", "type": "DEVICES", "duration": 60, "is_trial": false, "device_limit": 1, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-05-14 06:19:15.524432+00	2026-05-19 08:07:11.129609+00	\N	NO_RESET	\N	15	\N	\N	\N	f
41	cd94ff3f-d359-42e6-8d4d-246caa9a9260	ACTIVE	f	0	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-07-19 16:55:21.173+00	https://sub.begemot.cc/3ycGHkPyn87mn9AP	{"id": 1, "tag": null, "name": "Персональный 📱", "type": "DEVICES", "duration": 30, "is_trial": false, "device_limit": 1, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-20 16:55:21.163068+00	2026-06-14 06:01:15.6797+00	\N	NO_RESET	\N	534	\N	\N	\N	f
227	52cb1c2d-afbf-4343-9bc2-6c30f98fdd33	ACTIVE	f	0	3	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-08-16 05:58:59.274+00	https://sub.begemot.cc/Kua42QjcE9wHtFqa	{"id": 14, "tag": null, "name": "🏠 HOME · 3 📱 ⭐ Хит", "type": "DEVICES", "duration": 30, "is_trial": false, "device_limit": 3, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-05-18 05:52:04.610964+00	2026-06-17 05:58:59.316703+00	\N	NO_RESET	\N	17	\N	\N	\N	f
225	daec057e-a131-4947-b885-6a9c12420d5d	ACTIVE	f	0	3	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-08-15 09:10:08.521+00	https://sub.begemot.cc/wvvCfV6zQMThdspv	{"id": 14, "tag": null, "name": "🏠 HOME · 3 📱 ⭐ Хит", "type": "DEVICES", "duration": 90, "is_trial": false, "device_limit": 3, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-05-17 09:10:08.431725+00	2026-05-19 08:07:11.138683+00	\N	NO_RESET	\N	4	\N	\N	\N	f
19	846db4aa-c422-4243-bba6-3c4a2d85c7de	EXPIRED	t	10	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-04-21 04:18:10.51+00	https://sub.begemot.cc/URtm-7E4NXdA6Lv1	{"id": 3, "tag": "23", "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 10, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-18 04:18:10.502644+00	2026-05-19 08:07:11.143303+00	\N	NO_RESET	23	22	\N	\N	\N	f
16	75022c3f-eabb-44f6-b3dc-cdeed54aa65d	EXPIRED	t	10	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-04-24 12:07:50.368+00	https://sub.begemot.cc/_C7Vgeb_6bT2eQmV	{"id": 3, "tag": "23", "name": "Пробный период", "type": "BOTH", "duration": 7, "is_trial": true, "device_limit": 1, "traffic_limit": 10, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-17 12:07:50.360134+00	2026-05-19 08:07:11.157545+00	\N	NO_RESET	23	19	\N	\N	\N	f
203	6d1cdc68-ea0b-47e3-bbef-83a8e71ae087	ACTIVE	f	0	3	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-11-03 05:48:39.43+00	https://sub.begemot.cc/Vd10xsXTvNDMvJFg	{"id": 14, "tag": null, "name": "🏠 HOME · 3 📱 ⭐ Хит", "type": "DEVICES", "duration": 180, "is_trial": false, "device_limit": 3, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-05-07 05:48:39.265644+00	2026-05-19 08:07:11.166071+00	\N	NO_RESET	\N	18	\N	\N	\N	f
10	c9b8a476-08df-4de5-9181-ac8377fb6095	ACTIVE	f	0	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-10-14 06:17:58.295+00	https://sub.begemot.cc/NctxNpmhQnNKF8Fc	{"id": 1, "tag": null, "name": "Персональный", "type": "DEVICES", "duration": 180, "is_trial": false, "device_limit": 1, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-17 06:17:58.285639+00	2026-05-19 08:07:11.174665+00	\N	NO_RESET	\N	12	\N	\N	\N	f
182	89cfcdf7-69ed-477c-8a66-d69c5799b733	ACTIVE	f	0	10	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-06-18 15:33:47.049+00	https://sub.begemot.cc/LdAyV7U5dZXgDWxV	{"id": 18, "tag": "BEST_VALUE", "name": "🚀 UNLIMITED · до 10 📱", "type": "DEVICES", "duration": 365, "is_trial": false, "device_limit": 10, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-05-02 20:19:20.815996+00	2026-05-19 15:33:47.134519+00	\N	NO_RESET	BEST_VALUE	2	\N	\N	\N	f
30	1d8daf46-e0ed-46d1-9ec7-7e704b457b41	EXPIRED	f	0	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-05-19 17:24:52.436+00	https://sub.begemot.cc/BUeaPMSqbuGyYcg0	{"id": 1, "tag": null, "name": "Персональный 📱", "type": "DEVICES", "duration": 30, "is_trial": false, "device_limit": 1, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-19 17:24:52.349683+00	2026-05-19 17:25:00.054735+00	\N	NO_RESET	\N	13	\N	\N	\N	f
39	b903036e-b1f0-436a-b9e0-ce0750dbd7c0	DELETED	f	0	3	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-06-18 19:03:03.854+00	https://sub.begemot.cc/ULb0Hwkc_bxqWeKy	{"id": 2, "tag": null, "name": "Семейный 3 📱", "type": "DEVICES", "duration": 30, "is_trial": false, "device_limit": 3, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-20 14:04:54.013076+00	2026-05-19 19:03:03.881289+00	\N	NO_RESET	\N	16	\N	\N	\N	f
149	67cce491-2090-45f2-8fde-bf215f375ff8	EXPIRED	f	0	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-05-30 06:03:27.461+00	https://sub.begemot.cc/mB3NgRStSxSdN0N0	{"id": 12, "tag": null, "name": "👤 SOLO · 1 📱", "type": "DEVICES", "duration": 30, "is_trial": false, "device_limit": 1, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-30 06:03:27.37068+00	2026-05-30 06:03:30.038109+00	\N	NO_RESET	\N	734	\N	\N	\N	f
262	a52940a2-004a-4d6f-b536-a2031ac78d46	EXPIRED	t	5	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-06-07 20:48:52.763+00	https://sub.begemot.cc/GRNKup7GkJqA_BHK	{"id": 11, "tag": null, "name": "Пробный период", "type": "BOTH", "duration": 3, "is_trial": true, "device_limit": 1, "traffic_limit": 5, "external_squad": null, "internal_squads": ["f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b"], "traffic_limit_strategy": "NO_RESET"}	2026-06-04 20:48:52.747246+00	2026-06-07 20:49:00.090228+00	\N	NO_RESET	\N	869	\N	\N	\N	f
219	e951a4f3-38f9-4a3c-8933-16a87bdef184	DELETED	f	0	3	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-07-12 06:38:54.028+00	https://sub.begemot.cc/J-o-PG8PNLB4GvEZ	{"id": 14, "tag": null, "name": "🏠 HOME · 3 📱 ⭐ Хит", "type": "DEVICES", "duration": 30, "is_trial": false, "device_limit": 3, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-05-14 18:56:14.743084+00	2026-06-12 06:38:54.059951+00	\N	NO_RESET	\N	20	\N	\N	\N	f
40	cd665a1b-dbd7-41dd-989a-8d326e5ed519	DELETED	f	0	2	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2026-12-14 06:14:39.882+00	https://sub.begemot.cc/C80QDXeAusXBVSup	{"id": 7, "tag": null, "name": "Пара📱", "type": "BOTH", "duration": 60, "is_trial": false, "device_limit": 2, "traffic_limit": 999999, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-20 16:31:16.601896+00	2026-06-17 06:14:39.916153+00	\N	NO_RESET	\N	10	\N	\N	\N	f
5	069bb805-12f4-4969-a9a3-b9c2958128bc	ACTIVE	f	0	1	{f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b}	2027-04-16 20:44:54.327+00	https://sub.begemot.cc/xAFGQNmAS92qjSap	{"id": 1, "tag": null, "name": "Персональный", "type": "DEVICES", "duration": 365, "is_trial": false, "device_limit": 1, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-16 20:44:54.316088+00	2026-06-23 09:58:44.919426+00	\N	NO_RESET	\N	9	\N	\N	\N	f
\.


--
-- Data for Name: support_messages; Type: TABLE DATA; Schema: public; Owner: remnashop
--

COPY public.support_messages (id, ticket_id, sender, body, created_at) FROM stdin;
1	1	user	Здравствуйте, не открывается ссылка	2026-06-22 21:14:51.589863+00
2	1	admin	здарова, принял проверяй	2026-06-23 08:15:00.232114+00
\.


--
-- Data for Name: support_tickets; Type: TABLE DATA; Schema: public; Owner: remnashop
--

COPY public.support_tickets (id, user_id, subject, status, created_at, updated_at) FROM stdin;
1	894	Тест: не подключается	closed	2026-06-22 21:14:51.581951+00	2026-06-28 18:00:34.267237+00
\.


--
-- Data for Name: transactions; Type: TABLE DATA; Schema: public; Owner: remnashop
--

COPY public.transactions (id, payment_id, status, is_test, purchase_type, gateway_type, pricing, currency, plan_snapshot, created_at, updated_at, user_id, gateway_display_name, payment_method) FROM stdin;
128	75a53daa-bd53-4fb9-87a9-b9b5f32a7f29	CANCELED	f	CHANGE	PLATEGA	{"final_amount": "129", "original_amount": "129.00", "discount_percent": 0}	RUB	{"id": 12, "tag": null, "name": "👤 SOLO · 1 📱", "type": "DEVICES", "duration": 30, "is_trial": false, "device_limit": 1, "traffic_limit": 0, "external_squad": null, "internal_squads": ["f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b"], "traffic_limit_strategy": "NO_RESET"}	2026-06-22 18:03:10.31819+00	2026-06-22 18:37:06.300016+00	1	\N	2
127	c407b4c3-bc5f-45b9-9933-016f0e7e7036	CANCELED	f	CHANGE	YOOMONEY	{"final_amount": "129", "original_amount": "129.00", "discount_percent": 0}	RUB	{"id": 12, "tag": null, "name": "👤 SOLO · 1 📱", "type": "DEVICES", "duration": 30, "is_trial": false, "device_limit": 1, "traffic_limit": 0, "external_squad": null, "internal_squads": ["f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b"], "traffic_limit_strategy": "NO_RESET"}	2026-06-22 18:02:45.09631+00	2026-06-22 19:00:00.076555+00	1	\N	\N
129	c8079fc2-c8df-458d-854e-08da6d827c25	CANCELED	f	NEW	YOOMONEY	{"final_amount": "799", "original_amount": "799.00", "discount_percent": 0}	RUB	{"id": 18, "tag": "BEST_VALUE", "name": "🚀 UNLIMITED · до 10 📱", "type": "DEVICES", "duration": 30, "is_trial": false, "device_limit": 10, "traffic_limit": 0, "external_squad": null, "internal_squads": ["f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b"], "traffic_limit_strategy": "NO_RESET"}	2026-06-24 04:37:24.577845+00	2026-06-24 05:30:00.037991+00	877	\N	\N
130	4b3546d1-9d4c-40f9-ab95-8c61bf1356aa	CANCELED	t	NEW	HELEKET	{"final_amount": "2", "original_amount": "2", "discount_percent": 0}	USD	{"id": -1, "tag": null, "name": "test", "type": "UNLIMITED", "duration": 0, "is_trial": false, "device_limit": 0, "traffic_limit": 0, "external_squad": null, "internal_squads": [], "traffic_limit_strategy": "NO_RESET"}	2026-06-25 18:49:19.154481+00	2026-06-25 19:20:18.047273+00	1	\N	\N
1	73b08b3e-2063-477b-9076-53af64e2b065	CANCELED	t	NEW	TELEGRAM_STARS	{"final_amount": "2", "original_amount": "2", "discount_percent": 0}	XTR	{"id": -1, "tag": null, "name": "test", "type": "UNLIMITED", "duration": 0, "is_trial": false, "device_limit": 0, "traffic_limit": 0, "external_squad": null, "internal_squads": [], "traffic_limit_strategy": "NO_RESET"}	2026-04-16 10:07:58.74004+00	2026-04-16 11:00:00.154122+00	1	\N	\N
131	2fae0039-1996-4686-9a74-4c2801211da3	CANCELED	f	NEW	TELEGRAM_STARS	{"final_amount": "72", "original_amount": "72.00", "discount_percent": 0}	XTR	{"id": 12, "tag": null, "name": "👤 SOLO · 1 📱", "type": "DEVICES", "duration": 30, "is_trial": false, "device_limit": 1, "traffic_limit": 0, "external_squad": null, "internal_squads": ["f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b"], "traffic_limit_strategy": "NO_RESET"}	2026-06-26 15:42:42.664997+00	2026-06-26 16:30:00.047276+00	903	\N	\N
132	5ae99b9a-7d7a-4400-9f45-56608db37367	COMPLETED	f	NEW	YOOMONEY	{"final_amount": "129", "original_amount": "129.00", "discount_percent": 0}	RUB	{"id": 12, "tag": null, "name": "👤 SOLO · 1 📱", "type": "DEVICES", "duration": 30, "is_trial": false, "device_limit": 1, "traffic_limit": 0, "external_squad": null, "internal_squads": ["f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b"], "traffic_limit_strategy": "NO_RESET"}	2026-06-26 15:43:02.167933+00	2026-06-26 15:44:37.708993+00	903	\N	\N
79	2521bdc7-2cab-42fe-bdb0-93e83ba19a05	COMPLETED	f	CHANGE	YOOMONEY	{"final_amount": "557", "original_amount": "929.00", "discount_percent": 40}	RUB	{"id": 14, "tag": null, "name": "🏠 HOME · 3 📱 ⭐ Хит", "type": "DEVICES", "duration": 90, "is_trial": false, "device_limit": 3, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-05-17 09:06:42.442295+00	2026-05-17 09:10:08.431725+00	4	\N	\N
82	a07e913b-15e4-4e54-96b1-d1188bf5d914	CANCELED	f	CHANGE	YOOMONEY	{"final_amount": "929", "original_amount": "929.00", "discount_percent": 0}	RUB	{"id": 14, "tag": null, "name": "🏠 HOME · 3 📱 ⭐ Хит", "type": "DEVICES", "duration": 90, "is_trial": false, "device_limit": 3, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-05-19 08:01:22.959614+00	2026-05-19 09:00:00.014906+00	6	\N	\N
96	82be63af-e6f3-4425-8ae3-2a3d57e5b227	CANCELED	f	CHANGE	TELEGRAM_STARS	{"final_amount": "136", "original_amount": "136.00", "discount_percent": 0}	XTR	{"id": 13, "tag": null, "name": "👥 DUO · 2 📱 − выгоднее", "type": "DEVICES", "duration": 30, "is_trial": false, "device_limit": 2, "traffic_limit": 0, "external_squad": null, "internal_squads": ["f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b"], "traffic_limit_strategy": "NO_RESET"}	2026-05-20 14:30:03.518478+00	2026-05-20 15:30:00.039397+00	7	\N	\N
97	960a4888-74d7-4371-8a19-08aad80bbe3f	CANCELED	f	CHANGE	PLATEGA	{"final_amount": "239", "original_amount": "239.00", "discount_percent": 0}	RUB	{"id": 13, "tag": null, "name": "👥 DUO · 2 📱 − выгоднее", "type": "DEVICES", "duration": 30, "is_trial": false, "device_limit": 2, "traffic_limit": 0, "external_squad": null, "internal_squads": ["f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b"], "traffic_limit_strategy": "NO_RESET"}	2026-05-20 14:30:22.024464+00	2026-05-20 15:30:00.039397+00	7	\N	\N
98	0fcc5920-be14-43bc-84e5-dc4ba7dfa2ee	CANCELED	t	NEW	YOOMONEY	{"final_amount": "2", "original_amount": "2", "discount_percent": 0}	RUB	{"id": -1, "tag": null, "name": "test", "type": "UNLIMITED", "duration": 0, "is_trial": false, "device_limit": 0, "traffic_limit": 0, "external_squad": null, "internal_squads": [], "traffic_limit_strategy": "NO_RESET"}	2026-05-20 19:22:33.903897+00	2026-05-20 20:00:00.3339+00	1	\N	\N
99	b22be972-ac79-4f3a-ba27-b3704ad06fa2	CANCELED	t	NEW	YOOMONEY	{"final_amount": "2", "original_amount": "2", "discount_percent": 0}	RUB	{"id": -1, "tag": null, "name": "test", "type": "UNLIMITED", "duration": 0, "is_trial": false, "device_limit": 0, "traffic_limit": 0, "external_squad": null, "internal_squads": [], "traffic_limit_strategy": "NO_RESET"}	2026-05-20 19:25:26.455846+00	2026-05-20 20:00:00.3339+00	1	\N	\N
108	680bc963-7609-4f15-850e-7352fed7ce13	CANCELED	f	NEW	YOOMONEY	{"final_amount": "349", "original_amount": "349.00", "discount_percent": 0}	RUB	{"id": 12, "tag": null, "name": "👤 SOLO · 1 📱", "type": "DEVICES", "duration": 90, "is_trial": false, "device_limit": 1, "traffic_limit": 0, "external_squad": null, "internal_squads": ["f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b"], "traffic_limit_strategy": "NO_RESET"}	2026-05-26 09:48:45.507936+00	2026-05-26 10:30:00.033876+00	591	\N	\N
109	dc98ed7e-ac2b-48e9-a061-503b26bf6bf0	CANCELED	f	NEW	PLATEGA	{"final_amount": "349", "original_amount": "349.00", "discount_percent": 0}	RUB	{"id": 12, "tag": null, "name": "👤 SOLO · 1 📱", "type": "DEVICES", "duration": 90, "is_trial": false, "device_limit": 1, "traffic_limit": 0, "external_squad": null, "internal_squads": ["f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b"], "traffic_limit_strategy": "NO_RESET"}	2026-05-26 09:50:28.861596+00	2026-05-26 10:30:23.201581+00	591	\N	\N
110	465c4bf8-f5df-4d96-98fb-4ee57118ab97	COMPLETED	f	CHANGE	YOOMONEY	{"final_amount": "129", "original_amount": "129.00", "discount_percent": 0}	RUB	{"id": 12, "tag": null, "name": "👤 SOLO · 1 📱", "type": "DEVICES", "duration": 30, "is_trial": false, "device_limit": 1, "traffic_limit": 0, "external_squad": null, "internal_squads": ["f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b"], "traffic_limit_strategy": "NO_RESET"}	2026-05-27 18:50:10.162502+00	2026-05-27 19:04:09.025717+00	610	\N	\N
112	d89e8336-855f-422a-8cee-87528cf04e47	CANCELED	f	CHANGE	YOOMONEY	{"final_amount": "349", "original_amount": "349.00", "discount_percent": 0}	RUB	{"id": 12, "tag": null, "name": "👤 SOLO · 1 📱", "type": "DEVICES", "duration": 90, "is_trial": false, "device_limit": 1, "traffic_limit": 0, "external_squad": null, "internal_squads": ["f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b"], "traffic_limit_strategy": "NO_RESET"}	2026-05-29 16:21:18.821708+00	2026-05-29 17:00:00.063257+00	699	\N	\N
113	85ba9a45-6f92-4eaa-ad37-5b6a05830414	CANCELED	f	CHANGE	TELEGRAM_STARS	{"final_amount": "200", "original_amount": "200.00", "discount_percent": 0}	XTR	{"id": 12, "tag": null, "name": "👤 SOLO · 1 📱", "type": "DEVICES", "duration": 90, "is_trial": false, "device_limit": 1, "traffic_limit": 0, "external_squad": null, "internal_squads": ["f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b"], "traffic_limit_strategy": "NO_RESET"}	2026-05-29 16:26:25.360482+00	2026-05-29 17:00:00.063257+00	699	\N	\N
111	d6b72423-ead9-4f71-a82e-4b2675ea2530	CANCELED	f	CHANGE	PLATEGA	{"final_amount": "349", "original_amount": "349.00", "discount_percent": 0}	RUB	{"id": 12, "tag": null, "name": "👤 SOLO · 1 📱", "type": "DEVICES", "duration": 90, "is_trial": false, "device_limit": 1, "traffic_limit": 0, "external_squad": null, "internal_squads": ["f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b"], "traffic_limit_strategy": "NO_RESET"}	2026-05-29 16:20:26.909801+00	2026-05-29 17:00:29.906326+00	699	\N	\N
114	d1207a9e-9302-4e57-9d89-0cfbdc40299d	CANCELED	f	CHANGE	PLATEGA	{"final_amount": "129", "original_amount": "129.00", "discount_percent": 0}	RUB	{"id": 12, "tag": null, "name": "👤 SOLO · 1 📱", "type": "DEVICES", "duration": 30, "is_trial": false, "device_limit": 1, "traffic_limit": 0, "external_squad": null, "internal_squads": ["f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b"], "traffic_limit_strategy": "NO_RESET"}	2026-05-30 05:42:15.189918+00	2026-05-30 06:23:01.123932+00	728	\N	\N
61	556dd71c-7f08-4104-8e40-32a26fe16df3	COMPLETED	f	NEW	YOOMONEY	{"final_amount": "740", "original_amount": "740.00", "discount_percent": 0}	RUB	{"id": 7, "tag": null, "name": "Пара📱", "type": "DEVICES", "duration": 90, "is_trial": false, "device_limit": 2, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-24 09:26:34.830413+00	2026-04-24 09:28:20.913059+00	597	\N	\N
2	0b09ee2d-b4ec-4746-a24e-8c2dd04a28a1	CANCELED	t	NEW	YOOMONEY	{"final_amount": "2", "original_amount": "2", "discount_percent": 0}	RUB	{"id": -1, "tag": null, "name": "test", "type": "UNLIMITED", "duration": 0, "is_trial": false, "device_limit": 0, "traffic_limit": 0, "external_squad": null, "internal_squads": [], "traffic_limit_strategy": "NO_RESET"}	2026-04-16 10:13:36.212676+00	2026-04-16 11:00:00.154122+00	1	\N	\N
88	56065fb6-c680-4fbd-8669-94e18605a01c	COMPLETED	t	NEW	PLATEGA	{"final_amount": "2", "original_amount": "2", "discount_percent": 0}	RUB	{"id": -1, "tag": null, "name": "test", "type": "UNLIMITED", "duration": 0, "is_trial": false, "device_limit": 0, "traffic_limit": 0, "external_squad": null, "internal_squads": [], "traffic_limit_strategy": "NO_RESET"}	2026-05-19 09:11:24.940278+00	2026-05-19 09:12:01.879426+00	1	\N	\N
118	1e4b84e3-d0b5-45f5-8fe0-bb4288655f81	COMPLETED	f	NEW	YOOMONEY	{"final_amount": "129", "original_amount": "129.00", "discount_percent": 0}	RUB	{"id": 12, "tag": null, "name": "👤 SOLO · 1 📱", "type": "DEVICES", "duration": 30, "is_trial": false, "device_limit": 1, "traffic_limit": 0, "external_squad": null, "internal_squads": ["f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b"], "traffic_limit_strategy": "NO_RESET"}	2026-06-01 15:43:37.925337+00	2026-06-01 15:44:39.916358+00	845	\N	\N
117	f33e5829-daf0-48cc-83d5-296a2572346e	CANCELED	f	NEW	YOOMONEY	{"final_amount": "129", "original_amount": "129.00", "discount_percent": 0}	RUB	{"id": 12, "tag": null, "name": "👤 SOLO · 1 📱", "type": "DEVICES", "duration": 30, "is_trial": false, "device_limit": 1, "traffic_limit": 0, "external_squad": null, "internal_squads": ["f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b"], "traffic_limit_strategy": "NO_RESET"}	2026-06-01 15:40:40.14421+00	2026-06-01 16:30:00.036069+00	845	\N	\N
119	e5e79eae-6f1e-4b0b-b5bc-132e8beb53e2	CANCELED	f	CHANGE	YOOMONEY	{"final_amount": "439", "original_amount": "439.00", "discount_percent": 0}	RUB	{"id": 15, "tag": null, "name": "👨‍👩‍👧 FAMILY · 4 📱", "type": "DEVICES", "duration": 30, "is_trial": false, "device_limit": 4, "traffic_limit": 0, "external_squad": null, "internal_squads": ["f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b"], "traffic_limit_strategy": "NO_RESET"}	2026-06-10 20:14:19.273368+00	2026-06-10 21:00:00.048985+00	20	\N	\N
3	7fecb809-12e4-4b52-8104-0dc011d197df	COMPLETED	f	NEW	TELEGRAM_STARS	{"final_amount": "0", "original_amount": "0", "discount_percent": 0}	XTR	{"id": 3, "tag": "23", "name": "Пробный период", "type": "BOTH", "duration": 7, "is_trial": false, "device_limit": 1, "traffic_limit": 10, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-16 17:22:09.543113+00	2026-04-16 17:22:12.162056+00	1	\N	\N
66	ed577132-c4ae-4cb5-92b1-a36488962949	COMPLETED	f	NEW	YOOMONEY	{"final_amount": "130", "original_amount": "130.00", "discount_percent": 0}	RUB	{"id": 1, "tag": null, "name": "Личный", "type": "DEVICES", "duration": 30, "is_trial": false, "device_limit": 1, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-26 09:14:59.105169+00	2026-04-26 09:16:49.363654+00	610	\N	\N
67	5b50d0c5-db4a-40d0-b643-000edcdc2b45	COMPLETED	f	NEW	YOOMONEY	{"final_amount": "129", "original_amount": "129.00", "discount_percent": 0}	RUB	{"id": 12, "tag": null, "name": "👤 SOLO · 1 📱", "type": "DEVICES", "duration": 30, "is_trial": false, "device_limit": 1, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-30 06:01:17.816617+00	2026-04-30 06:03:27.37068+00	734	\N	\N
4	e92ec242-d1c3-4f2c-b0ce-a7f1fa54d604	CANCELED	f	NEW	YOOMONEY	{"final_amount": "80", "original_amount": "80.00", "discount_percent": 0}	RUB	{"id": 1, "tag": null, "name": "Анонимус", "type": "UNLIMITED", "duration": 14, "is_trial": false, "device_limit": 0, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-16 17:26:07.103164+00	2026-04-16 18:00:00.214583+00	1	\N	\N
5	2a425e8c-f3b9-4a47-8e11-bb8ac96be391	CANCELED	f	NEW	TELEGRAM_STARS	{"final_amount": "100", "original_amount": "100.00", "discount_percent": 0}	XTR	{"id": 1, "tag": null, "name": "Анонимус", "type": "UNLIMITED", "duration": 14, "is_trial": false, "device_limit": 0, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-16 17:26:26.469184+00	2026-04-16 18:00:00.214583+00	1	\N	\N
6	412cc4a8-9015-42bc-9e20-5b85fa49f5d4	CANCELED	f	NEW	YOOMONEY	{"final_amount": "2400", "original_amount": "2400.00", "discount_percent": 0}	RUB	{"id": 2, "tag": null, "name": "Семейный", "type": "DEVICES", "duration": 180, "is_trial": false, "device_limit": 3, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-16 17:31:42.426045+00	2026-04-16 18:30:00.041392+00	1	\N	\N
7	034627e2-6244-4d42-b0d4-61b1fa5c35fb	CANCELED	t	NEW	YOOMONEY	{"final_amount": "2", "original_amount": "2", "discount_percent": 0}	RUB	{"id": -1, "tag": null, "name": "test", "type": "UNLIMITED", "duration": 0, "is_trial": false, "device_limit": 0, "traffic_limit": 0, "external_squad": null, "internal_squads": [], "traffic_limit_strategy": "NO_RESET"}	2026-04-16 17:32:06.314582+00	2026-04-16 18:30:00.041392+00	1	\N	\N
75	6da204d9-cb80-4e16-a3e3-16ad4f9a5ec8	CANCELED	f	CHANGE	YOOMONEY	{"final_amount": "339", "original_amount": "339.00", "discount_percent": 0}	RUB	{"id": 14, "tag": null, "name": "🏠 HOME · 3 📱 ⭐ Хит", "type": "DEVICES", "duration": 30, "is_trial": false, "device_limit": 3, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-05-14 05:52:50.579097+00	2026-05-14 06:30:00.161685+00	20	\N	\N
8	5c4ba368-2bad-44bc-87cd-d1d0450161a4	CANCELED	f	CHANGE	YOOMONEY	{"final_amount": "80", "original_amount": "80.00", "discount_percent": 0}	RUB	{"id": 1, "tag": null, "name": "Персональный", "type": "DEVICES", "duration": 14, "is_trial": false, "device_limit": 1, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-16 19:00:33.101632+00	2026-04-16 20:00:00.04761+00	2	\N	\N
9	3f9ec62c-e3a4-4d72-bbf5-f7544ed822b6	CANCELED	f	NEW	YOOMONEY	{"final_amount": "80", "original_amount": "80.00", "discount_percent": 0}	RUB	{"id": 1, "tag": null, "name": "Персональный", "type": "DEVICES", "duration": 14, "is_trial": false, "device_limit": 1, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-16 19:20:46.131181+00	2026-04-16 20:00:00.04761+00	1	\N	\N
20	96742ce2-a8be-4e87-a63e-770cbbfbf364	COMPLETED	t	NEW	YOOMONEY	{"final_amount": "2", "original_amount": "2", "discount_percent": 0}	RUB	{"id": -1, "tag": null, "name": "test", "type": "UNLIMITED", "duration": 0, "is_trial": false, "device_limit": 0, "traffic_limit": 0, "external_squad": null, "internal_squads": [], "traffic_limit_strategy": "NO_RESET"}	2026-04-17 07:28:46.20142+00	2026-04-17 07:30:32.921376+00	1	\N	\N
19	4489d998-02e2-444a-a573-edc944686cb4	CANCELED	t	NEW	YOOMONEY	{"final_amount": "2", "original_amount": "2", "discount_percent": 0}	RUB	{"id": -1, "tag": null, "name": "test", "type": "UNLIMITED", "duration": 0, "is_trial": false, "device_limit": 0, "traffic_limit": 0, "external_squad": null, "internal_squads": [], "traffic_limit_strategy": "NO_RESET"}	2026-04-17 07:22:53.743197+00	2026-04-17 08:00:00.03184+00	1	\N	\N
31	033d2d5d-aece-4626-951e-9c8f10d79f0c	CANCELED	t	NEW	HELEKET	{"final_amount": "2", "original_amount": "2", "discount_percent": 0}	USD	{"id": -1, "tag": null, "name": "test", "type": "UNLIMITED", "duration": 0, "is_trial": false, "device_limit": 0, "traffic_limit": 0, "external_squad": null, "internal_squads": [], "traffic_limit_strategy": "NO_RESET"}	2026-04-17 13:28:46.92531+00	2026-04-17 14:00:21.58739+00	1	\N	\N
10	a9032185-2032-4f13-9428-6ab15d997f55	CANCELED	f	NEW	YOOMONEY	{"final_amount": "80", "original_amount": "80.00", "discount_percent": 0}	RUB	{"id": 1, "tag": null, "name": "Персональный", "type": "DEVICES", "duration": 14, "is_trial": false, "device_limit": 1, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-16 19:28:11.279023+00	2026-04-16 20:00:00.04761+00	1	\N	\N
11	e49fc544-1e59-4728-9d1f-6b9729b237f4	CANCELED	f	CHANGE	YOOMONEY	{"final_amount": "80", "original_amount": "80.00", "discount_percent": 0}	RUB	{"id": 1, "tag": null, "name": "Персональный", "type": "DEVICES", "duration": 14, "is_trial": false, "device_limit": 1, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-16 19:28:41.459488+00	2026-04-16 20:00:00.04761+00	2	\N	\N
72	44a86258-097d-4e0a-8b16-1abc83ebfe5c	COMPLETED	f	NEW	YOOMONEY	{"final_amount": "349", "original_amount": "349.00", "discount_percent": 0}	RUB	{"id": 12, "tag": null, "name": "👤 SOLO · 1 📱", "type": "DEVICES", "duration": 90, "is_trial": false, "device_limit": 1, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-05-11 18:35:55.024419+00	2026-05-11 18:37:23.494156+00	603	\N	\N
12	3970e41a-c7f3-472b-ad26-2faeada94622	CANCELED	f	NEW	TELEGRAM_STARS	{"final_amount": "0", "original_amount": "0", "discount_percent": 0}	XTR	{"id": 3, "tag": "23", "name": "Пробный период", "type": "BOTH", "duration": 7, "is_trial": false, "device_limit": 1, "traffic_limit": 10, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-16 20:25:14.690707+00	2026-04-16 21:00:00.395227+00	5	\N	\N
13	b551d08e-4ba7-49e5-8ac9-04053881ad42	COMPLETED	f	NEW	TELEGRAM_STARS	{"final_amount": "0", "original_amount": "0", "discount_percent": 0}	XTR	{"id": 3, "tag": "23", "name": "Пробный период", "type": "BOTH", "duration": 7, "is_trial": true, "device_limit": 1, "traffic_limit": 10, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-17 06:02:29.831943+00	2026-04-17 06:02:34.109328+00	10	\N	\N
14	8534e552-cf7e-4aa6-b286-3a1bf85fa572	CANCELED	f	NEW	TELEGRAM_STARS	{"final_amount": "412", "original_amount": "412.00", "discount_percent": 0}	XTR	{"id": 1, "tag": null, "name": "Персональный", "type": "DEVICES", "duration": 180, "is_trial": false, "device_limit": 1, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-17 06:03:11.218559+00	2026-04-17 07:00:00.246335+00	12	\N	\N
15	8967c6cb-5d9d-4b8e-8fd9-7d6c5c249ac2	CANCELED	f	NEW	YOOMONEY	{"final_amount": "725", "original_amount": "725.00", "discount_percent": 0}	RUB	{"id": 1, "tag": null, "name": "Персональный", "type": "DEVICES", "duration": 180, "is_trial": false, "device_limit": 1, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-17 06:03:34.496948+00	2026-04-17 07:00:00.246335+00	12	\N	\N
16	1aa3c60a-f42a-4a59-aaba-60e5f243e8be	CANCELED	t	NEW	YOOMONEY	{"final_amount": "2", "original_amount": "2", "discount_percent": 0}	RUB	{"id": -1, "tag": null, "name": "test", "type": "UNLIMITED", "duration": 0, "is_trial": false, "device_limit": 0, "traffic_limit": 0, "external_squad": null, "internal_squads": [], "traffic_limit_strategy": "NO_RESET"}	2026-04-17 06:13:53.234525+00	2026-04-17 07:00:00.246335+00	1	\N	\N
17	0f2d76cc-c19a-4b95-a2f9-69a794def4fc	CANCELED	f	CHANGE	YOOMONEY	{"final_amount": "80", "original_amount": "80.00", "discount_percent": 0}	RUB	{"id": 1, "tag": null, "name": "Персональный", "type": "DEVICES", "duration": 14, "is_trial": false, "device_limit": 1, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-17 06:36:04.956984+00	2026-04-17 07:30:00.047154+00	2	\N	\N
21	acc7d91f-7ff1-4092-bb65-6308fac3596b	COMPLETED	f	CHANGE	YOOMONEY	{"final_amount": "80", "original_amount": "80.00", "discount_percent": 0}	RUB	{"id": 1, "tag": null, "name": "Персональный", "type": "DEVICES", "duration": 14, "is_trial": false, "device_limit": 1, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-17 07:34:08.019185+00	2026-04-17 07:35:34.73726+00	1	\N	\N
23	3be1ad22-28e2-4238-8270-6ecf706cb2b1	COMPLETED	t	NEW	TELEGRAM_STARS	{"final_amount": "2", "original_amount": "2", "discount_percent": 0}	XTR	{"id": -1, "tag": null, "name": "test", "type": "UNLIMITED", "duration": 0, "is_trial": false, "device_limit": 0, "traffic_limit": 0, "external_squad": null, "internal_squads": [], "traffic_limit_strategy": "NO_RESET"}	2026-04-17 07:42:28.702173+00	2026-04-17 07:42:32.222111+00	1	\N	\N
18	46f0823f-4fc0-4aaa-9594-25452ece156e	CANCELED	t	NEW	YOOMONEY	{"final_amount": "2", "original_amount": "2", "discount_percent": 0}	RUB	{"id": -1, "tag": null, "name": "test", "type": "UNLIMITED", "duration": 0, "is_trial": false, "device_limit": 0, "traffic_limit": 0, "external_squad": null, "internal_squads": [], "traffic_limit_strategy": "NO_RESET"}	2026-04-17 07:14:09.667587+00	2026-04-17 08:00:00.03184+00	1	\N	\N
22	4a9c19df-f3fa-481f-add4-6c612d44f972	CANCELED	t	NEW	TELEGRAM_STARS	{"final_amount": "2", "original_amount": "2", "discount_percent": 0}	XTR	{"id": -1, "tag": null, "name": "test", "type": "UNLIMITED", "duration": 0, "is_trial": false, "device_limit": 0, "traffic_limit": 0, "external_squad": null, "internal_squads": [], "traffic_limit_strategy": "NO_RESET"}	2026-04-17 07:40:05.666409+00	2026-04-17 08:30:00.160823+00	1	\N	\N
24	435260e8-ef5e-47ef-817e-72641fa5db9b	CANCELED	f	NEW	YOOMONEY	{"final_amount": "80", "original_amount": "80.00", "discount_percent": 0}	RUB	{"id": 1, "tag": null, "name": "Персональный", "type": "DEVICES", "duration": 14, "is_trial": false, "device_limit": 1, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-17 08:31:05.766943+00	2026-04-17 09:30:00.040709+00	1	\N	\N
32	a9f14c75-b15b-4d3c-a6de-aba6f67d076d	CANCELED	t	NEW	HELEKET	{"final_amount": "2", "original_amount": "2", "discount_percent": 0}	USD	{"id": -1, "tag": null, "name": "test", "type": "UNLIMITED", "duration": 0, "is_trial": false, "device_limit": 0, "traffic_limit": 0, "external_squad": null, "internal_squads": [], "traffic_limit_strategy": "NO_RESET"}	2026-04-17 13:28:59.528878+00	2026-04-17 14:00:18.420534+00	1	\N	\N
54	6f3af380-d535-4254-9c9e-3d2014b91cc9	COMPLETED	t	NEW	PLATEGA	{"final_amount": "2", "original_amount": "2", "discount_percent": 0}	RUB	{"id": -1, "tag": null, "name": "test", "type": "UNLIMITED", "duration": 0, "is_trial": false, "device_limit": 0, "traffic_limit": 0, "external_squad": null, "internal_squads": [], "traffic_limit_strategy": "NO_RESET"}	2026-04-21 18:06:55.915464+00	2026-04-21 18:07:44.541931+00	1	\N	\N
62	83375daf-94d1-43bf-a255-8d58e2741b17	CANCELED	f	NEW	PLATEGA	{"final_amount": "80", "original_amount": "80.00", "discount_percent": 0}	RUB	{"id": 1, "tag": null, "name": "Личный", "type": "DEVICES", "duration": 14, "is_trial": false, "device_limit": 1, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-25 03:09:04.669044+00	2026-04-25 03:51:51.324647+00	617	\N	\N
25	ac4fa24d-2813-4d4f-8acb-b8abd04a8842	COMPLETED	f	NEW	YOOMONEY	{"final_amount": "80", "original_amount": "80.00", "discount_percent": 0}	RUB	{"id": 1, "tag": null, "name": "Персональный", "type": "DEVICES", "duration": 14, "is_trial": false, "device_limit": 1, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-17 08:32:17.00019+00	2026-04-17 08:33:02.836947+00	1	\N	\N
68	cd751055-f69b-4474-8ff7-ea5d2d20fddc	COMPLETED	f	NEW	PLATEGA	{"final_amount": "129", "original_amount": "129.00", "discount_percent": 0}	RUB	{"id": 12, "tag": null, "name": "👤 SOLO · 1 📱", "type": "DEVICES", "duration": 30, "is_trial": false, "device_limit": 1, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-30 07:27:03.215588+00	2026-04-30 07:29:36.2239+00	728	\N	\N
26	e40fc61e-7671-414b-906a-dd64fff79b6f	CANCELED	f	NEW	YOOMONEY	{"final_amount": "370", "original_amount": "370.00", "discount_percent": 0}	RUB	{"id": 2, "tag": null, "name": "Семейный", "type": "DEVICES", "duration": 30, "is_trial": false, "device_limit": 3, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-17 10:45:17.244366+00	2026-04-17 11:30:00.150965+00	17	\N	\N
27	bf3d4673-09aa-43b5-b151-2610e9dfb2ac	CANCELED	f	CHANGE	YOOMONEY	{"final_amount": "370", "original_amount": "370.00", "discount_percent": 0}	RUB	{"id": 2, "tag": null, "name": "Семейный", "type": "DEVICES", "duration": 30, "is_trial": false, "device_limit": 3, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-17 10:48:48.048131+00	2026-04-17 11:30:00.150965+00	1	\N	\N
73	599a64e1-c23b-4e08-9bd5-75f817a743dc	CANCELED	f	RENEW	YOOMONEY	{"final_amount": "600", "original_amount": "600.00", "discount_percent": 0}	RUB	{"id": 10, "tag": null, "name": "Канатбек", "type": "DEVICES", "duration": 30, "is_trial": false, "device_limit": 7, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-05-12 13:13:19.535756+00	2026-05-12 14:00:00.232678+00	3	\N	\N
77	a4f0e096-6604-41f9-b726-beb302ea551e	COMPLETED	f	CHANGE	YOOMONEY	{"final_amount": "339", "original_amount": "339.00", "discount_percent": 0}	RUB	{"id": 14, "tag": null, "name": "🏠 HOME · 3 📱 ⭐ Хит", "type": "DEVICES", "duration": 30, "is_trial": false, "device_limit": 3, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-05-14 18:54:41.972587+00	2026-05-14 18:56:14.743084+00	20	\N	\N
30	d87b1aa2-b48f-4158-a3fa-2573c1c2e014	COMPLETED	t	NEW	HELEKET	{"final_amount": "2", "original_amount": "2", "discount_percent": 0}	USD	{"id": -1, "tag": null, "name": "test", "type": "UNLIMITED", "duration": 0, "is_trial": false, "device_limit": 0, "traffic_limit": 0, "external_squad": null, "internal_squads": [], "traffic_limit_strategy": "NO_RESET"}	2026-04-17 13:14:55.597121+00	2026-04-17 13:23:04.467618+00	1	\N	\N
28	d84b0569-58b5-4465-b439-237bf5db78cc	CANCELED	t	NEW	HELEKET	{"final_amount": "2", "original_amount": "2", "discount_percent": 0}	USD	{"id": -1, "tag": null, "name": "test", "type": "UNLIMITED", "duration": 0, "is_trial": false, "device_limit": 0, "traffic_limit": 0, "external_squad": null, "internal_squads": [], "traffic_limit_strategy": "NO_RESET"}	2026-04-17 12:29:06.294264+00	2026-04-17 13:24:05.748224+00	1	\N	\N
80	48fc872d-eeb2-448e-90c9-47923835a919	COMPLETED	f	CHANGE	YOOMONEY	{"final_amount": "449", "original_amount": "449.00", "discount_percent": 0}	RUB	{"id": 13, "tag": null, "name": "👥 DUO · 2 📱 − выгоднее", "type": "DEVICES", "duration": 60, "is_trial": false, "device_limit": 2, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-05-17 18:01:30.521598+00	2026-05-17 18:07:16.055879+00	26	\N	\N
29	bdef05a6-5cbf-4e3d-8c9d-2832a855db55	CANCELED	t	NEW	HELEKET	{"final_amount": "2", "original_amount": "2", "discount_percent": 0}	USD	{"id": -1, "tag": null, "name": "test", "type": "UNLIMITED", "duration": 0, "is_trial": false, "device_limit": 0, "traffic_limit": 0, "external_squad": null, "internal_squads": [], "traffic_limit_strategy": "NO_RESET"}	2026-04-17 12:58:33.14916+00	2026-04-17 13:30:18.182728+00	1	\N	\N
63	bd58780e-7be9-4453-9fef-f9a210fdb86e	CANCELED	f	NEW	YOOMONEY	{"final_amount": "130", "original_amount": "130.00", "discount_percent": 0}	RUB	{"id": 1, "tag": null, "name": "Личный", "type": "DEVICES", "duration": 30, "is_trial": false, "device_limit": 1, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-25 06:48:23.643598+00	2026-04-25 07:30:00.122111+00	24	\N	\N
33	d08f8871-a8f5-4ed8-a246-e141dd357096	CANCELED	f	NEW	YOOMONEY	{"final_amount": "370", "original_amount": "370.00", "discount_percent": 0}	RUB	{"id": 2, "tag": null, "name": "Семейный", "type": "DEVICES", "duration": 30, "is_trial": false, "device_limit": 3, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-17 17:46:35.439437+00	2026-04-17 18:30:00.104939+00	20	\N	\N
34	692c4f74-9542-460a-8abc-12b8d9fd9a85	CANCELED	t	NEW	YOOMONEY	{"final_amount": "2", "original_amount": "2", "discount_percent": 0}	RUB	{"id": -1, "tag": null, "name": "test", "type": "UNLIMITED", "duration": 0, "is_trial": false, "device_limit": 0, "traffic_limit": 0, "external_squad": null, "internal_squads": [], "traffic_limit_strategy": "NO_RESET"}	2026-04-17 17:53:08.419602+00	2026-04-17 18:30:00.104939+00	1	\N	\N
35	2e4d2ae4-1dda-4ac9-8164-66f71b21ae49	CANCELED	f	CHANGE	YOOMONEY	{"final_amount": "80", "original_amount": "80.00", "discount_percent": 0}	RUB	{"id": 1, "tag": null, "name": "Персональный", "type": "DEVICES", "duration": 14, "is_trial": false, "device_limit": 1, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-17 19:32:06.596469+00	2026-04-17 20:30:00.11345+00	1	\N	\N
69	47735c2d-e06b-4383-9bce-3fba2787f42f	COMPLETED	f	NEW	PLATEGA	{"final_amount": "129", "original_amount": "129.00", "discount_percent": 0}	RUB	{"id": 12, "tag": null, "name": "👤 SOLO · 1 📱", "type": "DEVICES", "duration": 30, "is_trial": false, "device_limit": 1, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-05-03 11:38:18.603191+00	2026-05-03 11:42:43.440102+00	743	\N	\N
36	ddee5cf3-9c4e-4d9e-9951-796f7bd6cb57	CANCELED	f	CHANGE	HELEKET	{"final_amount": "1", "original_amount": "1.00", "discount_percent": 0}	USD	{"id": 1, "tag": null, "name": "Персональный", "type": "DEVICES", "duration": 14, "is_trial": false, "device_limit": 1, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-17 21:35:17.351576+00	2026-04-17 22:06:16.381053+00	1	\N	\N
74	136e6510-e418-4384-b552-70befba6a679	COMPLETED	f	NEW	YOOMONEY	{"final_amount": "129", "original_amount": "129.00", "discount_percent": 0}	RUB	{"id": 12, "tag": null, "name": "👤 SOLO · 1 📱", "type": "DEVICES", "duration": 30, "is_trial": false, "device_limit": 1, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-05-13 12:35:59.219341+00	2026-05-13 12:38:18.251071+00	608	\N	\N
37	5fcb93da-2758-47f5-b560-87a62659f951	CANCELED	f	NEW	HELEKET	{"final_amount": "17.5", "original_amount": "17.50", "discount_percent": 0}	USD	{"id": 1, "tag": null, "name": "Персональный", "type": "DEVICES", "duration": 365, "is_trial": false, "device_limit": 1, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-18 04:36:31.207229+00	2026-04-18 05:08:15.442356+00	22	\N	\N
38	6fbb4497-6c44-416e-9252-0aa2902bbc29	CANCELED	f	NEW	YOOMONEY	{"final_amount": "1400", "original_amount": "1400.00", "discount_percent": 0}	RUB	{"id": 1, "tag": null, "name": "Персональный", "type": "DEVICES", "duration": 365, "is_trial": false, "device_limit": 1, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-18 04:36:47.490862+00	2026-04-18 05:30:00.09979+00	22	\N	\N
78	f29b07ab-357a-4cb1-8e81-3bf86d53f3d4	COMPLETED	f	CHANGE	YOOMONEY	{"final_amount": "129", "original_amount": "129.00", "discount_percent": 0}	RUB	{"id": 12, "tag": null, "name": "👤 SOLO · 1 📱", "type": "DEVICES", "duration": 30, "is_trial": false, "device_limit": 1, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-05-15 16:02:55.8924+00	2026-05-15 16:03:57.44973+00	5	\N	\N
39	44b998c3-6c24-4f42-b76e-1417f3309b7b	CANCELED	f	NEW	YOOMONEY	{"final_amount": "130", "original_amount": "130.00", "discount_percent": 0}	RUB	{"id": 1, "tag": null, "name": "Персональный", "type": "DEVICES", "duration": 30, "is_trial": false, "device_limit": 1, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-18 14:55:56.212273+00	2026-04-18 15:30:00.054602+00	5	\N	\N
81	6444a242-33eb-43a7-a3b2-5be78870e11d	COMPLETED	f	CHANGE	YOOMONEY	{"final_amount": "339", "original_amount": "339.00", "discount_percent": 0}	RUB	{"id": 14, "tag": null, "name": "🏠 HOME · 3 📱 ⭐ Хит", "type": "DEVICES", "duration": 30, "is_trial": false, "device_limit": 3, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-05-18 05:50:45.438355+00	2026-05-18 05:52:04.610964+00	17	\N	\N
40	976eb643-a5a2-44dd-a3f8-7f9741f5390f	CANCELED	f	NEW	YOOMONEY	{"final_amount": "130", "original_amount": "130.00", "discount_percent": 0}	RUB	{"id": 1, "tag": null, "name": "Персональный", "type": "DEVICES", "duration": 30, "is_trial": false, "device_limit": 1, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-18 15:11:47.907555+00	2026-04-18 16:00:00.15143+00	4	\N	\N
41	da456b64-368f-4517-8619-69ce6c45c02a	CANCELED	f	NEW	YOOMONEY	{"final_amount": "370", "original_amount": "370.00", "discount_percent": 0}	RUB	{"id": 2, "tag": null, "name": "Семейный", "type": "DEVICES", "duration": 30, "is_trial": false, "device_limit": 3, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-18 15:47:40.705979+00	2026-04-18 16:30:00.114898+00	4	\N	\N
42	a3657521-d043-4b07-8e30-3ed320846912	CANCELED	f	NEW	TELEGRAM_STARS	{"final_amount": "74", "original_amount": "74.00", "discount_percent": 0}	XTR	{"id": 1, "tag": null, "name": "Персональный", "type": "DEVICES", "duration": 30, "is_trial": false, "device_limit": 1, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-18 17:18:40.447397+00	2026-04-18 18:00:00.156688+00	15	\N	\N
43	4bac4daa-59d9-4af1-829e-71ee264a68fb	CANCELED	f	NEW	YOOMONEY	{"final_amount": "130", "original_amount": "130.00", "discount_percent": 0}	RUB	{"id": 1, "tag": null, "name": "Персональный", "type": "DEVICES", "duration": 30, "is_trial": false, "device_limit": 1, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-18 17:19:26.737493+00	2026-04-18 18:00:00.156688+00	15	\N	\N
44	3aeee138-b511-4465-a6ca-1fd827febf30	COMPLETED	t	NEW	HELEKET	{"final_amount": "2", "original_amount": "2", "discount_percent": 0}	USD	{"id": -1, "tag": null, "name": "test", "type": "UNLIMITED", "duration": 0, "is_trial": false, "device_limit": 0, "traffic_limit": 0, "external_squad": null, "internal_squads": [], "traffic_limit_strategy": "NO_RESET"}	2026-04-19 07:30:49.198477+00	2026-04-19 07:33:43.680655+00	1	\N	\N
70	9b7a5919-67d1-497b-9198-a926a03e7c04	COMPLETED	f	NEW	YOOMONEY	{"final_amount": "129", "original_amount": "129.00", "discount_percent": 0}	RUB	{"id": 12, "tag": null, "name": "👤 SOLO · 1 📱", "type": "DEVICES", "duration": 30, "is_trial": false, "device_limit": 1, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-05-05 05:58:17.067238+00	2026-05-05 05:59:27.045239+00	816	\N	\N
45	9d0c20f9-c398-4e98-833f-d176a93eeae4	CANCELED	f	NEW	TELEGRAM_STARS	{"final_amount": "210", "original_amount": "210.00", "discount_percent": 0}	XTR	{"id": 1, "tag": null, "name": "Персональный", "type": "DEVICES", "duration": 90, "is_trial": false, "device_limit": 1, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-19 11:58:12.899837+00	2026-04-19 12:30:00.115884+00	25	\N	\N
46	a0afdc10-42cc-4217-b49c-2a66753d464d	COMPLETED	f	CHANGE	YOOMONEY	{"final_amount": "2", "original_amount": "2.00", "discount_percent": 0}	RUB	{"id": 6, "tag": null, "name": "Тест", "type": "BOTH", "duration": 7, "is_trial": false, "device_limit": 1, "traffic_limit": 100, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-19 13:23:01.060431+00	2026-04-19 13:23:55.998255+00	1	\N	\N
47	7b737af8-4398-48ac-97b9-f2598323bb45	COMPLETED	f	NEW	YOOMONEY	{"final_amount": "130", "original_amount": "130.00", "discount_percent": 0}	RUB	{"id": 1, "tag": null, "name": "Персональный 📱", "type": "DEVICES", "duration": 30, "is_trial": false, "device_limit": 1, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-19 17:22:59.82791+00	2026-04-19 17:24:52.349683+00	13	\N	\N
48	ec1d260f-3fa5-4311-9f2e-b779b086a97d	COMPLETED	f	NEW	YOOMONEY	{"final_amount": "370", "original_amount": "370.00", "discount_percent": 0}	RUB	{"id": 2, "tag": null, "name": "Семейный 3 📱", "type": "DEVICES", "duration": 30, "is_trial": false, "device_limit": 3, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-19 17:43:49.239913+00	2026-04-19 17:44:50.510004+00	6	\N	\N
49	dd4893d6-a0bd-41a9-8a94-d553897ee1e5	COMPLETED	f	NEW	YOOMONEY	{"final_amount": "370", "original_amount": "370.00", "discount_percent": 0}	RUB	{"id": 2, "tag": null, "name": "Семейный 3 📱", "type": "DEVICES", "duration": 30, "is_trial": false, "device_limit": 3, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-20 05:48:29.208775+00	2026-04-20 05:50:14.679319+00	17	\N	\N
50	c2f5f14b-0f32-444b-9c18-c30ca6c7e4e9	COMPLETED	f	NEW	YOOMONEY	{"final_amount": "370", "original_amount": "370.00", "discount_percent": 0}	RUB	{"id": 1, "tag": null, "name": "Персональный", "type": "DEVICES", "duration": 90, "is_trial": false, "device_limit": 1, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-20 09:18:58.417656+00	2026-04-20 09:20:02.567777+00	25	\N	\N
51	bcc4c9af-0e5f-41f6-8a65-97e262041b28	COMPLETED	f	NEW	YOOMONEY	{"final_amount": "370", "original_amount": "370.00", "discount_percent": 0}	RUB	{"id": 2, "tag": null, "name": "Семейный 3 📱", "type": "DEVICES", "duration": 30, "is_trial": false, "device_limit": 3, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-20 14:01:37.747738+00	2026-04-20 14:04:54.013076+00	16	\N	\N
52	5b582fe8-ba71-4f00-a1d8-6b540fdd46b2	COMPLETED	f	CHANGE	YOOMONEY	{"final_amount": "500", "original_amount": "500.00", "discount_percent": 0}	RUB	{"id": 7, "tag": null, "name": "Пара📱", "type": "BOTH", "duration": 60, "is_trial": false, "device_limit": 2, "traffic_limit": 999999, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-20 16:30:08.847945+00	2026-04-20 16:31:16.601896+00	10	\N	\N
53	21f35aa9-b07a-4310-a5d0-98e6d0f1607f	COMPLETED	f	NEW	YOOMONEY	{"final_amount": "130", "original_amount": "130.00", "discount_percent": 0}	RUB	{"id": 1, "tag": null, "name": "Персональный 📱", "type": "DEVICES", "duration": 30, "is_trial": false, "device_limit": 1, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-21 14:34:27.542798+00	2026-04-21 14:39:42.411536+00	587	\N	\N
56	3e817e58-cfba-461b-b95e-d09e49a99bbc	CANCELED	f	RENEW	PLATEGA	{"final_amount": "370", "original_amount": "370.00", "discount_percent": 0}	RUB	{"id": 2, "tag": null, "name": "Семейный 3 📱", "type": "DEVICES", "duration": 30, "is_trial": false, "device_limit": 3, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-21 18:09:42.499054+00	2026-04-21 18:54:03.043047+00	1	\N	\N
55	d8125a18-63ac-416c-85d6-8c0d6f54743f	CANCELED	f	RENEW	PLATEGA	{"final_amount": "370", "original_amount": "370.00", "discount_percent": 0}	RUB	{"id": 2, "tag": null, "name": "Семейный 3 📱", "type": "DEVICES", "duration": 30, "is_trial": false, "device_limit": 3, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-21 18:07:49.037858+00	2026-04-21 18:54:04.604528+00	1	\N	\N
57	beb0b5f5-ac40-488c-8ca3-3d21fbd7373b	CANCELED	f	NEW	YOOMONEY	{"final_amount": "80", "original_amount": "80.00", "discount_percent": 0}	RUB	{"id": 1, "tag": null, "name": "Персональный 📱", "type": "DEVICES", "duration": 14, "is_trial": false, "device_limit": 1, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-22 08:00:12.887168+00	2026-04-22 09:00:00.13097+00	589	\N	\N
59	96150a60-aa2d-4398-a853-f1459717b341	COMPLETED	f	NEW	PLATEGA	{"final_amount": "130", "original_amount": "130.00", "discount_percent": 0}	RUB	{"id": 1, "tag": null, "name": "Личный", "type": "DEVICES", "duration": 30, "is_trial": false, "device_limit": 1, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-23 10:45:05.407418+00	2026-04-23 10:51:00.13191+00	593	\N	\N
58	5cd58157-c76b-4d00-9a01-28d206788b31	CANCELED	f	NEW	YOOMONEY	{"final_amount": "130", "original_amount": "130.00", "discount_percent": 0}	RUB	{"id": 1, "tag": null, "name": "Личный", "type": "DEVICES", "duration": 30, "is_trial": false, "device_limit": 1, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-23 10:44:58.380179+00	2026-04-23 11:30:00.135282+00	593	\N	\N
60	6d284aec-70e0-4db1-8312-b391d89b8dc3	CANCELED	f	NEW	TELEGRAM_STARS	{"final_amount": "74", "original_amount": "74.00", "discount_percent": 0}	XTR	{"id": 1, "tag": null, "name": "Личный", "type": "DEVICES", "duration": 30, "is_trial": false, "device_limit": 1, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-23 10:45:19.650731+00	2026-04-23 11:30:00.135282+00	593	\N	\N
64	08d1e614-11fa-4cfd-bd27-fac7466d56a3	CANCELED	f	NEW	TELEGRAM_STARS	{"final_amount": "74", "original_amount": "74.00", "discount_percent": 0}	XTR	{"id": 1, "tag": null, "name": "Личный", "type": "DEVICES", "duration": 30, "is_trial": false, "device_limit": 1, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-25 10:33:23.337583+00	2026-04-25 11:30:00.105902+00	590	\N	\N
65	0b9be817-d0d6-40aa-bc60-11c66e2597e9	CANCELED	f	NEW	YOOMONEY	{"final_amount": "130", "original_amount": "130.00", "discount_percent": 0}	RUB	{"id": 1, "tag": null, "name": "Личный", "type": "DEVICES", "duration": 30, "is_trial": false, "device_limit": 1, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-04-25 10:34:04.439726+00	2026-04-25 11:30:00.105902+00	590	\N	\N
71	ec68723a-e884-4cf6-bb54-4c84a2bf2efe	COMPLETED	f	CHANGE	PLATEGA	{"final_amount": "1759", "original_amount": "1759.00", "discount_percent": 0}	RUB	{"id": 14, "tag": null, "name": "🏠 HOME · 3 📱 ⭐ Хит", "type": "DEVICES", "duration": 180, "is_trial": false, "device_limit": 3, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-05-07 05:47:00.778614+00	2026-05-07 05:48:39.265644+00	18	\N	\N
76	8f7374c6-0a55-4aa3-95c4-118aebb35f3c	COMPLETED	f	CHANGE	YOOMONEY	{"final_amount": "239", "original_amount": "239.00", "discount_percent": 0}	RUB	{"id": 12, "tag": null, "name": "👤 SOLO · 1 📱", "type": "DEVICES", "duration": 60, "is_trial": false, "device_limit": 1, "traffic_limit": 0, "external_squad": null, "internal_squads": ["7d3c2f79-92d4-4384-b5e0-4dadb7cda374"], "traffic_limit_strategy": "NO_RESET"}	2026-05-14 06:17:28.118124+00	2026-05-14 06:19:15.524432+00	15	\N	\N
83	8ff0b258-d751-4c0e-82b4-f7d183cad8d4	CANCELED	t	NEW	YOOMONEY	{"final_amount": "2", "original_amount": "2", "discount_percent": 0}	RUB	{"id": -1, "tag": null, "name": "test", "type": "UNLIMITED", "duration": 0, "is_trial": false, "device_limit": 0, "traffic_limit": 0, "external_squad": null, "internal_squads": [], "traffic_limit_strategy": "NO_RESET"}	2026-05-19 08:22:46.129836+00	2026-05-19 09:00:00.014906+00	1	\N	\N
84	fa232a7d-f429-4055-b57f-dfe332a0b48c	CANCELED	t	NEW	YOOMONEY	{"final_amount": "2", "original_amount": "2", "discount_percent": 0}	RUB	{"id": -1, "tag": null, "name": "test", "type": "UNLIMITED", "duration": 0, "is_trial": false, "device_limit": 0, "traffic_limit": 0, "external_squad": null, "internal_squads": [], "traffic_limit_strategy": "NO_RESET"}	2026-05-19 08:26:22.562391+00	2026-05-19 09:00:00.014906+00	1	\N	\N
85	d91c13d1-9be6-4f4c-b3ac-16eea20b74c2	CANCELED	t	NEW	YOOMONEY	{"final_amount": "2", "original_amount": "2", "discount_percent": 0}	RUB	{"id": -1, "tag": null, "name": "test", "type": "UNLIMITED", "duration": 0, "is_trial": false, "device_limit": 0, "traffic_limit": 0, "external_squad": null, "internal_squads": [], "traffic_limit_strategy": "NO_RESET"}	2026-05-19 08:26:31.212237+00	2026-05-19 09:00:00.014906+00	1	\N	\N
86	6e91edb4-1ab1-4293-b430-72f4dee1f116	CANCELED	t	NEW	YOOMONEY	{"final_amount": "2", "original_amount": "2", "discount_percent": 0}	RUB	{"id": -1, "tag": null, "name": "test", "type": "UNLIMITED", "duration": 0, "is_trial": false, "device_limit": 0, "traffic_limit": 0, "external_squad": null, "internal_squads": [], "traffic_limit_strategy": "NO_RESET"}	2026-05-19 08:53:49.074224+00	2026-05-19 09:30:00.017109+00	1	\N	\N
87	10fe0652-ab49-4431-bf1f-d48c7da5b80d	CANCELED	t	NEW	YOOMONEY	{"final_amount": "2", "original_amount": "2", "discount_percent": 0}	RUB	{"id": -1, "tag": null, "name": "test", "type": "UNLIMITED", "duration": 0, "is_trial": false, "device_limit": 0, "traffic_limit": 0, "external_squad": null, "internal_squads": [], "traffic_limit_strategy": "NO_RESET"}	2026-05-19 09:04:09.247364+00	2026-05-19 10:00:00.057731+00	1	\N	\N
91	f9cf012b-9b8e-48aa-923e-9b7d6ce71e6b	CANCELED	t	NEW	YOOMONEY	{"final_amount": "2", "original_amount": "2", "discount_percent": 0}	RUB	{"id": -1, "tag": null, "name": "test", "type": "UNLIMITED", "duration": 0, "is_trial": false, "device_limit": 0, "traffic_limit": 0, "external_squad": null, "internal_squads": [], "traffic_limit_strategy": "NO_RESET"}	2026-05-19 15:40:50.225604+00	2026-05-19 16:30:00.280424+00	1	\N	\N
89	d90dadaa-4049-4ca9-94ce-68fa6f90b138	CANCELED	t	NEW	YOOMONEY	{"final_amount": "2", "original_amount": "2", "discount_percent": 0}	RUB	{"id": -1, "tag": null, "name": "test", "type": "UNLIMITED", "duration": 0, "is_trial": false, "device_limit": 0, "traffic_limit": 0, "external_squad": null, "internal_squads": [], "traffic_limit_strategy": "NO_RESET"}	2026-05-19 15:37:43.252039+00	2026-05-19 16:30:00.280424+00	1	\N	\N
90	99c54cfc-a826-4e87-8ad8-94fe321c2481	CANCELED	t	NEW	YOOMONEY	{"final_amount": "2", "original_amount": "2", "discount_percent": 0}	RUB	{"id": -1, "tag": null, "name": "test", "type": "UNLIMITED", "duration": 0, "is_trial": false, "device_limit": 0, "traffic_limit": 0, "external_squad": null, "internal_squads": [], "traffic_limit_strategy": "NO_RESET"}	2026-05-19 15:40:04.025649+00	2026-05-19 16:30:00.280424+00	1	\N	\N
92	8dd6d919-2ce2-4f89-a762-2c92bee30a5b	COMPLETED	t	NEW	PLATEGA	{"final_amount": "2", "original_amount": "2", "discount_percent": 0}	RUB	{"id": -1, "tag": null, "name": "test", "type": "UNLIMITED", "duration": 0, "is_trial": false, "device_limit": 0, "traffic_limit": 0, "external_squad": null, "internal_squads": [], "traffic_limit_strategy": "NO_RESET"}	2026-05-19 18:31:47.973095+00	2026-05-19 18:32:10.767762+00	1	\N	\N
93	dddc3bc1-f246-4956-8bdd-6e3377070066	COMPLETED	f	CHANGE	PLATEGA	{"final_amount": "339", "original_amount": "339.00", "discount_percent": 0}	RUB	{"id": 14, "tag": null, "name": "🏠 HOME · 3 📱 ⭐ Хит", "type": "DEVICES", "duration": 30, "is_trial": false, "device_limit": 3, "traffic_limit": 0, "external_squad": null, "internal_squads": ["f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b"], "traffic_limit_strategy": "NO_RESET"}	2026-05-19 19:01:18.31581+00	2026-05-19 19:03:03.82674+00	16	\N	\N
95	1285fb14-ebcd-44e3-8aa3-3a1b01220232	COMPLETED	f	CHANGE	PLATEGA	{"final_amount": "449", "original_amount": "449.00", "discount_percent": 0}	RUB	{"id": 13, "tag": null, "name": "👥 DUO · 2 📱 − выгоднее", "type": "DEVICES", "duration": 60, "is_trial": false, "device_limit": 2, "traffic_limit": 0, "external_squad": null, "internal_squads": ["f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b"], "traffic_limit_strategy": "NO_RESET"}	2026-05-19 19:14:45.701731+00	2026-05-19 19:20:26.971613+00	587	\N	\N
94	c1cee37f-44e1-48b2-b026-13eafe5d65fa	CANCELED	f	CHANGE	TELEGRAM_STARS	{"final_amount": "194", "original_amount": "194.00", "discount_percent": 0}	XTR	{"id": 14, "tag": null, "name": "🏠 HOME · 3 📱 ⭐ Хит", "type": "DEVICES", "duration": 30, "is_trial": false, "device_limit": 3, "traffic_limit": 0, "external_squad": null, "internal_squads": ["f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b"], "traffic_limit_strategy": "NO_RESET"}	2026-05-19 19:01:48.038949+00	2026-05-19 20:00:00.04182+00	16	\N	\N
100	28bf96d3-7268-44ca-a14e-5c5e62e50bac	CANCELED	t	NEW	YOOMONEY	{"final_amount": "2", "original_amount": "2", "discount_percent": 0}	RUB	{"id": -1, "tag": null, "name": "test", "type": "UNLIMITED", "duration": 0, "is_trial": false, "device_limit": 0, "traffic_limit": 0, "external_squad": null, "internal_squads": [], "traffic_limit_strategy": "NO_RESET"}	2026-05-20 19:32:10.168208+00	2026-05-20 20:30:00.009419+00	1	\N	\N
101	755c6c85-e23b-4fb7-b2bd-100612ee8ed1	CANCELED	t	NEW	YOOMONEY	{"final_amount": "2", "original_amount": "2", "discount_percent": 0}	RUB	{"id": -1, "tag": null, "name": "test", "type": "UNLIMITED", "duration": 0, "is_trial": false, "device_limit": 0, "traffic_limit": 0, "external_squad": null, "internal_squads": [], "traffic_limit_strategy": "NO_RESET"}	2026-05-20 19:35:44.822401+00	2026-05-20 20:30:00.009419+00	1	\N	\N
102	57698ea0-c085-44d8-b4cb-26f538559224	CANCELED	t	NEW	YOOMONEY	{"final_amount": "2", "original_amount": "2", "discount_percent": 0}	RUB	{"id": -1, "tag": null, "name": "test", "type": "UNLIMITED", "duration": 0, "is_trial": false, "device_limit": 0, "traffic_limit": 0, "external_squad": null, "internal_squads": [], "traffic_limit_strategy": "NO_RESET"}	2026-05-20 19:39:39.439484+00	2026-05-20 20:30:00.009419+00	1	\N	\N
103	d79b13b4-6317-4b58-a99f-856883df03e5	COMPLETED	t	NEW	YOOMONEY	{"final_amount": "2", "original_amount": "2", "discount_percent": 0}	RUB	{"id": -1, "tag": null, "name": "test", "type": "UNLIMITED", "duration": 0, "is_trial": false, "device_limit": 0, "traffic_limit": 0, "external_squad": null, "internal_squads": [], "traffic_limit_strategy": "NO_RESET"}	2026-05-21 05:03:35.639447+00	2026-05-21 05:04:11.117692+00	1	\N	\N
104	31df4968-c2dc-414f-883a-797167e2c810	COMPLETED	f	CHANGE	PLATEGA	{"final_amount": "129", "original_amount": "129.00", "discount_percent": 0}	RUB	{"id": 12, "tag": null, "name": "👤 SOLO · 1 📱", "type": "DEVICES", "duration": 30, "is_trial": false, "device_limit": 1, "traffic_limit": 0, "external_squad": null, "internal_squads": ["f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b"], "traffic_limit_strategy": "NO_RESET"}	2026-05-24 11:36:43.115178+00	2026-05-24 11:38:11.015281+00	593	\N	\N
105	69e96e9a-f052-44f2-a5de-26d4ce6230af	CANCELED	f	NEW	YOOMONEY	{"final_amount": "349", "original_amount": "349.00", "discount_percent": 0}	RUB	{"id": 12, "tag": null, "name": "👤 SOLO · 1 📱", "type": "DEVICES", "duration": 90, "is_trial": false, "device_limit": 1, "traffic_limit": 0, "external_squad": null, "internal_squads": ["f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b"], "traffic_limit_strategy": "NO_RESET"}	2026-05-25 14:06:10.208254+00	2026-05-25 15:00:00.041044+00	591	\N	\N
106	090d5e87-94fa-4236-b3f2-129d0fa1ff9c	CANCELED	f	NEW	YOOMONEY	{"final_amount": "349", "original_amount": "349.00", "discount_percent": 0}	RUB	{"id": 12, "tag": null, "name": "👤 SOLO · 1 📱", "type": "DEVICES", "duration": 90, "is_trial": false, "device_limit": 1, "traffic_limit": 0, "external_squad": null, "internal_squads": ["f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b"], "traffic_limit_strategy": "NO_RESET"}	2026-05-25 14:06:50.554054+00	2026-05-25 15:00:00.041044+00	591	\N	\N
107	259519e3-dc57-4962-8729-d4aa4c4422d7	CANCELED	f	NEW	YOOMONEY	{"final_amount": "129", "original_amount": "129.00", "discount_percent": 0}	RUB	{"id": 12, "tag": null, "name": "👤 SOLO · 1 📱", "type": "DEVICES", "duration": 30, "is_trial": false, "device_limit": 1, "traffic_limit": 0, "external_squad": null, "internal_squads": ["f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b"], "traffic_limit_strategy": "NO_RESET"}	2026-05-26 07:29:54.243769+00	2026-05-26 08:00:00.038156+00	591	\N	\N
115	d520d51b-e2f1-4565-9061-c87ab2a0a717	COMPLETED	f	CHANGE	YOOMONEY	{"final_amount": "349", "original_amount": "349.00", "discount_percent": 0}	RUB	{"id": 12, "tag": null, "name": "👤 SOLO · 1 📱", "type": "DEVICES", "duration": 90, "is_trial": false, "device_limit": 1, "traffic_limit": 0, "external_squad": null, "internal_squads": ["f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b"], "traffic_limit_strategy": "NO_RESET"}	2026-05-30 10:22:36.76557+00	2026-05-30 10:34:46.39851+00	699	\N	\N
116	b39368af-7b8c-4fba-aaae-639608916cf1	COMPLETED	f	CHANGE	PLATEGA	{"final_amount": "129", "original_amount": "129.00", "discount_percent": 0}	RUB	{"id": 12, "tag": null, "name": "👤 SOLO · 1 📱", "type": "DEVICES", "duration": 30, "is_trial": false, "device_limit": 1, "traffic_limit": 0, "external_squad": null, "internal_squads": ["f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b"], "traffic_limit_strategy": "NO_RESET"}	2026-05-30 13:53:50.518099+00	2026-05-30 13:55:33.162319+00	728	\N	\N
120	b0c076b4-c91e-4566-877c-6f68a6fc7ace	COMPLETED	f	CHANGE	YOOMONEY	{"final_amount": "349", "original_amount": "349.00", "discount_percent": 0}	RUB	{"id": 12, "tag": null, "name": "👤 SOLO · 1 📱", "type": "DEVICES", "duration": 90, "is_trial": false, "device_limit": 1, "traffic_limit": 0, "external_squad": null, "internal_squads": ["f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b"], "traffic_limit_strategy": "NO_RESET"}	2026-06-11 16:32:01.802562+00	2026-06-11 16:32:59.193719+00	5	\N	\N
121	f666e1a4-4bfe-4faf-8c34-ff51895977c3	COMPLETED	f	CHANGE	YOOMONEY	{"final_amount": "339", "original_amount": "339.00", "discount_percent": 0}	RUB	{"id": 14, "tag": null, "name": "🏠 HOME · 3 📱 ⭐ Хит", "type": "DEVICES", "duration": 30, "is_trial": false, "device_limit": 3, "traffic_limit": 0, "external_squad": null, "internal_squads": ["f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b"], "traffic_limit_strategy": "NO_RESET"}	2026-06-12 06:37:16.655094+00	2026-06-12 06:38:53.989779+00	20	\N	\N
122	5d3830b5-3ef2-4744-be8b-e3837a95c68c	COMPLETED	f	CHANGE	YOOMONEY	{"final_amount": "649", "original_amount": "649.00", "discount_percent": 0}	RUB	{"id": 14, "tag": null, "name": "🏠 HOME · 3 📱 ⭐ Хит", "type": "DEVICES", "duration": 60, "is_trial": false, "device_limit": 3, "traffic_limit": 0, "external_squad": null, "internal_squads": ["f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b"], "traffic_limit_strategy": "NO_RESET"}	2026-06-17 05:57:39.400121+00	2026-06-17 05:58:59.247598+00	17	\N	\N
123	ad950239-df79-4d9e-8fb5-3b902fbe3fc7	COMPLETED	f	CHANGE	YOOMONEY	{"final_amount": "1209", "original_amount": "1209.00", "discount_percent": 0}	RUB	{"id": 13, "tag": null, "name": "👥 DUO · 2 📱 − выгоднее", "type": "DEVICES", "duration": 180, "is_trial": false, "device_limit": 2, "traffic_limit": 0, "external_squad": null, "internal_squads": ["f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b"], "traffic_limit_strategy": "NO_RESET"}	2026-06-17 06:13:19.878464+00	2026-06-17 06:14:39.85623+00	10	\N	\N
124	c2d3bdc5-1ae6-4e67-b748-559e013534c3	COMPLETED	f	RENEW	PLATEGA	{"final_amount": "339", "original_amount": "339.00", "discount_percent": 0}	RUB	{"id": 14, "tag": null, "name": "🏠 HOME · 3 📱 ⭐ Хит", "type": "DEVICES", "duration": 30, "is_trial": false, "device_limit": 3, "traffic_limit": 0, "external_squad": null, "internal_squads": ["f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b"], "traffic_limit_strategy": "NO_RESET"}	2026-06-18 04:34:28.12793+00	2026-06-18 04:35:13.632938+00	16	\N	\N
126	8eab54cd-893a-450e-8805-9b462903e49f	COMPLETED	f	RENEW	YOOMONEY	{"final_amount": "239", "original_amount": "239.00", "discount_percent": 0}	RUB	{"id": 13, "tag": null, "name": "👥 DUO · 2 📱 − выгоднее", "type": "DEVICES", "duration": 30, "is_trial": false, "device_limit": 2, "traffic_limit": 0, "external_squad": null, "internal_squads": ["f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b"], "traffic_limit_strategy": "NO_RESET"}	2026-06-18 18:31:18.973769+00	2026-06-18 18:32:32.549361+00	7	\N	\N
125	a229da63-1c31-4e95-a26a-ed9be807c3bc	CANCELED	f	RENEW	YOOMONEY	{"final_amount": "239", "original_amount": "239.00", "discount_percent": 0}	RUB	{"id": 13, "tag": null, "name": "👥 DUO · 2 📱 − выгоднее", "type": "DEVICES", "duration": 30, "is_trial": false, "device_limit": 2, "traffic_limit": 0, "external_squad": null, "internal_squads": ["f92bc02d-ac1d-46cc-b5c2-9b6045ecc59b"], "traffic_limit_strategy": "NO_RESET"}	2026-06-18 18:31:00.691001+00	2026-06-18 19:30:00.060103+00	7	\N	\N
\.


--
-- Data for Name: user_oauth_providers; Type: TABLE DATA; Schema: public; Owner: remnashop
--

COPY public.user_oauth_providers (id, user_id, provider, provider_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: remnashop
--

COPY public.users (id, telegram_id, username, name, role, language, personal_discount, purchase_discount, is_blocked, is_bot_blocked, current_subscription_id, created_at, updated_at, referral_code, points, is_rules_accepted, is_trial_available, email, password_hash, is_email_verified, pending_email, email_verification_code_hash, email_verification_expires_at, auth_type, ad_link_id, referral_code_reset_at) FROM stdin;
21	1394034854	plategabottest	PLATEGA	USER	RU	0	0	f	f	24	2026-04-17 16:10:29.197848+00	2026-04-19 09:29:26.055073+00	uEdTxM	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
19	8078468447	hrthrtgbdfvbsdghjyj	ᅠ	USER	RU	0	0	f	f	16	2026-04-17 12:07:47.444922+00	2026-04-17 12:07:50.360134+00	29C8ar	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
663	5675941740	HellgaM1225	Яло	USER	RU	0	0	f	t	\N	2026-04-25 16:36:23.379887+00	2026-04-25 16:37:11.105516+00	baWT7I	0	t	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
13	5256051267	Ksenia_Bursuk	Ксения	USER	RU	0	0	f	f	30	2026-04-17 05:45:43.631848+00	2026-04-19 17:24:52.349683+00	cgJ4Md	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
717	5566641771	zzz_eee_sss	$$$	USER	RU	0	0	f	f	131	2026-04-28 11:18:51.395427+00	2026-04-28 11:18:55.704955+00	BVmy8b	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
11	6205390666	\N	Danya Sergeevich	USER	RU	0	0	f	f	\N	2026-04-17 03:49:02.185313+00	2026-04-17 06:12:48.697464+00	jUyv48	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
675	7759184945	Lbdoqfhxissk53	7759184945	USER	RU	0	0	f	t	91	2026-04-26 03:15:05.221011+00	2026-04-26 03:17:17.981263+00	cQxh5p	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
8	1640268421	\N	Айпери Суйимбек кызы	USER	RU	0	0	f	f	\N	2026-04-16 20:43:04.545254+00	2026-04-17 06:13:12.912261+00	xdRpGD	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
12	478979333	Diana_Evsyukova	Диана	USER	RU	0	0	f	f	10	2026-04-17 04:11:21.370138+00	2026-04-17 06:17:58.285639+00	HXoYlP	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
694	8097606820	myasoedil	Artem Brodyaga	USER	RU	0	0	f	f	106	2026-04-26 15:18:58.583266+00	2026-04-26 15:19:04.674928+00	XR8qQm	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
700	5887257461	xTGSx	TGS	USER	RU	0	0	f	f	\N	2026-04-27 10:02:38.428655+00	2026-04-29 00:09:40.216201+00	ZCHQNi	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
727	1818767165	yanaruot	Lina	USER	RU	0	0	f	t	137	2026-04-28 19:29:21.96786+00	2026-04-29 19:51:40.335207+00	ortEE9	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
791	6096347627	\N	Senya	USER	RU	0	0	f	t	\N	2026-05-03 09:42:32.96909+00	2026-05-10 06:12:54.008472+00	wZeJYN	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
698	6300464896	HABbICOTE	winteam	USER	RU	0	0	f	f	110	2026-04-27 06:14:22.911966+00	2026-04-27 06:14:37.623447+00	y8XuPg	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
822	8777277767	tolleranttg	ᴛоᴧᴧᴇᴩᴀнᴛ tolleranttg	USER	RU	0	0	f	f	202	2026-05-06 21:04:29.825017+00	2026-05-06 21:04:34.412528+00	bqLeq7	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
18	1337030857	Daria_Bakunina	Дарья	USER	RU	0	0	f	f	203	2026-04-17 10:52:15.458564+00	2026-05-07 05:48:39.265644+00	wVaERQ	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
823	6733386723	\N	Максим Максимов	USER	RU	0	0	f	t	\N	2026-05-07 10:02:21.456543+00	2026-05-16 05:16:02.146184+00	7zJ1G4	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
3	1301243503	Kanatbek_Mamaseitov	Канатбек Мамасеитов	USER	RU	0	0	f	f	224	2026-04-16 20:10:11.610889+00	2026-05-16 13:56:56.319497+00	blrEsP	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
22	1489283201	wwfomix	Jeka_ya	USER	RU	0	0	f	f	19	2026-04-18 04:17:17.043342+00	2026-04-18 04:18:10.502644+00	vk2chW	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
23	462113585	kot6egemot	Сергей К	USER	RU	0	0	f	f	\N	2026-04-18 05:37:28.852525+00	2026-04-18 05:37:31.015828+00	r8hiR6	0	t	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
686	5480821126	\N	Олег	USER	RU	0	0	f	t	\N	2026-04-26 11:18:04.074907+00	2026-05-18 15:11:22.47273+00	x1sXzI	0	t	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
701	8063096566	\N	Лариса Павловна	USER	RU	0	0	f	t	115	2026-04-27 10:09:53.000217+00	2026-04-27 10:35:45.780538+00	pSctXV	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
702	1349626770	\N	Алексей Дроздов	USER	RU	0	0	f	f	\N	2026-04-27 11:42:17.973449+00	2026-04-27 11:42:21.384033+00	zeyAja	0	t	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
42	7450035785	\N	Владимир Посадский	USER	RU	0	0	f	f	\N	2026-04-20 14:22:51.991031+00	2026-04-20 14:22:51.991031+00	bbMzqK	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
43	7172951429	\N	Пётр Быков	USER	RU	0	0	f	f	\N	2026-04-20 14:22:51.992305+00	2026-04-20 14:22:51.992305+00	mkv239	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
26	5572930262	Seregakol	Серега	USER	RU	0	0	f	f	226	2026-04-19 12:44:49.831568+00	2026-05-17 18:07:16.055879+00	F1kdDK	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
649	8369385343	Zas0h	Nikita	USER	RU	0	0	f	t	78	2026-04-25 12:17:07.932314+00	2026-04-25 16:51:54.456318+00	0z0mFm	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
44	7380841579	\N	Елена Зо	USER	RU	0	0	f	f	\N	2026-04-20 14:22:52.026118+00	2026-04-20 14:22:52.026118+00	Sxvdyg	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
45	7288750002	\N	Георгий Рыкованов	USER	RU	0	0	f	f	\N	2026-04-20 14:22:52.073271+00	2026-04-20 14:22:52.073271+00	UhYQSp	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
46	7455994994	\N	Кудрявцев Геннадий	USER	RU	0	0	f	f	\N	2026-04-20 14:22:52.100517+00	2026-04-20 14:22:52.100517+00	bgDSBy	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
47	7491024356	efaxorcr4	Инна	USER	RU	0	0	f	f	\N	2026-04-20 14:22:52.131949+00	2026-04-20 14:22:52.131949+00	qSc8lZ	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
48	7122366076	\N	Олег Филонов	USER	RU	0	0	f	f	\N	2026-04-20 14:22:52.161244+00	2026-04-20 14:22:52.161244+00	LdZ2Qz	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
49	6503498484	\N	Сергей Поздняков	USER	RU	0	0	f	f	\N	2026-04-20 14:22:52.205913+00	2026-04-20 14:22:52.205913+00	zygXbS	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
50	7417244324	\N	Андрей Клюев	USER	RU	0	0	f	f	\N	2026-04-20 14:22:52.206373+00	2026-04-20 14:22:52.206373+00	V9Eeut	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
51	5566835452	\N	Галина Божченко	USER	RU	0	0	f	f	\N	2026-04-20 14:22:52.208801+00	2026-04-20 14:22:52.208801+00	bcDkBQ	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
27	6487412221	nIkI_Ta57	АВОКАДИК	USER	RU	0	0	f	f	28	2026-04-19 16:26:04.543516+00	2026-04-19 16:26:09.285708+00	2Box6a	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
52	7321695838	\N	Елена Иванова	USER	RU	0	0	f	f	\N	2026-04-20 14:22:52.266248+00	2026-04-20 14:22:52.266248+00	bylInP	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
53	7137332170	\N	Бойченко Игорь	USER	RU	0	0	f	f	\N	2026-04-20 14:22:52.34679+00	2026-04-20 14:22:52.34679+00	Qlux5L	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
676	7488466797	Aqenly	Its nefor	USER	RU	0	0	f	f	92	2026-04-26 04:16:43.872665+00	2026-04-26 04:18:17.034152+00	J1se4Z	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
29	2016406877	Reyuzaki_L	Человек с лягушкой	USER	RU	0	0	f	f	34	2026-04-20 06:33:27.267539+00	2026-04-20 06:33:33.460136+00	sxTBax	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
30	5986546413	WestWinstonSavva	Winston	USER	RU	0	0	f	f	35	2026-04-20 08:22:23.152832+00	2026-04-20 08:22:30.429863+00	ImOw0Z	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
792	8543938635	Konserva900	AnyaWakuWaku	USER	RU	0	0	f	f	\N	2026-05-03 10:10:17.182688+00	2026-05-03 10:10:20.217398+00	DekTD2	0	t	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
25	5581255609	\N	Мария	USER	RU	0	0	f	f	36	2026-04-19 11:57:30.721099+00	2026-04-20 09:20:02.567777+00	rWscqS	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
687	5305665179	LREH_228	Владимир Владимирович	USER	RU	0	0	f	f	99	2026-04-26 11:41:09.307735+00	2026-04-26 11:41:16.664587+00	bhff7d	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
15	5334269724	\N	Ольга	USER	RU	0	0	f	f	218	2026-04-17 08:12:22.847506+00	2026-05-14 06:19:15.524432+00	k2J4Be	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
32	8228208140	swiftrace	Denis M	USER	RU	0	0	f	t	\N	2026-04-20 10:11:18.080596+00	2026-04-20 10:12:35.899654+00	F2ArGm	0	t	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
33	1177696065	cs5avfpx	Fishily	USER	RU	0	0	f	f	\N	2026-04-20 10:24:27.688655+00	2026-04-20 10:24:33.305171+00	bcy8V0	0	t	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
16	5594197564	MB_80_KL	Михаил	USER	RU	0	0	f	f	233	2026-04-17 09:18:17.214004+00	2026-05-19 19:03:03.82674+00	mhSunI	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
728	1115561743	\N	Poul	USER	RU	0	0	f	f	252	2026-04-29 00:27:19.774051+00	2026-05-30 13:55:33.162319+00	q2vbI3	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
31	8143932381	swip_mw	meaw	USER	RU	0	0	f	t	37	2026-04-20 09:50:36.514395+00	2026-06-27 08:56:21.498655+00	8eXzKV	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
28	6395040950	EWZEWZ13	Griffith	USER	RU	0	0	f	t	29	2026-04-19 17:05:59.150261+00	2026-06-07 22:48:13.02637+00	6V8VLH	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
20	880601228	Kashkin_Oleg	Олег Кашкин Эксперт на рынке не	USER	RU	0	0	f	f	270	2026-04-17 15:17:26.201547+00	2026-06-12 06:38:53.989779+00	yFVpXk	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
17	8380465191	\N	Anet	USER	RU	0	0	f	f	273	2026-04-17 10:44:38.518384+00	2026-06-17 05:58:59.247598+00	biERcs	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
10	233781889	zirochka_kohana	Ksenia	USER	RU	0	0	f	f	274	2026-04-16 20:54:29.395018+00	2026-06-17 06:14:39.85623+00	5VCbPU	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
821	1127193430	real_kudinova	miilxxw	USER	RU	0	0	f	t	201	2026-05-06 16:32:37.617963+00	2026-06-23 07:11:53.121542+00	gpIqAr	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
9	799081841	tkj1isj	софик	USER	RU	0	0	f	f	5	2026-04-16 20:44:21.123148+00	2026-06-23 09:53:51.839618+00	TFX9C6	5	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
14	8261668113	Sergey_MulenPay_support	Sergey Support	USER	RU	0	0	f	t	\N	2026-04-17 07:05:20.588953+00	2026-06-24 06:17:05.695938+00	TagMmB	0	t	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
718	8274401525	Blackbolinka	.	USER	RU	0	0	f	t	132	2026-04-28 12:54:28.236055+00	2026-06-24 10:50:26.810385+00	bgDs66	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
34	7038893979	sergee_chirkov	Сергей Чирков	USER	RU	0	0	f	f	\N	2026-04-20 14:22:51.583964+00	2026-04-20 14:22:51.583964+00	Ud9PSS	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
35	7391948218	akhacizhoshak10	Gadjimurad	USER	RU	0	0	f	f	\N	2026-04-20 14:22:51.621596+00	2026-04-20 14:22:51.621596+00	BW9pNK	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
36	7187512358	\N	Сергей Сережников	USER	RU	0	0	f	f	\N	2026-04-20 14:22:51.673599+00	2026-04-20 14:22:51.673599+00	vrrWvQ	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
37	7410555375	ekhthcizczhqt5	Chush	USER	RU	0	0	f	f	\N	2026-04-20 14:22:51.741622+00	2026-04-20 14:22:51.741622+00	bccA64	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
38	6487602590	\N	Чуйков Олег	USER	RU	0	0	f	f	\N	2026-04-20 14:22:51.789496+00	2026-04-20 14:22:51.789496+00	Ru2ka5	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
39	6554193113	\N	Ирина Тихомирова	USER	RU	0	0	f	f	\N	2026-04-20 14:22:51.798785+00	2026-04-20 14:22:51.798785+00	biBhuS	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
40	7190243719	\N	Валерий Кулдышев	USER	RU	0	0	f	f	\N	2026-04-20 14:22:51.82262+00	2026-04-20 14:22:51.82262+00	P3cT1i	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
41	7499529675	ynosekhzhshy9	Ira	USER	RU	0	0	f	f	\N	2026-04-20 14:22:51.913474+00	2026-04-20 14:22:51.913474+00	h6ofTS	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
54	7144442403	khchikhodoshmgcn5	Анна	USER	RU	0	0	f	f	\N	2026-04-20 14:22:52.376154+00	2026-04-20 14:22:52.376154+00	TFc5FA	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
55	6757922624	\N	Андрей Тоняев	USER	RU	0	0	f	f	\N	2026-04-20 14:22:52.457821+00	2026-04-20 14:22:52.457821+00	pbcrgs	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
56	7128362025	\N	Andrey Rogozev	USER	RU	0	0	f	f	\N	2026-04-20 14:22:52.486729+00	2026-04-20 14:22:52.486729+00	dOU9O7	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
57	7285725177	echfkhymemcw4	Samir	USER	RU	0	0	f	f	\N	2026-04-20 14:22:52.488612+00	2026-04-20 14:22:52.488612+00	cMM0b4	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
58	6854004170	ysuvkhwaje2	Gadjimurad	USER	RU	0	0	f	f	\N	2026-04-20 14:22:52.547528+00	2026-04-20 14:22:52.547528+00	bbk22r	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
59	7072859207	\N	Сергей Крутелев	USER	RU	0	0	f	f	\N	2026-04-20 14:22:52.586057+00	2026-04-20 14:22:52.586057+00	RPsOkU	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
60	7185451514	\N	Голубев Павел	USER	RU	0	0	f	f	\N	2026-04-20 14:22:52.586484+00	2026-04-20 14:22:52.586484+00	xTWnMa	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
61	7223675208	uthbcgfycts3	Kuznetsov Nicolai	USER	RU	0	0	f	f	\N	2026-04-20 14:22:52.613641+00	2026-04-20 14:22:52.613641+00	q6noQg	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
62	7338428345	\N	Леонид Гиндин	USER	RU	0	0	f	f	\N	2026-04-20 14:22:52.667833+00	2026-04-20 14:22:52.667833+00	cPM9Rg	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
63	7295987638	\N	Роман Кузилов	USER	RU	0	0	f	f	\N	2026-04-20 14:22:52.692861+00	2026-04-20 14:22:52.692861+00	sm3NPy	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
64	7276629524	\N	Chush	USER	RU	0	0	f	f	\N	2026-04-20 14:22:52.753955+00	2026-04-20 14:22:52.753955+00	YL35wn	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
65	7492372845	\N	Виктор Луцкович	USER	RU	0	0	f	f	\N	2026-04-20 14:22:52.755886+00	2026-04-20 14:22:52.755886+00	I9nn86	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
66	7307890386	yfvhqfizhtzhu7	Рем	USER	RU	0	0	f	f	\N	2026-04-20 14:22:52.854966+00	2026-04-20 14:22:52.854966+00	bclmSC	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
67	7231927002	\N	Ростислав Асов	USER	RU	0	0	f	f	\N	2026-04-20 14:22:52.855499+00	2026-04-20 14:22:52.855499+00	m4kx2Z	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
824	5294646916	hogtz	Мипо	USER	RU	0	0	f	t	204	2026-05-07 10:11:30.147406+00	2026-05-07 10:23:17.295232+00	Sqh5mf	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
4	1452534244	Tyrboyrka	Евгений Гридасов	USER	RU	0	0	f	f	225	2026-04-16 20:13:24.116231+00	2026-05-17 09:10:08.431725+00	bp46bZ	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
68	7351740982	\N	Евгений Топехин	USER	RU	0	0	f	f	\N	2026-04-20 14:22:52.962893+00	2026-04-20 14:22:52.962893+00	IZxQH2	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
71	7061189280	\N	Геннадий Александрович	USER	RU	0	0	f	f	\N	2026-04-20 14:22:53.143117+00	2026-04-20 14:22:53.143117+00	ITM9Yy	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
74	7319867279	kirkir32435	Kirill	USER	RU	0	0	f	f	\N	2026-04-20 14:22:53.351109+00	2026-04-20 14:22:53.474733+00	ZW4UUc	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
81	6411120039	\N	Павел Шишков	USER	RU	0	0	f	f	\N	2026-04-20 14:22:53.891692+00	2026-04-20 14:22:53.891692+00	l0CaXJ	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
92	7384490069	khshshmvkmnot3	Мебель	USER	RU	0	0	f	f	\N	2026-04-20 14:22:54.438949+00	2026-04-20 14:22:54.438949+00	bn5yhn	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
107	7398212280	\N	Христо	USER	RU	0	0	f	f	\N	2026-04-20 14:22:55.158793+00	2026-04-20 14:22:55.158793+00	bn3aiw	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
128	7433869293	\N	Акимов Ю.Е.	USER	RU	0	0	f	f	\N	2026-04-20 14:22:56.018111+00	2026-04-20 14:22:56.018111+00	bqsXuI	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
154	7486177728	erfjuthyhshgr5	2100031408_	USER	RU	0	0	f	f	\N	2026-04-20 14:22:56.669196+00	2026-04-20 14:22:56.669196+00	3LDFBV	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
191	7332486092	\N	Блинова Ирина Вячеславовна	USER	RU	0	0	f	f	\N	2026-04-20 14:22:57.977992+00	2026-04-20 14:22:57.977992+00	bae6v0	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
241	7413630065	oxqqshrgq9	Семен Лисовой	USER	RU	0	0	f	f	\N	2026-04-20 14:23:00.230025+00	2026-04-20 14:23:00.230025+00	bnKLn1	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
300	7354866904	ixufytuzqczhg6	Samir	USER	RU	0	0	f	f	\N	2026-04-20 14:23:02.683508+00	2026-04-20 14:23:02.683508+00	beyAhI	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
359	7417621134	zqthdunjburzz9	Samir	USER	RU	0	0	f	f	\N	2026-04-20 14:23:04.042327+00	2026-04-20 14:23:04.042327+00	GWZSw4	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
418	7394365009	\N	Юрий Скачко	USER	RU	0	0	f	f	\N	2026-04-20 14:23:05.310199+00	2026-04-20 14:23:05.310199+00	je4szx	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
477	7480599636	\N	Anatoli	USER	RU	0	0	f	f	\N	2026-04-20 14:23:07.092346+00	2026-04-20 14:23:07.092346+00	E2MJn8	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
664	2067224852	Nastasia_98_21	Настасья	USER	RU	0	0	f	f	83	2026-04-25 20:09:17.211367+00	2026-04-25 20:09:24.092943+00	Mnjz6a	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
719	1705091148	\N	Анастасия	USER	RU	0	0	f	f	133	2026-04-28 14:02:02.763657+00	2026-04-28 14:02:28.779286+00	G0aPlu	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
688	5078253898	Nurich10	DA	USER	RU	0	0	f	t	100	2026-04-26 11:43:43.51093+00	2026-04-26 11:45:07.618578+00	bdfbLm	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
695	6159205362	Dina4200	Динуля Колокуцкая	USER	RU	0	0	f	f	107	2026-04-26 22:29:01.971768+00	2026-04-26 22:29:30.407497+00	LBMPs9	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
619	5014160544	romasnca159	Romasnca Molotov	USER	RU	0	0	f	f	63	2026-04-25 03:37:02.241705+00	2026-04-27 08:55:10.531128+00	C15jZA	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
729	1590513029	INickSkyline	Nick Skyline	USER	RU	0	0	f	f	\N	2026-04-29 05:58:47.335391+00	2026-04-29 05:58:49.187248+00	TaR5xn	0	t	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
825	1667788892	\N	Tonny Kobe	USER	RU	0	0	f	t	\N	2026-05-08 03:04:29.503399+00	2026-05-08 03:04:34.497458+00	geLglk	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
703	7738883042	S_every_soul_will_taste_death_S	S	USER	RU	0	0	f	f	\N	2026-04-27 13:31:23.159278+00	2026-04-27 13:31:24.897123+00	M2v2GA	0	t	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
704	6793204759	ASTAKHOV1502	Виктор Астахов 79518663868	USER	RU	0	0	f	f	123	2026-04-27 13:40:48.201227+00	2026-04-27 13:41:15.037141+00	rkmipI	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
705	7685702678	\N	7685702678	USER	RU	0	0	f	f	124	2026-04-27 13:54:30.053853+00	2026-04-27 13:54:33.622234+00	RBBojl	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
706	7626879649	\N	Сс	USER	RU	0	0	f	f	\N	2026-04-27 15:48:41.3781+00	2026-04-27 15:48:41.3781+00	bl96OI	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
707	5992905982	UIIWESFW	NN	USER	RU	0	0	f	f	125	2026-04-27 16:09:17.442375+00	2026-04-27 16:09:24.83612+00	RtxHOT	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
69	7340129004	\N	Николай Шевцов	USER	RU	0	0	f	f	\N	2026-04-20 14:22:52.965309+00	2026-04-20 14:22:52.965309+00	nWwikN	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
72	6996445188	\N	Владимир Куницкий	USER	RU	0	0	f	f	\N	2026-04-20 14:22:53.143452+00	2026-04-20 14:22:53.143452+00	ujoEa7	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
75	7430129719	ukhzgkthfkochrd4	gavrila	USER	RU	0	0	f	f	\N	2026-04-20 14:22:53.380891+00	2026-04-20 14:22:53.380891+00	6cYDzj	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
79	7354194922	\N	Владимир Буров	USER	RU	0	0	f	f	\N	2026-04-20 14:22:53.739364+00	2026-04-20 14:22:53.739364+00	bgD7xt	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
84	7133030596	\N	Сергей Сорокин	USER	RU	0	0	f	f	\N	2026-04-20 14:22:54.149819+00	2026-04-20 14:22:54.149819+00	tMharX	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
95	6958467224	\N	Андрей Новиков	USER	RU	0	0	f	f	\N	2026-04-20 14:22:54.467242+00	2026-04-20 14:22:54.467242+00	9bx8ZO	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
111	7228818009	\N	Татьяна Грибова	USER	RU	0	0	f	f	\N	2026-04-20 14:22:55.194046+00	2026-04-20 14:22:55.194046+00	VKZBRR	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
132	7477498200	bkhnnjhthqczho9	Спичка Андрей Владимирович	USER	RU	0	0	f	f	\N	2026-04-20 14:22:56.372379+00	2026-04-20 14:22:56.372379+00	G2UdBU	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
159	7119233548	azhkpohibukhchp4	Дмитрий Минченко	USER	RU	0	0	f	f	\N	2026-04-20 14:22:56.948191+00	2026-04-20 14:22:56.948191+00	JieiZs	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
196	6904058698	\N	Дмитрий Абрамов-Иревли	USER	RU	0	0	f	f	\N	2026-04-20 14:22:58.049111+00	2026-04-20 14:22:58.049111+00	xEDuN8	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
247	7297960774	\N	Зимирева О.К.	USER	RU	0	0	f	f	\N	2026-04-20 14:23:00.665562+00	2026-04-20 14:23:00.665562+00	be0rxJ	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
306	6617954808	\N	Daniil S	USER	RU	0	0	f	f	\N	2026-04-20 14:23:02.782471+00	2026-04-20 14:23:02.782471+00	86EbjU	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
366	7287319665	wcotwzgshopkk1	Sompong	USER	RU	0	0	f	f	\N	2026-04-20 14:23:04.158108+00	2026-04-20 14:23:04.158108+00	boNhT2	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
425	7267885936	\N	Максим Тятюшев	USER	RU	0	0	f	f	\N	2026-04-20 14:23:05.524447+00	2026-04-20 14:23:05.524447+00	1CVvnG	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
484	6843364768	\N	Офтин Александр Васильевич	USER	RU	0	0	f	f	\N	2026-04-20 14:23:07.410014+00	2026-04-20 14:23:07.410014+00	bj0WSV	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
795	6394269022	ktai_05	.	USER	RU	0	0	f	t	187	2026-05-03 12:33:06.39003+00	2026-05-07 05:51:15.420903+00	HNWGMT	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
665	8750176301	anya_216	anya	USER	RU	0	0	f	f	84	2026-04-25 20:43:23.958189+00	2026-04-25 20:43:28.814863+00	bcTX3q	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
720	865516063	stasya_kochkina	Девушка с характером	USER	RU	0	0	f	f	134	2026-04-28 14:41:22.688774+00	2026-04-28 14:41:32.551333+00	tspTzo	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
713	8797039508	The6Dark6Knight	Knight of the World	USER	RU	0	0	f	t	\N	2026-04-28 02:45:00.577128+00	2026-04-28 22:54:44.930806+00	UiK9Ka	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
730	852409517	kakashkaspikelove	эмилия	USER	RU	0	0	f	f	\N	2026-04-29 06:59:59.826545+00	2026-04-29 07:00:02.709347+00	StXmRr	0	t	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
678	8095930033	\N	гостов tsc	USER	RU	0	0	f	t	\N	2026-04-26 06:03:03.155815+00	2026-04-26 06:03:30.074825+00	A0ZwjS	0	t	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
689	7613640229	\N	ᅠ ᅠ	USER	RU	0	0	f	f	101	2026-04-26 11:52:03.800725+00	2026-04-26 11:52:11.371254+00	2uPr63	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
666	835939136	matsasha	Alexandr	USER	RU	0	0	f	t	85	2026-04-25 21:02:00.518751+00	2026-04-26 21:53:38.89444+00	diMljG	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
794	5170224742	danna_tobio	dina	USER	RU	0	0	f	f	186	2026-05-03 12:10:15.492051+00	2026-05-03 12:10:19.68233+00	R6l3TQ	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
696	5480077164	igor_mtzudm	Igor	USER	RU	0	0	f	f	108	2026-04-26 23:21:21.380358+00	2026-04-26 23:22:23.793824+00	bBEldG	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
826	6950538855	\N	abcdefg ᅠ	USER	RU	0	0	f	f	205	2026-05-08 09:58:29.536826+00	2026-05-08 09:58:33.480108+00	LeuHo4	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
709	7908141897	kwexqzzz	kristixzzz	USER	RU	0	0	f	t	127	2026-04-27 17:15:44.458509+00	2026-05-11 03:13:35.989646+00	boZ9lG	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
708	1723253062	Aladin098	Атас	USER	RU	0	0	f	t	126	2026-04-27 16:31:13.61147+00	2026-04-27 16:32:00.789546+00	RA9CAU	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
711	7560014900	\N	Ставь Zemlyanichko228	USER	RU	0	0	f	f	128	2026-04-27 20:42:04.878542+00	2026-04-27 20:42:08.604654+00	Wsoc41	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
712	5977321994	Carlozito	Carlos	USER	RU	0	0	f	t	\N	2026-04-27 20:44:34.139788+00	2026-04-27 20:46:43.503696+00	OfflSH	0	t	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
714	5145828499	Nataha1979q	Наталья	USER	RU	0	0	f	t	\N	2026-04-28 04:29:17.286862+00	2026-04-28 04:30:30.764534+00	0Vi5Z7	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
70	6748820752	\N	Александр Гоголев	USER	RU	0	0	f	f	\N	2026-04-20 14:22:52.964952+00	2026-04-20 14:22:52.964952+00	7dRxCE	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
73	7480940229	nzutzhluw4	Анна	USER	RU	0	0	f	f	\N	2026-04-20 14:22:53.185649+00	2026-04-20 14:22:53.185649+00	0277YL	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
76	7077460072	\N	Виктор Егорычев	USER	RU	0	0	f	f	\N	2026-04-20 14:22:53.383322+00	2026-04-20 14:22:53.383322+00	e87ZUG	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
77	6883471731	\N	Константин Данилочкин	USER	RU	0	0	f	f	\N	2026-04-20 14:22:53.35431+00	2026-04-20 14:22:53.35431+00	bf1rii	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
78	6788251292	\N	Сергей Осипов	USER	RU	0	0	f	f	\N	2026-04-20 14:22:53.361673+00	2026-04-20 14:22:53.361673+00	WGykZq	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
80	7399645099	\N	Андрей Геннадьевич Мишуков	USER	RU	0	0	f	f	\N	2026-04-20 14:22:53.758643+00	2026-04-20 14:22:53.758643+00	Cz0EtS	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
82	7081936228	\N	Сергей Хрупов	USER	RU	0	0	f	f	\N	2026-04-20 14:22:53.738016+00	2026-04-20 14:22:53.738016+00	YwQ1S1	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
83	7479343577	kstldwofqk5	Анна	USER	RU	0	0	f	f	\N	2026-04-20 14:22:54.150027+00	2026-04-20 14:22:54.150027+00	6uKjSf	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
85	7336115488	\N	Slava Boi	USER	RU	0	0	f	f	\N	2026-04-20 14:22:54.156441+00	2026-04-20 14:22:54.156441+00	beyIlk	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
86	7078573519	\N	Павел Козырев	USER	RU	0	0	f	f	\N	2026-04-20 14:22:54.156849+00	2026-04-20 14:22:54.156849+00	xpiiSc	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
87	7270320670	\N	Сюзев Андрей Михайлович	USER	RU	0	0	f	f	\N	2026-04-20 14:22:53.835001+00	2026-04-20 14:22:53.835001+00	ZNWsXu	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
88	7302644015	\N	Шумаков Игорь	USER	RU	0	0	f	f	\N	2026-04-20 14:22:53.851602+00	2026-04-20 14:22:53.851602+00	bhz6NN	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
89	6490138552	\N	Vladimir Belov	USER	RU	0	0	f	f	\N	2026-04-20 14:22:53.844005+00	2026-04-20 14:22:53.844005+00	81ZAsG	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
90	7224443453	yponhkuqxhmch1	Ira	USER	RU	0	0	f	f	\N	2026-04-20 14:22:53.910828+00	2026-04-20 14:22:53.910828+00	5CyJZ6	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
91	6737205642	\N	Орловский Евгений	USER	RU	0	0	f	f	\N	2026-04-20 14:22:53.895894+00	2026-04-20 14:22:53.895894+00	A1NsMl	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
93	7292243830	\N	Геннадий Бессонов	USER	RU	0	0	f	f	\N	2026-04-20 14:22:54.464001+00	2026-04-20 14:22:54.464001+00	S1K1Wz	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
94	6938294583	\N	Александр Леонов	USER	RU	0	0	f	f	\N	2026-04-20 14:22:54.464258+00	2026-04-20 14:22:54.464258+00	bf4Tde	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
96	7221896728	\N	Пароев Олег	USER	RU	0	0	f	f	\N	2026-04-20 14:22:54.554383+00	2026-04-20 14:22:54.554383+00	HLDAMs	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
97	7113311819	Ullena2004	Юлия Губарева	USER	RU	0	0	f	f	\N	2026-04-20 14:22:54.369878+00	2026-04-20 14:22:54.369878+00	bdLV1Y	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
98	6712822171	\N	Александр Николаев	USER	RU	0	0	f	f	\N	2026-04-20 14:22:54.646058+00	2026-04-20 14:22:54.646058+00	RdBBb4	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
99	7117931610	\N	Владимир Косенков	USER	RU	0	0	f	f	\N	2026-04-20 14:22:54.270567+00	2026-04-20 14:22:54.270567+00	BlaK8N	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
100	6912688847	uthwxokhykh10	Slava Boi	USER	RU	0	0	f	f	\N	2026-04-20 14:22:54.334667+00	2026-04-20 14:22:54.334667+00	bEcOt6	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
101	7217808692	\N	Alexander Chigirinskiy	USER	RU	0	0	f	f	\N	2026-04-20 14:22:54.679824+00	2026-04-20 14:22:54.679824+00	A6slng	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
102	7411731871	\N	Юлия Малинникова	USER	RU	0	0	f	f	\N	2026-04-20 14:22:54.709803+00	2026-04-20 14:22:54.709803+00	4Kgix1	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
103	7032147482	vncrochrh1	SonG	USER	RU	0	0	f	f	\N	2026-04-20 14:22:54.709175+00	2026-04-20 14:22:54.709175+00	bi2IEc	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
104	7256161644	akkhgibvny6	Chush	USER	RU	0	0	f	f	\N	2026-04-20 14:22:54.467503+00	2026-04-20 14:22:54.467503+00	HSTqsc	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
105	7356073196	\N	Елена Алексеенко	USER	RU	0	0	f	f	\N	2026-04-20 14:22:54.478867+00	2026-04-20 14:22:54.478867+00	H05v5P	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
106	7279002114	\N	K Petr	USER	RU	0	0	f	f	\N	2026-04-20 14:22:54.97242+00	2026-04-20 14:22:54.97242+00	lN8hVq	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
108	6819629081	\N	.	USER	RU	0	0	f	f	\N	2026-04-20 14:22:55.158985+00	2026-04-20 14:22:55.158985+00	k2KIeu	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
109	7414434083	\N	Владимир Худяев	USER	RU	0	0	f	f	\N	2026-04-20 14:22:55.173616+00	2026-04-20 14:22:55.173616+00	bn9IYR	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
110	7448056782	\N	Ольга Ивановна	USER	RU	0	0	f	f	\N	2026-04-20 14:22:55.181372+00	2026-04-20 14:22:55.181372+00	PAWmvb	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
112	6819104727	\N	Савкина В.А	USER	RU	0	0	f	f	\N	2026-04-20 14:22:55.198072+00	2026-04-20 14:22:55.198072+00	bpZfVa	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
113	7146428273	ychodzhnezlkhthzh7	Samir	USER	RU	0	0	f	f	\N	2026-04-20 14:22:55.220461+00	2026-04-20 14:22:55.220461+00	blD6RC	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
114	6513101232	\N	Sergey Balyakin	USER	RU	0	0	f	f	\N	2026-04-20 14:22:55.220844+00	2026-04-20 14:22:55.220844+00	bf9uZz	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
115	6831988322	\N	Николаенко Виктория	USER	RU	0	0	f	f	\N	2026-04-20 14:22:55.239955+00	2026-04-20 14:22:55.239955+00	yPrFGj	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
116	7385458403	\N	Анфиса Егорова	USER	RU	0	0	f	f	\N	2026-04-20 14:22:54.741349+00	2026-04-20 14:22:54.741349+00	OYp2fs	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
710	5381951943	\N	Я	USER	RU	0	0	f	t	\N	2026-04-27 18:27:10.670588+00	2026-06-24 11:22:34.547447+00	C8FfNH	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
117	7483947461	\N	Андрей Долбиков	USER	RU	0	0	f	f	\N	2026-04-20 14:22:55.344128+00	2026-04-20 14:22:55.344128+00	bmKlp3	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
118	7281842976	smfvukhmvt7	Ilya	USER	RU	0	0	f	f	\N	2026-04-20 14:22:55.344008+00	2026-04-20 14:22:55.344008+00	fAGXj4	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
119	7364825145	lvitvvlkhebxsh9	SonG	USER	RU	0	0	f	f	\N	2026-04-20 14:22:55.368656+00	2026-04-20 14:22:55.368656+00	CqE8B1	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
120	7250351029	ichyzhunazhp4	Айдар Расимович	USER	RU	0	0	f	f	\N	2026-04-20 14:22:55.391483+00	2026-04-20 14:22:55.391483+00	xvy1Xf	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
121	7259733413	\N	Павел Дронов	USER	RU	0	0	f	f	\N	2026-04-20 14:22:55.204221+00	2026-04-20 14:22:55.204221+00	bcRhXm	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
122	7357787447	\N	Валерий Переверин	USER	RU	0	0	f	f	\N	2026-04-20 14:22:55.195097+00	2026-04-20 14:22:55.195097+00	FLWE7c	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
123	7467253710	\N	Игорь	USER	RU	0	0	f	f	\N	2026-04-20 14:22:55.194764+00	2026-04-20 14:22:55.194764+00	zrC9z4	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
124	7390027772	\N	Павел Гальянов	USER	RU	0	0	f	f	\N	2026-04-20 14:22:55.460254+00	2026-04-20 14:22:55.460254+00	qI7rUt	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
125	7280023532	uwhmbnyzhyx1	Роман Кавинов	USER	RU	0	0	f	f	\N	2026-04-20 14:22:55.463197+00	2026-04-20 14:22:55.463197+00	NDD5dQ	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
126	7408005329	\N	1	USER	RU	0	0	f	f	\N	2026-04-20 14:22:55.533232+00	2026-04-20 14:22:55.533232+00	kZDRU0	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
127	7203645209	\N	Павел Савинов	USER	RU	0	0	f	f	\N	2026-04-20 14:22:55.220105+00	2026-04-20 14:22:55.220105+00	SdMfox	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
129	7497076469	owjmxgycchhy4	Инна	USER	RU	0	0	f	f	\N	2026-04-20 14:22:56.033975+00	2026-04-20 14:22:56.033975+00	4oyLlV	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
130	7402642250	\N	Andrei Khmelev	USER	RU	0	0	f	f	\N	2026-04-20 14:22:56.06356+00	2026-04-20 14:22:56.06356+00	rn11PO	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
131	7398189598	\N	Евгений Сусликов	USER	RU	0	0	f	f	\N	2026-04-20 14:22:56.074318+00	2026-04-20 14:22:56.074318+00	oVr920	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
133	7210201658	skhhfpshacent1	Gadjimurad	USER	RU	0	0	f	f	\N	2026-04-20 14:22:56.375538+00	2026-04-20 14:22:56.375538+00	bqWOw6	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
134	7129912346	\N	Светлана Байрашева	USER	RU	0	0	f	f	\N	2026-04-20 14:22:56.401278+00	2026-04-20 14:22:56.401278+00	D0PmVl	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
135	6695311415	\N	Максим Захаревич	USER	RU	0	0	f	f	\N	2026-04-20 14:22:56.087596+00	2026-04-20 14:22:56.087596+00	Q5FSEy	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
136	7293375733	hqtchevrth2	Анна	USER	RU	0	0	f	f	\N	2026-04-20 14:22:56.437153+00	2026-04-20 14:22:56.437153+00	yrcR7W	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
137	6856781049	\N	Шевченко Виталий Александрович	USER	RU	0	0	f	f	\N	2026-04-20 14:22:56.446273+00	2026-04-20 14:22:56.446273+00	bcK81k	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
138	7263883783	\N	Фомичев А.Н.	USER	RU	0	0	f	f	\N	2026-04-20 14:22:56.485244+00	2026-04-20 14:22:56.485244+00	m4uAIh	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
139	7345328988	\N	Леньков Максим	USER	RU	0	0	f	f	\N	2026-04-20 14:22:56.107284+00	2026-04-20 14:22:56.107284+00	bjtNUZ	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
140	7335435107	\N	Образцов С.В	USER	RU	0	0	f	f	\N	2026-04-20 14:22:56.487329+00	2026-04-20 14:22:56.487329+00	3k3RzJ	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
141	7227615305	ychorasjbchwy3	Ишков Олег	USER	RU	0	0	f	f	\N	2026-04-20 14:22:56.14472+00	2026-04-20 14:22:56.14472+00	bjfG77	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
142	6902336319	ijrkthsnpaqif1	Zakir	USER	RU	0	0	f	f	\N	2026-04-20 14:22:56.502588+00	2026-04-20 14:22:56.502588+00	q5SbR0	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
146	6536188029	\N	Юрий	USER	RU	0	0	f	f	\N	2026-04-20 14:22:56.530178+00	2026-04-20 14:22:56.530178+00	3ykNRg	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
143	7472076728	ahecqrogaf2	Мебель	USER	RU	0	0	f	f	\N	2026-04-20 14:22:56.254317+00	2026-04-20 14:22:56.254317+00	bbQ346	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
172	6955637268	\N	цву цйувмца	USER	RU	0	0	f	f	\N	2026-04-20 14:22:57.759199+00	2026-04-20 14:22:57.759199+00	Cql3q1	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
214	7241693219	yzhinarufyqsd9	Chush	USER	RU	0	0	f	f	\N	2026-04-20 14:22:59.670179+00	2026-04-20 14:22:59.670179+00	43hqZ3	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
265	7017217935	\N	Ольга Езикеева	USER	RU	0	0	f	f	\N	2026-04-20 14:23:01.041764+00	2026-04-20 14:23:01.041764+00	iyDTWQ	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
324	7366497366	\N	Олег Осипович	USER	RU	0	0	f	f	\N	2026-04-20 14:23:03.058487+00	2026-04-20 14:23:03.058487+00	vHr2oH	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
383	7002587286	\N	Сергей Витушенко	USER	RU	0	0	f	f	\N	2026-04-20 14:23:04.463577+00	2026-04-20 14:23:04.463577+00	BuB14h	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
442	7272638101	mgynbqkhnash1	Zakir	USER	RU	0	0	f	f	\N	2026-04-20 14:23:06.16838+00	2026-04-20 14:23:06.16838+00	oJoXB4	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
501	7335384411	\N	Наталья Михайлова	USER	RU	0	0	f	f	\N	2026-04-20 14:23:08.086744+00	2026-04-20 14:23:08.086744+00	fwnEDU	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
722	931779414	\N	Екатерина Митрофановна	USER	RU	0	0	f	f	\N	2026-04-28 15:31:54.296687+00	2026-05-07 11:18:49.246936+00	k2XaFn	0	t	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
667	6352250392	\N	Павел	USER	RU	0	0	f	t	86	2026-04-25 21:24:03.444487+00	2026-04-25 21:25:14.379338+00	bkLxgM	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
690	175189326	FlamingBird	Евгений Дробович	USER	RU	0	0	f	f	102	2026-04-26 12:19:47.162369+00	2026-04-26 12:20:40.190737+00	fHrMrW	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
731	5343646622	keepitcool777	chort	USER	RU	0	0	f	f	139	2026-04-29 07:52:20.901226+00	2026-04-29 07:52:29.909046+00	4oeewa	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
697	1551954657	andrey_89art	Андрей Олейник	USER	RU	0	0	f	f	109	2026-04-27 03:23:59.444038+00	2026-04-27 03:24:26.422952+00	IRmTLF	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
679	957916956	OMSalnikova	Оксана Михайловна Сальникова	USER	RU	0	0	f	t	\N	2026-04-26 07:28:08.106444+00	2026-04-27 03:49:54.91233+00	2iWFQR	0	t	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
715	6589742064	\N	454	USER	RU	0	0	f	t	129	2026-04-28 06:11:26.435313+00	2026-04-30 11:38:50.833137+00	qKI3KQ	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
721	6657993130	Slv3568	...	USER	RU	0	0	f	f	179	2026-04-28 15:12:15.076962+00	2026-05-02 14:53:32.909805+00	bd9l3n	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
827	7433052371	fuksleer	K	USER	RU	0	0	f	t	207	2026-05-09 09:38:10.334074+00	2026-05-12 14:54:46.657676+00	ejecTa	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
716	8793182428	\N	димас	USER	RU	0	0	f	f	130	2026-04-28 08:28:05.939029+00	2026-04-28 08:28:18.706613+00	Kkga3Q	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
144	7396980070	\N	Альбина Хамидулина	USER	RU	0	0	f	f	\N	2026-04-20 14:22:56.503041+00	2026-04-20 14:22:56.503041+00	gAybEv	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
145	7120695040	yrolxguv8	Юлия Белова	USER	RU	0	0	f	f	\N	2026-04-20 14:22:56.288537+00	2026-04-20 14:22:56.288537+00	ztgPIo	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
170	5733577611	\N	Кожевников С.М.	USER	RU	0	0	f	f	\N	2026-04-20 14:22:57.750817+00	2026-04-20 14:22:57.750817+00	46W71i	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
178	7440722694	\N	Светлана Гончарова	USER	RU	0	0	f	f	\N	2026-04-20 14:22:57.797953+00	2026-04-20 14:22:57.797953+00	TuYkax	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
209	7005339027	jkqbzlhsh3	Дмитрий	USER	RU	0	0	f	f	\N	2026-04-20 14:22:59.460718+00	2026-04-20 14:22:59.460718+00	jTnYWQ	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
224	7341332557	\N	Белан Сергей	USER	RU	0	0	f	f	\N	2026-04-20 14:22:59.90347+00	2026-04-20 14:22:59.90347+00	qmbQ0j	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
259	7275715624	\N	Александр Белов	USER	RU	0	0	f	f	\N	2026-04-20 14:23:00.88684+00	2026-04-20 14:23:00.88684+00	bj1y92	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
275	7262621586	\N	Konstantin Pokachalov	USER	RU	0	0	f	f	\N	2026-04-20 14:23:02.035782+00	2026-04-20 14:23:02.035782+00	9ve2fx	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
318	7337281368	sgxwsbunkhmchkh9	Bor	USER	RU	0	0	f	f	\N	2026-04-20 14:23:02.953368+00	2026-04-20 14:23:02.953368+00	IQJWvV	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
334	7265568579	\N	Зарипов Айрат	USER	RU	0	0	f	f	\N	2026-04-20 14:23:03.419335+00	2026-04-20 14:23:03.419335+00	wtsZ41	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
377	7216789683	\N	Сергей Романцов	USER	RU	0	0	f	f	\N	2026-04-20 14:23:04.40882+00	2026-04-20 14:23:04.40882+00	S60gEA	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
393	6903175433	\N	Поддубицкий Николай	USER	RU	0	0	f	f	\N	2026-04-20 14:23:04.752817+00	2026-04-20 14:23:04.752817+00	wlbO4P	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
435	7463228093	akheraragatvf10	Дамир	USER	RU	0	0	f	f	\N	2026-04-20 14:23:06.022265+00	2026-04-20 14:23:06.022265+00	6WKSf7	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
452	7305513383	dbnntdshbld1	Миха	USER	RU	0	0	f	f	\N	2026-04-20 14:23:06.372962+00	2026-04-20 14:23:06.372962+00	Iedahl	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
494	7084403761	\N	Голуся Огрызкова	USER	RU	0	0	f	f	\N	2026-04-20 14:23:07.732229+00	2026-04-20 14:23:07.732229+00	ubFheg	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
511	6842873070	Alexsey_Borisivitch	Алексей	USER	RU	0	0	f	f	\N	2026-04-20 14:23:08.245323+00	2026-04-20 14:23:08.245323+00	Zekf8X	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
796	8760102889	\N	Ib	USER	RU	0	0	f	t	\N	2026-05-03 14:07:18.058044+00	2026-06-23 23:08:45.439922+00	bgqEmk	0	t	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
668	1806802248	LUkukla16	Лина Александровна	USER	RU	0	0	f	f	87	2026-04-25 23:00:46.332411+00	2026-04-25 23:01:01.23811+00	uZfdZ2	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
680	7183273066	astdvt	Александр	USER	RU	0	0	f	f	93	2026-04-26 07:55:49.193659+00	2026-04-26 07:55:58.880735+00	babKIn	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
691	5488160175	kyn1_lover69	Люблю Аню	USER	RU	0	0	f	t	\N	2026-04-26 13:13:56.155862+00	2026-04-26 13:14:04.33354+00	w8Gt5H	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
732	404604015	Goldwara	Алексндр	USER	RU	0	0	f	f	\N	2026-04-29 09:34:04.38112+00	2026-04-29 09:34:04.429228+00	AmMKOh	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
723	5197002608	avtobond	447873088257	USER	RU	0	0	f	t	135	2026-04-28 15:33:30.179541+00	2026-05-01 15:36:14.839049+00	F2zQfN	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
693	8471315018	henry9103	8471315018	USER	RU	0	0	f	f	104	2026-04-26 13:14:05.762088+00	2026-04-26 13:14:13.24482+00	Iixb9z	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
797	8565949539	\N	joyle	USER	RU	0	0	f	f	188	2026-05-03 15:22:25.599662+00	2026-05-03 15:22:29.770189+00	bqMQ7v	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
798	6769353525	sonyaLLoxx	.	USER	RU	0	0	f	f	\N	2026-05-03 15:23:12.455727+00	2026-05-03 15:23:15.331474+00	PjtDh9	0	t	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
828	6346924303	bodry_777	S S	USER	RU	0	0	f	f	208	2026-05-09 11:42:15.57144+00	2026-05-09 11:42:20.206201+00	8Trcuz	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
147	7490793146	rxpkepuj4	Миха	USER	RU	0	0	f	f	\N	2026-04-20 14:22:56.580801+00	2026-04-20 14:22:56.580801+00	vDdCzC	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
179	7472855075	\N	Ратников Александр	USER	RU	0	0	f	f	\N	2026-04-20 14:22:57.837108+00	2026-04-20 14:22:57.837108+00	i04RGD	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
225	7186586540	zdukhixqchuzhcsh10	Ira	USER	RU	0	0	f	f	\N	2026-04-20 14:22:59.908054+00	2026-04-20 14:22:59.908054+00	3TWzJC	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
276	7372217440	\N	Дмитрий Башков	USER	RU	0	0	f	f	\N	2026-04-20 14:23:02.055904+00	2026-04-20 14:23:02.055904+00	Ra5E4v	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
335	6808370611	\N	Шагимарданов Ринат	USER	RU	0	0	f	f	\N	2026-04-20 14:23:03.437256+00	2026-04-20 14:23:03.437256+00	ftatLy	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
394	7479224907	ofuhwzhopngo9	Миха	USER	RU	0	0	f	f	\N	2026-04-20 14:23:04.761867+00	2026-04-20 14:23:04.761867+00	bOiXBg	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
453	7451393448	\N	Вадим Воробьев	USER	RU	0	0	f	f	\N	2026-04-20 14:23:06.373231+00	2026-04-20 14:23:06.373231+00	W9Gz5r	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
512	7336596100	acechadthjuh2	Миха	USER	RU	0	0	f	f	\N	2026-04-20 14:23:08.294657+00	2026-04-20 14:23:08.294657+00	h0eM7H	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
724	1083060921	\N	Оксана Васильева	USER	RU	0	0	f	f	\N	2026-04-28 17:00:41.718596+00	2026-04-28 17:00:41.718596+00	JXbieO	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
692	806465974	\N	Наташа	USER	RU	0	0	f	f	103	2026-04-26 13:14:04.062792+00	2026-04-26 13:14:11.753202+00	k5UEvb	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
733	912237048	perchui_m	Перчуи	USER	RU	0	0	f	f	141	2026-04-29 15:11:22.366948+00	2026-04-29 15:13:08.50027+00	hrLmUf	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
799	8312512885	ee1090	Юрий	USER	RU	0	0	f	t	189	2026-05-03 21:27:58.164375+00	2026-05-04 08:54:18.424289+00	EUfiDo	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
829	1040358746	\N	Руслан Горяйнов	USER	RU	0	0	f	f	212	2026-05-10 05:29:37.50878+00	2026-05-10 05:47:20.368658+00	IUy6fy	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
148	7405150363	yvlchagehtho1	Samir	USER	RU	0	0	f	f	\N	2026-04-20 14:22:56.583228+00	2026-04-20 14:22:56.583228+00	62phJJ	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
181	7009754328	\N	Татьяна Марчук	USER	RU	0	0	f	f	\N	2026-04-20 14:22:57.874415+00	2026-04-20 14:22:57.874415+00	bl8V2F	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
227	7322936602	\N	Сергей Радьков	USER	RU	0	0	f	f	\N	2026-04-20 14:22:59.952236+00	2026-04-20 14:22:59.952236+00	Vp2x31	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
277	7424107413	\N	Елена Аристархова	USER	RU	0	0	f	f	\N	2026-04-20 14:23:02.083665+00	2026-04-20 14:23:02.083665+00	6ECjOu	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
336	7225475227	\N	Игорь Думенко	USER	RU	0	0	f	f	\N	2026-04-20 14:23:03.451491+00	2026-04-20 14:23:03.451491+00	bpstdx	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
395	7278064469	\N	Горский Денис	USER	RU	0	0	f	f	\N	2026-04-20 14:23:04.768098+00	2026-04-20 14:23:04.768098+00	ieVfpd	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
454	7293629051	\N	Евгений Шевченко	USER	RU	0	0	f	f	\N	2026-04-20 14:23:06.414877+00	2026-04-20 14:23:06.414877+00	boxSkS	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
513	7062738644	chqushuvipdkhc10	Анна	USER	RU	0	0	f	f	\N	2026-04-20 14:23:08.381071+00	2026-04-20 14:23:08.381071+00	cZxyuG	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
670	1064673257	\N	Егор	USER	RU	0	0	f	t	\N	2026-04-26 00:33:55.587875+00	2026-04-28 15:06:50.470719+00	y75k8K	0	t	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
681	5417439348	\N	Наталья Рыжова	USER	RU	0	0	f	f	95	2026-04-26 10:00:33.420419+00	2026-04-26 10:00:55.974321+00	ZaFFkp	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
800	7639895295	wiking011	...	USER	RU	0	0	f	f	190	2026-05-04 03:12:40.931172+00	2026-05-04 03:12:49.403328+00	UmrVjv	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
725	8709027200	\N	8709027200	USER	RU	0	0	f	t	136	2026-04-28 18:09:33.138979+00	2026-04-28 18:10:28.303958+00	zQEao9	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
726	490107533	Bor11515	Юрий Бородин	USER	RU	0	0	f	f	\N	2026-04-28 18:15:33.906591+00	2026-04-28 18:15:37.03039+00	bhXUJ4	0	t	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
830	985794662	\N	Марина Горяйнова	USER	RU	0	0	f	f	211	2026-05-10 05:34:02.714176+00	2026-05-10 05:46:20.077494+00	bc05Lm	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
149	7320198281	chmzpashopiz3	Samir	USER	RU	0	0	f	f	\N	2026-04-20 14:22:56.607521+00	2026-04-20 14:22:56.607521+00	4ixzA3	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
184	7069077029	khztmomothcvpr10	Миха Иванова	USER	RU	0	0	f	f	\N	2026-04-20 14:22:57.913655+00	2026-04-20 14:22:57.913655+00	0XtHu9	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
234	7178769654	\N	Кудинова Марина Феликсовна	USER	RU	0	0	f	f	\N	2026-04-20 14:23:00.160973+00	2026-04-20 14:23:00.160973+00	z8ZEqJ	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
289	6812847389	\N	Лев Арутюнов	USER	RU	0	0	f	f	\N	2026-04-20 14:23:02.35311+00	2026-04-20 14:23:02.35311+00	WRmIXs	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
348	7458198444	bhuflchchtb7	Ilya	USER	RU	0	0	f	f	\N	2026-04-20 14:23:03.766772+00	2026-04-20 14:23:03.766772+00	9Vc9ju	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
407	7445856809	\N	Алексей Новиков	USER	RU	0	0	f	f	\N	2026-04-20 14:23:05.034262+00	2026-04-20 14:23:05.034262+00	Xvpga8	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
466	7045231912	\N	Богданов Владимир	USER	RU	0	0	f	f	\N	2026-04-20 14:23:06.765704+00	2026-04-20 14:23:06.765704+00	b3FiDl	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
525	7050075079	ylmsumsflva5	Анна	USER	RU	0	0	f	f	\N	2026-04-20 14:23:09.015776+00	2026-04-20 14:23:09.015776+00	DjC45v	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
671	8066923905	\N	Аксёна	USER	RU	0	0	f	t	\N	2026-04-26 01:02:07.666457+00	2026-04-26 01:02:29.985973+00	jyocjB	0	t	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
682	8341525065	\N	Matveyq	USER	RU	0	0	f	f	96	2026-04-26 10:02:43.645123+00	2026-04-26 10:03:23.451366+00	CyCTu2	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
831	5196355976	Ancrml	Аня	USER	RU	0	0	f	f	\N	2026-05-10 07:15:50.455144+00	2026-05-10 07:15:53.309274+00	gpa4Xx	0	t	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
736	1434013714	Ignatbes	Игнатий	USER	RU	0	0	f	t	145	2026-04-29 17:27:31.063722+00	2026-05-01 16:51:48.62943+00	Y3jmEN	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
801	336378374	\N	Humantraffic	USER	RU	0	0	f	t	191	2026-05-04 06:43:17.086854+00	2026-05-06 11:44:15.737143+00	bohYai	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
150	7468367470	mraggmbkht5	Anti-spambot	USER	RU	0	0	f	f	\N	2026-04-20 14:22:56.610821+00	2026-04-20 14:22:56.610821+00	Uvdgxv	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
151	7354966146	\N	Елена Казанцева	USER	RU	0	0	f	f	\N	2026-04-20 14:22:56.425919+00	2026-04-20 14:22:56.425919+00	eAtcuN	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
185	7105211061	\N	Хуснутдинов Айрат Энварович	USER	RU	0	0	f	f	\N	2026-04-20 14:22:57.925669+00	2026-04-20 14:22:57.925669+00	t27APF	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
190	7102805530	mwichdcona1	SonG	USER	RU	0	0	f	f	\N	2026-04-20 14:22:57.961412+00	2026-04-20 14:22:57.961412+00	WBq8t8	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
236	7283414970	\N	Воломеев Сергей	USER	RU	0	0	f	f	\N	2026-04-20 14:23:00.177607+00	2026-04-20 14:23:00.177607+00	U4rpoq	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
240	7409273983	ymetrthqzhuzv1	Дмитрий	USER	RU	0	0	f	f	\N	2026-04-20 14:23:00.216911+00	2026-04-20 14:23:00.216911+00	bfFZ0v	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
292	7368778364	icozulobep1	Bor	USER	RU	0	0	f	f	\N	2026-04-20 14:23:02.381021+00	2026-04-20 14:23:02.381021+00	sOrBkF	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
299	7496160754	\N	Тарусин Виктор	USER	RU	0	0	f	f	\N	2026-04-20 14:23:02.642816+00	2026-04-20 14:23:02.642816+00	yJJYLi	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
351	7345173335	\N	Dilya	USER	RU	0	0	f	f	\N	2026-04-20 14:23:03.812317+00	2026-04-20 14:23:03.812317+00	cNh23g	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
610	1522905492	ClownsNotDead21	Даня iguana	USER	RU	0	0	f	f	248	2026-04-24 21:15:25.281821+00	2026-05-27 19:04:09.025717+00	bpeOSz	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
734	477687824	magashka2617	magashka	USER	RU	0	0	f	t	149	2026-04-29 16:56:18.550853+00	2026-05-31 06:03:37.420752+00	qUBjFh	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
358	6607571464	\N	Игорь Кайсин	USER	RU	0	0	f	f	\N	2026-04-20 14:23:04.03618+00	2026-04-20 14:23:04.03618+00	EJFBfy	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
410	6317918580	\N	Роман Шилин	USER	RU	0	0	f	f	\N	2026-04-20 14:23:05.084404+00	2026-04-20 14:23:05.084404+00	PcbqOy	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
417	7494212450	ipychlpowmzh9	Рем	USER	RU	0	0	f	f	\N	2026-04-20 14:23:05.287089+00	2026-04-20 14:23:05.287089+00	cu3z0p	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
469	7475039772	\N	Ольга Завренко	USER	RU	0	0	f	f	\N	2026-04-20 14:23:06.859122+00	2026-04-20 14:23:06.859122+00	bfIXoq	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
476	7394563013	\N	Гусев Владимир Александрович	USER	RU	0	0	f	f	\N	2026-04-20 14:23:07.082948+00	2026-04-20 14:23:07.082948+00	f06VT0	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
672	228833161	Igorvilkov	Игорь	USER	RU	0	0	f	f	88	2026-04-26 01:18:05.78201+00	2026-04-26 01:18:16.484989+00	R82D40	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
683	5226836717	\N	Николай	USER	RU	0	0	f	f	\N	2026-04-26 10:33:18.43733+00	2026-04-26 10:33:22.222943+00	gVAbbU	0	t	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
802	6500276672	Levanskei	067	USER	RU	0	0	f	f	\N	2026-05-04 07:09:26.22603+00	2026-05-04 07:09:28.141022+00	bqQqKi	0	t	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
737	7699352527	\N	Савелий штурмгейст89 ВиваДуче	USER	RU	0	0	f	f	146	2026-04-29 17:51:51.782251+00	2026-04-29 17:51:56.742742+00	1LV8AV	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
832	924940029	realmaksimbro	мąк$им	USER	RU	0	0	f	t	214	2026-05-11 23:44:57.875985+00	2026-05-15 00:53:37.824915+00	iwbglS	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
152	7165553695	\N	Иван Павлов	USER	RU	0	0	f	f	\N	2026-04-20 14:22:56.633601+00	2026-04-20 14:22:56.633601+00	GVYLze	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
187	6573150121	\N	Иван Конев	USER	RU	0	0	f	f	\N	2026-04-20 14:22:57.94849+00	2026-04-20 14:22:57.94849+00	ltwktG	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
237	7234202457	fpqvanoz1	Дмитрий	USER	RU	0	0	f	f	\N	2026-04-20 14:23:00.198195+00	2026-04-20 14:23:00.198195+00	U56tWP	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
296	7398903961	\N	Юдаков Виктор Владимирович	USER	RU	0	0	f	f	\N	2026-04-20 14:23:02.540902+00	2026-04-20 14:23:02.540902+00	8S2RHS	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
356	7049252962	shcophhep1	Миха	USER	RU	0	0	f	f	\N	2026-04-20 14:23:03.978503+00	2026-04-20 14:23:03.978503+00	bundxz	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
415	7136075143	uzuvthdywv1	Chush	USER	RU	0	0	f	f	\N	2026-04-20 14:23:05.238819+00	2026-04-20 14:23:05.238819+00	noUvkU	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
474	7427713419	ipiznkewkhs7	Pavel	USER	RU	0	0	f	f	\N	2026-04-20 14:23:07.075967+00	2026-04-20 14:23:07.075967+00	baWlmL	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
673	5130290114	Shamil8656	Шамиль	USER	RU	0	0	f	t	89	2026-04-26 01:43:38.246675+00	2026-04-26 10:39:50.663039+00	bmmQHm	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
738	6676859774	maksim_0223	Максута	USER	RU	0	0	f	f	147	2026-04-29 18:55:16.602572+00	2026-04-29 18:55:25.72672+00	dKRmNh	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
803	7256065839	hb445	حبيب محمد	USER	RU	0	0	f	f	192	2026-05-04 11:18:04.314446+00	2026-05-04 11:18:13.331301+00	bmeklb	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
684	8406041826	visksiz7	𑀋ꤙӄ᥉ꤘ	USER	RU	0	0	f	f	97	2026-04-26 10:56:23.129129+00	2026-04-26 10:56:30.450664+00	fkFIZ1	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
833	7110643198	\N	123	USER	RU	0	0	f	t	215	2026-05-12 02:51:17.6005+00	2026-05-12 02:53:34.281682+00	j9UExO	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
685	8627210013	danikaada74	Даника	USER	RU	0	0	f	t	98	2026-04-26 11:09:51.180325+00	2026-04-26 11:10:15.637889+00	DhSFRh	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
153	7395037907	\N	Харченко Олег	USER	RU	0	0	f	f	\N	2026-04-20 14:22:56.645793+00	2026-04-20 14:22:56.645793+00	3LBjac	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
188	7492788624	tratataru1	Dmitriy Tarbeev	USER	RU	0	0	f	f	\N	2026-04-20 14:22:57.961092+00	2026-04-20 14:22:57.961092+00	blMCC2	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
239	7066731611	imzhnzhlthsch4	NO	USER	RU	0	0	f	f	\N	2026-04-20 14:23:00.203804+00	2026-04-20 14:23:00.203804+00	QnvxhE	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
298	7057039169	xhpkhidnpzh1	Denis	USER	RU	0	0	f	f	\N	2026-04-20 14:23:02.593916+00	2026-04-20 14:23:02.593916+00	Pik6pb	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
357	6748887010	\N	Панков Олег	USER	RU	0	0	f	f	\N	2026-04-20 14:23:03.993136+00	2026-04-20 14:23:03.993136+00	RbOee3	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
416	7260657319	ftewfhmgsg10	Vasiliy	USER	RU	0	0	f	f	\N	2026-04-20 14:23:05.25387+00	2026-04-20 14:23:05.25387+00	boSoVx	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
475	7352100625	\N	Алексей Никитин	USER	RU	0	0	f	f	\N	2026-04-20 14:23:07.077133+00	2026-04-20 14:23:07.077133+00	bpKkuS	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
674	7131902205	PotashevSergey	Сергей Поташев	USER	RU	0	0	f	t	90	2026-04-26 02:12:19.857658+00	2026-04-26 14:48:06.867179+00	l0FtnT	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
804	8068741584	MaryLeadsgen	Дмитрий Ли	USER	RU	0	0	f	t	\N	2026-05-04 13:02:49.534129+00	2026-05-05 14:50:40.184463+00	bgr6Yc	0	t	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
739	1475267501	qxI_xD	1475267501	USER	RU	0	0	f	t	148	2026-04-30 01:17:32.732463+00	2026-05-02 17:59:01.286021+00	Zbbtnm	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
834	2006993960	flypusik	FlypᏬᏕ	USER	RU	0	0	f	t	216	2026-05-12 04:46:34.401495+00	2026-05-12 04:47:17.233427+00	Y3f1O2	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
155	7369764310	tgthvyvugo10	slava	USER	RU	0	0	f	f	\N	2026-04-20 14:22:56.669425+00	2026-04-20 14:22:56.669425+00	sTzJWa	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
192	7034019132	\N	Дмитрий Леонидович	USER	RU	0	0	f	f	\N	2026-04-20 14:22:58.002879+00	2026-04-20 14:22:58.002879+00	QXRHm0	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
243	7472715901	DemianeekOksana	Оксана Демьяненко	USER	RU	0	0	f	f	\N	2026-04-20 14:23:00.233936+00	2026-04-20 14:23:00.233936+00	wfHQr5	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
302	7287242628	\N	Ирина Заботина	USER	RU	0	0	f	f	\N	2026-04-20 14:23:02.724041+00	2026-04-20 14:23:02.724041+00	b1XlQk	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
361	7439819306	\N	Усачев Юрий Николаевич	USER	RU	0	0	f	f	\N	2026-04-20 14:23:04.065283+00	2026-04-20 14:23:04.065283+00	iOY86i	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
420	7421675547	\N	Константин Радченко	USER	RU	0	0	f	f	\N	2026-04-20 14:23:05.34695+00	2026-04-20 14:23:05.34695+00	3qSvXY	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
479	1330562493	\N	Сергей Мизюра	USER	RU	0	0	f	f	\N	2026-04-20 14:23:07.16147+00	2026-04-20 14:23:07.16147+00	DwNuxw	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
835	1227051309	ikar_dr	Икар	USER	RU	0	0	f	f	\N	2026-05-13 18:16:51.470176+00	2026-05-13 18:16:51.470176+00	kSvT9r	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
740	5203124071	borch1k1	Иса Дагестанчик	USER	RU	0	0	f	t	151	2026-04-30 08:05:08.390119+00	2026-05-04 06:07:14.448678+00	pcn05x	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
805	7969421911	\N	Максимбай	USER	RU	0	0	f	f	193	2026-05-04 13:38:28.884782+00	2026-05-04 13:39:02.644051+00	X1X2yS	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
156	7223140853	assshhgthpyt9	Миха	USER	RU	0	0	f	f	\N	2026-04-20 14:22:56.682657+00	2026-04-20 14:22:56.682657+00	TXLoZZ	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
193	7439303716	\N	Другов Дмитрий Борисович	USER	RU	0	0	f	f	\N	2026-04-20 14:22:58.016758+00	2026-04-20 14:22:58.016758+00	blBWff	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
244	6900366567	\N	Шумаков Игорь	USER	RU	0	0	f	f	\N	2026-04-20 14:23:00.250341+00	2026-04-20 14:23:00.250341+00	bkWyMe	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
303	6392111368	\N	Наталья	USER	RU	0	0	f	f	\N	2026-04-20 14:23:02.738842+00	2026-04-20 14:23:02.738842+00	XghSld	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
362	7264265057	\N	Аркадий Черницын	USER	RU	0	0	f	f	\N	2026-04-20 14:23:04.085661+00	2026-04-20 14:23:04.085661+00	fr3R3I	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
421	7343598327	\N	Галина Божченко	USER	RU	0	0	f	f	\N	2026-04-20 14:23:05.356204+00	2026-04-20 14:23:05.356204+00	brg7WG	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
480	6498115511	akicshpofug10	Шнитко Виктор	USER	RU	0	0	f	f	\N	2026-04-20 14:23:07.289007+00	2026-04-20 14:23:07.289007+00	bpwxY5	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
741	7560357719	MarkHeleket	Mark	USER	RU	0	0	f	f	\N	2026-04-30 09:06:22.429677+00	2026-04-30 09:06:24.214873+00	bjBlrg	0	t	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
806	408300874	purushottamBNK	Purushottama	USER	RU	0	0	f	f	\N	2026-05-04 15:43:30.618876+00	2026-05-04 15:43:34.26528+00	05sjpN	0	t	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
836	8426825252	nertyf	nertyyy	USER	RU	0	0	f	f	220	2026-05-15 10:22:57.794046+00	2026-05-15 10:23:02.116351+00	8JOOwW	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
157	7467695816	\N	Максим Бобров	USER	RU	0	0	f	f	\N	2026-04-20 14:22:56.695499+00	2026-04-20 14:22:56.695499+00	beYMeV	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
194	7248597399	kxusqqzquruw9	SonG	USER	RU	0	0	f	f	\N	2026-04-20 14:22:58.031912+00	2026-04-20 14:22:58.031912+00	tbPOYc	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
245	7234030910	atchhexibejab7	Ira	USER	RU	0	0	f	f	\N	2026-04-20 14:23:00.584225+00	2026-04-20 14:23:00.584225+00	HIjbMQ	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
304	7198381183	ythqrohtkxc8	Ira	USER	RU	0	0	f	f	\N	2026-04-20 14:23:02.752978+00	2026-04-20 14:23:02.752978+00	GUYTBZ	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
363	7248584120	uxodhchoh8	Анна	USER	RU	0	0	f	f	\N	2026-04-20 14:23:04.111032+00	2026-04-20 14:23:04.111032+00	jNtZHJ	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
422	7316713996	\N	Сергеев Дмитрий	USER	RU	0	0	f	f	\N	2026-04-20 14:23:05.430613+00	2026-04-20 14:23:05.430613+00	vqLfIu	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
481	6768686529	\N	Екатерина Кривошеина	USER	RU	0	0	f	f	\N	2026-04-20 14:23:07.321676+00	2026-04-20 14:23:07.321676+00	QPhscB	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
742	5312870136	\N	Сергей	USER	RU	0	0	f	t	152	2026-04-30 09:44:24.508247+00	2026-04-30 10:46:36.33288+00	Ee27dJ	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
807	6288525980	P_A_T_R_U_L_N_A_53_UA	Патрульна поліція Вітає вас	USER	RU	0	0	t	t	\N	2026-05-04 15:54:20.516814+00	2026-05-04 15:55:30.314094+00	boEdXo	0	t	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
158	6988507363	shzhzhdwpqshanmkh2	Вепхиа Чучулаевич	USER	RU	0	0	f	f	\N	2026-04-20 14:22:56.727233+00	2026-04-20 14:22:56.727233+00	sPrhZn	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
195	6853206923	shutyshodljcg6	Andrei Khmelev Кулакова	USER	RU	0	0	f	f	\N	2026-04-20 14:22:58.042045+00	2026-04-20 14:22:58.042045+00	5qyT9Y	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
246	7379485576	ztokebagbthrc2	Sompong	USER	RU	0	0	f	f	\N	2026-04-20 14:23:00.658328+00	2026-04-20 14:23:00.658328+00	USGnAV	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
305	6926342074	\N	Владимир Петрыкин	USER	RU	0	0	f	f	\N	2026-04-20 14:23:02.77365+00	2026-04-20 14:23:02.77365+00	Sswtkm	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
364	7166756544	\N	Боровлёва Юлия	USER	RU	0	0	f	f	\N	2026-04-20 14:23:04.121521+00	2026-04-20 14:23:04.121521+00	blNY3X	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
423	7390082222	\N	Алексей Давыдов	USER	RU	0	0	f	f	\N	2026-04-20 14:23:05.449792+00	2026-04-20 14:23:05.449792+00	qkRZAA	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
483	7448788759	azhodibkciqy4	oxxxqp	USER	RU	0	0	f	f	\N	2026-04-20 14:23:07.336392+00	2026-04-20 14:23:07.336392+00	bkxfNN	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
743	5233422473	contra2406	МАТРОНА	USER	RU	0	0	f	f	185	2026-04-30 11:36:51.190672+00	2026-05-03 11:42:43.440102+00	9EBSod	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
808	1447080406	VaterUSSR	Федя Бубликов	USER	RU	0	0	f	f	\N	2026-05-04 16:35:45.837156+00	2026-05-04 16:35:45.837156+00	evvwa0	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
810	367906205	Sm1rnyga	Sm1rnyga	USER	RU	0	0	f	f	194	2026-05-04 16:42:23.539053+00	2026-05-04 16:45:33.28158+00	LxXLZo	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
160	7285392010	qlyvthkuna1	Anti-spambot	USER	RU	0	0	f	f	\N	2026-04-20 14:22:56.956386+00	2026-04-20 14:22:56.956386+00	bp5itX	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
197	6546191298	\N	Андрей Красноперов	USER	RU	0	0	f	f	\N	2026-04-20 14:22:58.058277+00	2026-04-20 14:22:58.058277+00	0LzNmx	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
248	7253597290	twdzhpdzhduzshk2	Samir	USER	RU	0	0	f	f	\N	2026-04-20 14:23:00.687225+00	2026-04-20 14:23:00.687225+00	6AbRaX	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
307	7274796723	\N	Алексей Бендо	USER	RU	0	0	f	f	\N	2026-04-20 14:23:02.798416+00	2026-04-20 14:23:02.798416+00	FZgACz	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
365	7394591101	\N	Санасарян Сурен	USER	RU	0	0	f	f	\N	2026-04-20 14:23:04.155302+00	2026-04-20 14:23:04.155302+00	FpXVCH	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
424	7286174077	\N	Александр Беляев	USER	RU	0	0	f	f	\N	2026-04-20 14:23:05.522387+00	2026-04-20 14:23:05.522387+00	RqVj25	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
482	7440476426	\N	Евгений Матвеев	USER	RU	0	0	f	f	\N	2026-04-20 14:23:07.336591+00	2026-04-20 14:23:07.336591+00	SYJbii	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
745	8666693791	wesdul	affectionate tenderness.	USER	RU	0	0	f	f	\N	2026-04-30 11:56:41.407551+00	2026-04-30 11:56:42.933229+00	IMoA0c	0	t	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
746	6218027116	\N	.	USER	RU	0	0	f	f	\N	2026-04-30 12:03:06.68023+00	2026-04-30 12:03:06.68023+00	bjMdgW	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
809	1491940586	Aleksey_NVZ	AlekseyN	USER	RU	0	0	f	f	\N	2026-05-04 16:36:46.874234+00	2026-05-04 16:37:26.334006+00	pUgG9N	0	t	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
839	827455639	JanuaryRAM	ЯНВАРЬ	USER	RU	0	0	f	t	223	2026-05-16 07:59:37.560957+00	2026-05-16 19:23:14.612472+00	GDYVDl	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
161	7420598772	ccyngcushawul4	Ira	USER	RU	0	0	f	f	\N	2026-04-20 14:22:57.183592+00	2026-04-20 14:22:57.183592+00	pjZaRQ	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
198	7153350558	mshthrxdynkhqd9	Сергей Царюк	USER	RU	0	0	f	f	\N	2026-04-20 14:22:58.067303+00	2026-04-20 14:22:58.067303+00	ZVrGPi	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
249	7463637838	\N	Голубев Павел	USER	RU	0	0	f	f	\N	2026-04-20 14:23:00.704678+00	2026-04-20 14:23:00.704678+00	BQqlpt	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
308	7185243080	icakxjozhgcnkh9	Дмитрий Ефимов	USER	RU	0	0	f	f	\N	2026-04-20 14:23:02.80843+00	2026-04-20 14:23:02.80843+00	OItWUz	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
367	7026555924	\N	Сергей Григоркевич	USER	RU	0	0	f	f	\N	2026-04-20 14:23:04.178919+00	2026-04-20 14:23:04.178919+00	bmgcWP	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
426	7396385500	\N	Гришаев Сергей	USER	RU	0	0	f	f	\N	2026-04-20 14:23:05.534782+00	2026-04-20 14:23:05.534782+00	FkeXWA	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
485	7448858687	\N	Алексей Бодров	USER	RU	0	0	f	f	\N	2026-04-20 14:23:07.438323+00	2026-04-20 14:23:07.438323+00	GfKkol	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
747	786965404	culinar_art	Алексей Николаенко	USER	RU	0	0	f	t	\N	2026-04-30 12:07:58.21949+00	2026-04-30 12:39:43.525262+00	epRFc9	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
811	6188491953	q_666a	Пирожок	USER	RU	0	0	f	f	\N	2026-05-04 17:07:13.830267+00	2026-05-04 17:07:15.679524+00	emm8O4	0	t	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
840	551288028	dumurt	Мур	USER	RU	0	0	f	f	\N	2026-05-16 09:39:46.66125+00	2026-05-16 09:39:46.791584+00	bbJrc0	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
162	7489493064	bzhfrechuvx10	Дмитрий	USER	RU	0	0	f	f	\N	2026-04-20 14:22:57.403418+00	2026-04-20 14:22:57.403418+00	jrFJ0P	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
199	7346049541	ibjzchxovabyx2	Ilya	USER	RU	0	0	f	f	\N	2026-04-20 14:22:58.344035+00	2026-04-20 14:22:58.344035+00	mmilnY	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
250	7491811013	\N	Евгений Никулин	USER	RU	0	0	f	f	\N	2026-04-20 14:23:00.70833+00	2026-04-20 14:23:00.70833+00	49gHf5	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
309	7073182162	\N	Коденев Алексей	USER	RU	0	0	f	f	\N	2026-04-20 14:23:02.814974+00	2026-04-20 14:23:02.814974+00	BT3E8D	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
368	6880573207	\N	Сергеев Дмитрий	USER	RU	0	0	f	f	\N	2026-04-20 14:23:04.190659+00	2026-04-20 14:23:04.190659+00	V1B6Ns	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
427	6659987306	\N	Igor Ashik	USER	RU	0	0	f	f	\N	2026-04-20 14:23:05.537672+00	2026-04-20 14:23:05.537672+00	ZW344n	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
486	7311651807	uwlfuzhevyru3	Sompong	USER	RU	0	0	f	f	\N	2026-04-20 14:23:07.503767+00	2026-04-20 14:23:07.503767+00	2cggEY	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
841	1893169303	\N	Константин	USER	RU	0	0	f	t	\N	2026-05-16 15:00:35.506869+00	2026-05-16 15:10:21.486522+00	legh5y	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
748	7949213444	kozzza13	KOZA	USER	RU	0	0	f	f	154	2026-04-30 12:48:31.160174+00	2026-04-30 12:48:43.036658+00	blKG92	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
812	8341352889	dlUBOvc	Александр	USER	RU	0	0	f	t	195	2026-05-04 17:37:22.207964+00	2026-05-04 17:38:10.611175+00	beDiwP	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
163	6788822166	ozukhimulachmx10	Анна Орехова	USER	RU	0	0	f	f	\N	2026-04-20 14:22:57.406442+00	2026-04-20 14:22:57.406442+00	bgWFHC	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
200	7394823778	Maksimm_Polukhin	Полухин Максим	USER	RU	0	0	f	f	\N	2026-04-20 14:22:58.422485+00	2026-04-20 14:22:58.422485+00	bccDaO	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
251	7341060537	\N	Владимир Просветов	USER	RU	0	0	f	f	\N	2026-04-20 14:23:00.721553+00	2026-04-20 14:23:00.721553+00	C7eiBQ	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
310	7376133712	\N	Востротин Александр	USER	RU	0	0	f	f	\N	2026-04-20 14:23:02.830585+00	2026-04-20 14:23:02.830585+00	yaNUXT	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
369	7431524586	\N	Гилязиев Роберт	USER	RU	0	0	f	f	\N	2026-04-20 14:23:04.217071+00	2026-04-20 14:23:04.217071+00	tcpaqi	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
428	7346778778	\N	Сабельникова С.И	USER	RU	0	0	f	f	\N	2026-04-20 14:23:05.780091+00	2026-04-20 14:23:05.780091+00	MyX4GU	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
487	7431546240	ucactnagnw10	Алексей	USER	RU	0	0	f	f	\N	2026-04-20 14:23:07.515518+00	2026-04-20 14:23:07.515518+00	lIcnvP	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
749	6885423909	vcdfhjgj	Татьяна	USER	RU	0	0	f	f	155	2026-04-30 13:47:25.750372+00	2026-04-30 13:47:40.09686+00	blaBVG	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
813	1408979993	\N	Антон Кузнецов	USER	RU	0	0	f	f	\N	2026-05-04 18:15:04.286168+00	2026-05-04 18:15:04.286168+00	dp156p	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
842	6305114719	\N	hamzatik352	USER	RU	0	0	f	f	228	2026-05-18 14:38:57.041+00	2026-05-18 14:39:05.411042+00	deWjEY	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
164	7453490673	\N	Михаил Нелюбин	USER	RU	0	0	f	f	\N	2026-04-20 14:22:57.499972+00	2026-04-20 14:22:57.499972+00	NaZuBi	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
201	7351360835	ywychvticgn9	Герасименко Лариса	USER	RU	0	0	f	f	\N	2026-04-20 14:22:58.450905+00	2026-04-20 14:22:58.450905+00	6X6Tdv	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
252	6833737453	ovnwenchteza4	Vasiliy long	USER	RU	0	0	f	f	\N	2026-04-20 14:23:00.737468+00	2026-04-20 14:23:00.737468+00	D13qdW	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
311	7472360536	\N	Семен Прохоренко	USER	RU	0	0	f	f	\N	2026-04-20 14:23:02.841013+00	2026-04-20 14:23:02.841013+00	r969Xg	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
837	760956401	dani_7_13	Дana	USER	RU	0	0	f	t	221	2026-05-15 14:25:51.276205+00	2026-05-30 13:50:15.180217+00	sMypOJ	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
838	710012309	allinabyme	а	USER	RU	0	0	f	t	\N	2026-05-15 19:56:41.147815+00	2026-06-23 21:30:12.282764+00	AwGZVb	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
370	6773494532	\N	Радик Хасанов	USER	RU	0	0	f	f	\N	2026-04-20 14:23:04.281695+00	2026-04-20 14:23:04.281695+00	bhPHHg	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
429	7176927120	\N	Алексей Барвинок	USER	RU	0	0	f	f	\N	2026-04-20 14:23:05.908643+00	2026-04-20 14:23:05.908643+00	WI63tQ	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
488	7260243414	\N	Андрей	USER	RU	0	0	f	f	\N	2026-04-20 14:23:07.546684+00	2026-04-20 14:23:07.546684+00	qnxahD	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
750	8202793630	\N	В Советском Союзе делали это ти	USER	RU	0	0	f	t	156	2026-04-30 14:21:39.731553+00	2026-04-30 14:23:39.528782+00	ozCr3M	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
814	1325429451	\N	Елена	USER	RU	0	0	f	f	\N	2026-05-04 21:47:10.128623+00	2026-05-04 21:47:48.527584+00	xWzKqX	0	t	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
165	6676685293	\N	Марина Кадухина	USER	RU	0	0	f	f	\N	2026-04-20 14:22:57.617257+00	2026-04-20 14:22:57.617257+00	bdzFPO	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
202	6647497786	\N	Наталья Плутова	USER	RU	0	0	f	f	\N	2026-04-20 14:22:58.456681+00	2026-04-20 14:22:58.456681+00	Pmpm3t	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
253	7251793091	vgcwkracun4	Vasiliy	USER	RU	0	0	f	f	\N	2026-04-20 14:23:00.754782+00	2026-04-20 14:23:00.754782+00	trzQPA	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
312	6737551380	jrellzyni9	Samir	USER	RU	0	0	f	f	\N	2026-04-20 14:23:02.84671+00	2026-04-20 14:23:02.84671+00	wE9Ecu	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
371	7252467539	\N	Виталий Сидоров	USER	RU	0	0	f	f	\N	2026-04-20 14:23:04.288926+00	2026-04-20 14:23:04.288926+00	dwMXjp	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
430	7415443356	gcgschqevivoh7	Марина	USER	RU	0	0	f	f	\N	2026-04-20 14:23:05.921715+00	2026-04-20 14:23:05.921715+00	nRERtd	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
489	7445590293	\N	Михаил Железнов	USER	RU	0	0	f	f	\N	2026-04-20 14:23:07.637908+00	2026-04-20 14:23:07.637908+00	xF5j1B	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
751	5406848018	M_A_Gen	Альбина	USER	RU	0	0	f	f	\N	2026-04-30 15:24:29.616743+00	2026-04-30 15:24:29.616743+00	l8wK9c	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
166	7206411290	\N	Юрий Сорокин	USER	RU	0	0	f	f	\N	2026-04-20 14:22:57.645913+00	2026-04-20 14:22:57.645913+00	bbM6kz	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
203	7132517841	zhxkchqhfgosnz8	Миха	USER	RU	0	0	f	f	\N	2026-04-20 14:22:58.490506+00	2026-04-20 14:22:58.490506+00	bePjeF	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
254	7400978359	\N	Гаазе Ольга	USER	RU	0	0	f	f	\N	2026-04-20 14:23:00.765948+00	2026-04-20 14:23:00.765948+00	nS5o1g	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
313	7104936886	gshatejccezq5	Рем	USER	RU	0	0	f	f	\N	2026-04-20 14:23:02.853615+00	2026-04-20 14:23:02.853615+00	o1CNfD	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
372	7391151265	\N	RN	USER	RU	0	0	f	f	\N	2026-04-20 14:23:04.31572+00	2026-04-20 14:23:04.31572+00	MvOUCQ	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
431	7428305063	\N	Andrey Kildiiarov	USER	RU	0	0	f	f	\N	2026-04-20 14:23:05.963352+00	2026-04-20 14:23:05.963352+00	bkEQMh	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
490	6444883211	ozhhrqgyl8	Ilya	USER	RU	0	0	f	f	\N	2026-04-20 14:23:07.666916+00	2026-04-20 14:23:07.666916+00	qAPK7v	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
752	8766782393	GaIaxy500	САНЕМИ	USER	RU	0	0	f	f	157	2026-04-30 15:46:30.334751+00	2026-04-30 15:46:33.932468+00	boD3uE	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
816	7843181300	\N	Михаил	USER	RU	0	0	f	f	196	2026-05-05 05:57:47.38626+00	2026-05-05 05:59:27.045239+00	beK3hR	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
167	7431088278	ocozskhlgtlh5	Zakir	USER	RU	0	0	f	f	\N	2026-04-20 14:22:57.680938+00	2026-04-20 14:22:57.680938+00	bktf5J	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
204	7167504078	\N	Khamidullin Ruslan	USER	RU	0	0	f	f	\N	2026-04-20 14:22:58.954342+00	2026-04-20 14:22:58.954342+00	IFmC7N	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
255	7438346139	\N	Тарасов М.А.	USER	RU	0	0	f	f	\N	2026-04-20 14:23:00.775988+00	2026-04-20 14:23:00.775988+00	1AFUEL	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
314	7062405915	\N	Александ Чулков	USER	RU	0	0	f	f	\N	2026-04-20 14:23:02.890979+00	2026-04-20 14:23:02.890979+00	Y4Ni57	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
373	7020719005	\N	Александр Дроздов	USER	RU	0	0	f	f	\N	2026-04-20 14:23:04.334704+00	2026-04-20 14:23:04.334704+00	JkGvUy	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
432	7353247648	\N	Сергей Слепов	USER	RU	0	0	f	f	\N	2026-04-20 14:23:05.987498+00	2026-04-20 14:23:05.987498+00	ciKYVw	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
491	7408520048	fdvnezrw7	Ira	USER	RU	0	0	f	f	\N	2026-04-20 14:23:07.669737+00	2026-04-20 14:23:07.669737+00	6BPdoY	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
753	6930967651	Eqlips_777	ΈǭłᎥҏ$	USER	RU	0	0	f	t	158	2026-04-30 17:30:01.918272+00	2026-05-02 18:32:17.723814+00	Edsyd5	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
817	6255838509	UE_Dem	Дем	USER	RU	0	0	f	f	197	2026-05-05 08:38:27.311538+00	2026-05-05 08:39:44.698931+00	e1ssCK	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
168	7041721969	trzckhhjd1	Chush	USER	RU	0	0	f	f	\N	2026-04-20 14:22:57.727951+00	2026-04-20 14:22:57.727951+00	mLuHVH	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
205	7174001640	\N	Иван Вымлятин	USER	RU	0	0	f	f	\N	2026-04-20 14:22:59.040879+00	2026-04-20 14:22:59.040879+00	jBm6kW	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
256	7145794716	\N	Александр Воробьев	USER	RU	0	0	f	f	\N	2026-04-20 14:23:00.808489+00	2026-04-20 14:23:00.808489+00	JA3qCx	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
315	7314028676	shxlbbcoxach1	Sompong	USER	RU	0	0	f	f	\N	2026-04-20 14:23:02.920844+00	2026-04-20 14:23:02.920844+00	bclzax	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
374	7483113939	yshuflryr6	Gadjimurad	USER	RU	0	0	f	f	\N	2026-04-20 14:23:04.362205+00	2026-04-20 14:23:04.362205+00	ILphxz	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
433	6753127049	\N	Сергей Тарчуткин	USER	RU	0	0	f	f	\N	2026-04-20 14:23:05.987997+00	2026-04-20 14:23:05.987997+00	htY1V2	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
492	7013215746	\N	.	USER	RU	0	0	f	f	\N	2026-04-20 14:23:07.702084+00	2026-04-20 14:23:07.702084+00	26rxim	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
754	5116868592	Korvusli	Hibo	USER	RU	0	0	f	f	159	2026-04-30 19:53:49.010919+00	2026-04-30 19:53:53.513317+00	xomhlt	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
818	1670556845	\N	Лила Ишвари	USER	RU	0	0	f	t	\N	2026-05-05 09:06:02.984412+00	2026-05-05 09:08:57.050637+00	Os86lZ	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
169	6804486744	\N	Руденко Алексей	USER	RU	0	0	f	f	\N	2026-04-20 14:22:57.745118+00	2026-04-20 14:22:57.745118+00	kCPzWX	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
171	6888226470	\N	Владимир Рейнюк	USER	RU	0	0	f	f	\N	2026-04-20 14:22:57.266783+00	2026-04-20 14:22:57.266783+00	tt8F4X	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
173	6949153488	nwthqashmdiz6	Инна	USER	RU	0	0	f	f	\N	2026-04-20 14:22:57.272519+00	2026-04-20 14:22:57.272519+00	759wVW	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
174	7280737377	afecshtpshgt6	Samir	USER	RU	0	0	f	f	\N	2026-04-20 14:22:57.30035+00	2026-04-20 14:22:57.30035+00	boFEDa	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
175	6423322805	\N	Евгений Финкельштейн	USER	RU	0	0	f	f	\N	2026-04-20 14:22:57.404018+00	2026-04-20 14:22:57.404018+00	fcyip7	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
176	7218790478	\N	Евгений Трусов	USER	RU	0	0	f	f	\N	2026-04-20 14:22:57.499899+00	2026-04-20 14:22:57.499899+00	baqpty	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
206	7497721621	\N	Александр Игнатьев	USER	RU	0	0	f	f	\N	2026-04-20 14:22:59.05738+00	2026-04-20 14:22:59.05738+00	bmu8nD	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
212	7241060297	\N	Кетеван Бугрова	USER	RU	0	0	f	f	\N	2026-04-20 14:22:59.615337+00	2026-04-20 14:22:59.615337+00	bqfEKS	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
219	7389838892	\N	1	USER	RU	0	0	f	f	\N	2026-04-20 14:22:59.784093+00	2026-04-20 14:22:59.784093+00	frcDn5	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
220	7410354048	\N	Щербинин Евгений	USER	RU	0	0	f	f	\N	2026-04-20 14:22:59.800665+00	2026-04-20 14:22:59.800665+00	MSRdZp	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
222	7409301268	\N	Белан Сергей	USER	RU	0	0	f	f	\N	2026-04-20 14:22:59.812684+00	2026-04-20 14:22:59.812684+00	CsaR4A	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
217	6926469043	\N	Пуртов К.С	USER	RU	0	0	f	f	\N	2026-04-20 14:22:59.760836+00	2026-04-20 14:23:01.130585+00	4yMvTS	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
257	7297212697	\N	Кудинова Марина Феликсовна	USER	RU	0	0	f	f	\N	2026-04-20 14:23:00.831047+00	2026-04-20 14:23:00.831047+00	b5jdmy	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
263	7046446556	\N	Шаяхметов Р.Р.	USER	RU	0	0	f	f	\N	2026-04-20 14:23:00.970734+00	2026-04-20 14:23:00.970734+00	baxjCQ	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
268	7422975458	\N	Ирина Есипенко	USER	RU	0	0	f	f	\N	2026-04-20 14:23:01.420768+00	2026-04-20 14:23:01.420768+00	bpzEvh	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
270	7304272418	\N	Игорь Угаров	USER	RU	0	0	f	f	\N	2026-04-20 14:23:01.472073+00	2026-04-20 14:23:01.472073+00	hWdWyJ	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
271	7404687839	\N	Радионова Светлана	USER	RU	0	0	f	f	\N	2026-04-20 14:23:01.57325+00	2026-04-20 14:23:01.57325+00	OB4xPr	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
273	7174260970	zhtafabedfzhy1	oxxxqp	USER	RU	0	0	f	f	\N	2026-04-20 14:23:01.668491+00	2026-04-20 14:23:01.668491+00	1qGB5l	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
316	6858248295	\N	К	USER	RU	0	0	f	f	\N	2026-04-20 14:23:02.940604+00	2026-04-20 14:23:02.940604+00	dsfIAj	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
322	7369130617	ixalamithyrhx2	Анна	USER	RU	0	0	f	f	\N	2026-04-20 14:23:03.023555+00	2026-04-20 14:23:03.023555+00	b9A73C	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
327	7216125388	\N	Сергей Леонов	USER	RU	0	0	f	f	\N	2026-04-20 14:23:03.236133+00	2026-04-20 14:23:03.236133+00	7Rp6ea	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
329	6837172151	\N	Петр С	USER	RU	0	0	f	f	\N	2026-04-20 14:23:03.257582+00	2026-04-20 14:23:03.257582+00	TzthLl	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
330	7493986530	kchizhwbthijy1	Анна	USER	RU	0	0	f	f	\N	2026-04-20 14:23:03.262965+00	2026-04-20 14:23:03.262965+00	8Toi9U	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
332	7475386990	\N	Ольга Соболева	USER	RU	0	0	f	f	\N	2026-04-20 14:23:03.28945+00	2026-04-20 14:23:03.28945+00	oZZjcq	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
376	7232032870	\N	Сергей Якжин	USER	RU	0	0	f	f	\N	2026-04-20 14:23:04.39151+00	2026-04-20 14:23:04.39151+00	oQ6U9B	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
381	7307510835	wrahbhodch7	Анна	USER	RU	0	0	f	f	\N	2026-04-20 14:23:04.451914+00	2026-04-20 14:23:04.451914+00	dbBn6J	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
386	7209103418	\N	Еремин Олег	USER	RU	0	0	f	f	\N	2026-04-20 14:23:04.564737+00	2026-04-20 14:23:04.564737+00	kCgqwI	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
388	6849930782	asymyddqg3	Анна	USER	RU	0	0	f	f	\N	2026-04-20 14:23:04.569383+00	2026-04-20 14:23:04.569383+00	lyXsZK	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
389	6433996072	fyhgdjshfgkah	Чернышова Марина	USER	RU	0	0	f	f	\N	2026-04-20 14:23:04.579036+00	2026-04-20 14:23:04.579036+00	QpGfKA	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
391	7122237892	\N	Максим Захаревич	USER	RU	0	0	f	f	\N	2026-04-20 14:23:04.586201+00	2026-04-20 14:23:04.586201+00	7lBhFi	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
436	7276965181	kkfthtkdshw5	Pavel	USER	RU	0	0	f	f	\N	2026-04-20 14:23:06.02263+00	2026-04-20 14:23:06.02263+00	bkLsve	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
440	7226638120	irixynulibe5	Sompong	USER	RU	0	0	f	f	\N	2026-04-20 14:23:06.156623+00	2026-04-20 14:23:06.156623+00	bpdIQ4	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
445	7401889730	\N	Апексимова Ирина	USER	RU	0	0	f	f	\N	2026-04-20 14:23:06.18364+00	2026-04-20 14:23:06.18364+00	0uv7VR	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
447	7473642120	\N	Сергей Бойко	USER	RU	0	0	f	f	\N	2026-04-20 14:23:06.223701+00	2026-04-20 14:23:06.223701+00	WvLac8	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
448	7225128574	\N	Александр Корчак	USER	RU	0	0	f	f	\N	2026-04-20 14:23:06.229512+00	2026-04-20 14:23:06.229512+00	1I1RyG	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
450	7118147405	lthjshkhvithu6	oxxxqp	USER	RU	0	0	f	f	\N	2026-04-20 14:23:06.333921+00	2026-04-20 14:23:06.333921+00	7NpCsd	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
495	7465918207	kkhrthgbiv9	Denis	USER	RU	0	0	f	f	\N	2026-04-20 14:23:07.790882+00	2026-04-20 14:23:07.790882+00	TnnYh9	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
500	7453211768	xsdchrwiwmvnm6	Дмитрий	USER	RU	0	0	f	f	\N	2026-04-20 14:23:08.055611+00	2026-04-20 14:23:08.055611+00	SWHTnI	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
504	7317992389	\N	Михайлов Сергей	USER	RU	0	0	f	f	\N	2026-04-20 14:23:08.118153+00	2026-04-20 14:23:08.118153+00	PjEBb8	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
506	6954314423	khsopocycfnkh2	Анна	USER	RU	0	0	f	f	\N	2026-04-20 14:23:08.202414+00	2026-04-20 14:23:08.202414+00	bmi3j8	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
507	6606922596	shqukhtzthshibfc5	Миха	USER	RU	0	0	f	f	\N	2026-04-20 14:23:08.202729+00	2026-04-20 14:23:08.202729+00	9B8YbE	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
509	7010477957	\N	Сергей Осипов	USER	RU	0	0	f	f	\N	2026-04-20 14:23:08.231841+00	2026-04-20 14:23:08.231841+00	beLqRQ	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
819	6518537738	Kachok1234567890	Мансур Халфин	USER	RU	0	0	f	t	198	2026-05-05 10:23:19.421142+00	2026-05-05 15:26:29.119296+00	3gaJi7	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
755	751921839	\N	верде	USER	RU	0	0	f	t	\N	2026-04-30 19:59:24.62556+00	2026-05-15 19:27:31.104446+00	FvrhSV	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
177	7383316244	\N	Вячеслав Дрёмов	USER	RU	0	0	f	f	\N	2026-04-20 14:22:57.794499+00	2026-04-20 14:22:57.794499+00	gHjZ9U	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
180	7319524003	\N	Владимир Артемьев	USER	RU	0	0	f	f	\N	2026-04-20 14:22:57.626178+00	2026-04-20 14:22:57.626178+00	brRQI7	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
182	7294668602	\N	Голубев Павел	USER	RU	0	0	f	f	\N	2026-04-20 14:22:57.619656+00	2026-04-20 14:22:57.619656+00	ZuinRL	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
183	7231878023	\N	Завалишина Наталья Николаевна	USER	RU	0	0	f	f	\N	2026-04-20 14:22:57.672058+00	2026-04-20 14:22:57.672058+00	MceEJ0	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
186	7466735922	\N	Борис Величкин	USER	RU	0	0	f	f	\N	2026-04-20 14:22:57.689175+00	2026-04-20 14:22:57.689175+00	fGtvlH	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
189	7338382935	chricutwbybxs1	Анна	USER	RU	0	0	f	f	\N	2026-04-20 14:22:57.730561+00	2026-04-20 14:22:57.730561+00	bibshn	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
207	6996180060	\N	Максим Яковлев	USER	RU	0	0	f	f	\N	2026-04-20 14:22:58.482339+00	2026-04-20 14:22:58.482339+00	bnKo5q	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
208	7331866625	\N	Алексей Рощин	USER	RU	0	0	f	f	\N	2026-04-20 14:22:58.490067+00	2026-04-20 14:22:58.490067+00	bbqgWe	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
210	7365792037	\N	Александр Перепелов	USER	RU	0	0	f	f	\N	2026-04-20 14:22:58.551233+00	2026-04-20 14:22:58.551233+00	ieTbAH	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
211	6974631796	\N	Шаталова Алла	USER	RU	0	0	f	f	\N	2026-04-20 14:22:58.702785+00	2026-04-20 14:22:58.702785+00	obPGYz	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
213	7050217553	\N	Наталья Олеговна Василенко	USER	RU	0	0	f	f	\N	2026-04-20 14:22:58.969937+00	2026-04-20 14:22:58.969937+00	sdfNtS	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
215	6996892564	Kostomarov_vasilii	Костомаров Василий Сергеевич	USER	RU	0	0	f	f	\N	2026-04-20 14:22:59.030247+00	2026-04-20 14:22:59.030247+00	cmhh8N	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
216	7339664840	gdnjvzizuv6	Chush	USER	RU	0	0	f	f	\N	2026-04-20 14:22:59.043754+00	2026-04-20 14:22:59.043754+00	9pK61y	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
218	7060725312	\N	Юрий Николаевич Ерёмин	USER	RU	0	0	f	f	\N	2026-04-20 14:22:59.255586+00	2026-04-20 14:22:59.255586+00	IPu2RY	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
221	6700996795	\N	Крючков Александр	USER	RU	0	0	f	f	\N	2026-04-20 14:22:59.32534+00	2026-04-20 14:22:59.32534+00	bpogf3	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
223	7047451651	\N	Алексей Свириденко	USER	RU	0	0	f	f	\N	2026-04-20 14:22:59.876577+00	2026-04-20 14:22:59.876577+00	qWUvUl	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
226	7435782158	ebithmtithtzh4	Рем	USER	RU	0	0	f	f	\N	2026-04-20 14:22:59.640137+00	2026-04-20 14:22:59.640137+00	w66v2e	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
228	7252147772	ithldixqbc5	Анна	USER	RU	0	0	f	f	\N	2026-04-20 14:22:59.670349+00	2026-04-20 14:22:59.670349+00	zliBSA	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
229	6846886157	zgahfnokhlblzh2	Samir Орлова	USER	RU	0	0	f	f	\N	2026-04-20 14:22:59.670798+00	2026-04-20 14:22:59.670798+00	bdWmra	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
230	7067607532	\N	Тутулин Иван	USER	RU	0	0	f	f	\N	2026-04-20 14:22:59.709033+00	2026-04-20 14:22:59.709033+00	T2wxNP	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
231	7202615296	\N	Орловский Евгений	USER	RU	0	0	f	f	\N	2026-04-20 14:22:59.976785+00	2026-04-20 14:22:59.976785+00	kSZ8CY	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
232	7447217681	\N	Анна Голтелова	USER	RU	0	0	f	f	\N	2026-04-20 14:22:59.758273+00	2026-04-20 14:22:59.758273+00	T6Wu9h	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
233	7112432693	uhbvehdr10	Samir	USER	RU	0	0	f	f	\N	2026-04-20 14:23:00.055825+00	2026-04-20 14:23:00.055825+00	XinPmt	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
235	7472809344	rspdawchm4	Ilya	USER	RU	0	0	f	f	\N	2026-04-20 14:23:00.17362+00	2026-04-20 14:23:00.17362+00	p2xYZN	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
238	6985498584	\N	oxxxqp	USER	RU	0	0	f	f	\N	2026-04-20 14:23:00.198641+00	2026-04-20 14:23:00.198641+00	dqsaiO	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
242	7418702199	vxiklhac7	Инна	USER	RU	0	0	f	f	\N	2026-04-20 14:23:00.230304+00	2026-04-20 14:23:00.230304+00	6KZ8O2	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
258	7227331186	osrbppsch9	Bogdan	USER	RU	0	0	f	f	\N	2026-04-20 14:23:00.880925+00	2026-04-20 14:23:00.880925+00	ubP4Iu	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
260	7313812923	\N	Четвериков Сергей Геннадьевич	USER	RU	0	0	f	f	\N	2026-04-20 14:23:00.894772+00	2026-04-20 14:23:00.894772+00	bjduiG	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
261	7278100939	\N	Белобров В.В.	USER	RU	0	0	f	f	\N	2026-04-20 14:23:00.909732+00	2026-04-20 14:23:00.909732+00	8NbxcF	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
262	7437377141	chchonefnmubiz6	Миха	USER	RU	0	0	f	f	\N	2026-04-20 14:23:00.914624+00	2026-04-20 14:23:00.914624+00	bbjJLt	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
264	7492081714	\N	Алексей Коденев	USER	RU	0	0	f	f	\N	2026-04-20 14:23:01.017848+00	2026-04-20 14:23:01.017848+00	qcTrMB	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
266	7224885382	hlscnzhysh10	Рем	USER	RU	0	0	f	f	\N	2026-04-20 14:23:01.090826+00	2026-04-20 14:23:01.090826+00	uhroHK	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
267	7450519923	ehashvzhazh4	Ira	USER	RU	0	0	f	f	\N	2026-04-20 14:23:01.120816+00	2026-04-20 14:23:01.120816+00	RGBIJ9	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
269	7216267040	AlnaK2911	Рем	USER	RU	0	0	f	f	\N	2026-04-20 14:23:01.454605+00	2026-04-20 14:23:01.454605+00	jG04ma	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
272	7325860999	\N	Белан Сергей	USER	RU	0	0	f	f	\N	2026-04-20 14:23:01.592735+00	2026-04-20 14:23:01.592735+00	LVFU7C	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
274	7090929231	lwyppbuxchfxx5	Pavel	USER	RU	0	0	f	f	\N	2026-04-20 14:23:01.950342+00	2026-04-20 14:23:01.950342+00	bbrJRY	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
278	6441697181	\N	Андрей Маталыга	USER	RU	0	0	f	f	\N	2026-04-20 14:23:02.084073+00	2026-04-20 14:23:02.084073+00	Mju1aN	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
279	7198679153	ubtfrchxfuzhy10	Ilya	USER	RU	0	0	f	f	\N	2026-04-20 14:23:02.097872+00	2026-04-20 14:23:02.097872+00	r9sgjh	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
280	7198098954	\N	Негоица Павел	USER	RU	0	0	f	f	\N	2026-04-20 14:23:02.103546+00	2026-04-20 14:23:02.103546+00	wTpC3v	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
281	7343409963	etewwchbpqjyb7	Vasiliy	USER	RU	0	0	f	f	\N	2026-04-20 14:23:02.101666+00	2026-04-20 14:23:02.101666+00	oatEGh	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
282	7276814834	\N	Andrey Nizov	USER	RU	0	0	f	f	\N	2026-04-20 14:23:02.123684+00	2026-04-20 14:23:02.123684+00	QfQ0r0	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
283	6308959854	idyzhtdscikus7	Миха Федорук	USER	RU	0	0	f	f	\N	2026-04-20 14:23:01.77623+00	2026-04-20 14:23:01.77623+00	C5IqS4	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
284	7464092625	\N	Белан Сергей	USER	RU	0	0	f	f	\N	2026-04-20 14:23:01.765329+00	2026-04-20 14:23:01.765329+00	8YRPHS	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
285	7295638836	\N	Oleg Gerilovich	USER	RU	0	0	f	f	\N	2026-04-20 14:23:02.251787+00	2026-04-20 14:23:02.251787+00	bq1btf	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
286	7476749427	\N	Юрий Бурлачко	USER	RU	0	0	f	f	\N	2026-04-20 14:23:02.25275+00	2026-04-20 14:23:02.25275+00	f6uPGh	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
287	7233589765	achodyjjzhtffd3	NO	USER	RU	0	0	f	f	\N	2026-04-20 14:23:01.842996+00	2026-04-20 14:23:01.842996+00	wgTjss	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
288	7421379882	\N	Максим Захаревич	USER	RU	0	0	f	f	\N	2026-04-20 14:23:01.988266+00	2026-04-20 14:23:01.988266+00	uWzZ9G	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
290	7138901894	nataIfeeI	Филь Наталья	USER	RU	0	0	f	f	\N	2026-04-20 14:23:02.064428+00	2026-04-20 14:23:02.064428+00	AhztHp	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
291	7482839312	xfthwashozkh9	Ilya	USER	RU	0	0	f	f	\N	2026-04-20 14:23:02.359914+00	2026-04-20 14:23:02.359914+00	biMyTG	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
293	7462017304	okfkhichqzhddvs7	Denis	USER	RU	0	0	f	f	\N	2026-04-20 14:23:02.098764+00	2026-04-20 14:23:02.098764+00	cEor4P	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
294	7001618168	\N	Орловский Евгений	USER	RU	0	0	f	f	\N	2026-04-20 14:23:02.119636+00	2026-04-20 14:23:02.119636+00	o1IESQ	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
295	7186646131	\N	Natalia Leitis	USER	RU	0	0	f	f	\N	2026-04-20 14:23:02.119586+00	2026-04-20 14:23:02.119586+00	8nTzyi	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
297	7401129411	\N	Архипов Александр	USER	RU	0	0	f	f	\N	2026-04-20 14:23:02.591927+00	2026-04-20 14:23:02.591927+00	WVJHIf	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
301	7297179962	\N	Татьяна Гречаная	USER	RU	0	0	f	f	\N	2026-04-20 14:23:02.696382+00	2026-04-20 14:23:02.696382+00	TwyqHC	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
317	7295930733	\N	Мельников Дмитрий	USER	RU	0	0	f	f	\N	2026-04-20 14:23:02.94931+00	2026-04-20 14:23:02.94931+00	YDtKGu	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
319	7213957980	Oxsav113	Оксана Савченко	USER	RU	0	0	f	f	\N	2026-04-20 14:23:02.958925+00	2026-04-20 14:23:02.958925+00	ILmdHb	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
320	7324556223	\N	.	USER	RU	0	0	f	f	\N	2026-04-20 14:23:02.971229+00	2026-04-20 14:23:02.971229+00	bp3KdT	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
321	7167961722	jpdsxshezhate4	Анна	USER	RU	0	0	f	f	\N	2026-04-20 14:23:03.004365+00	2026-04-20 14:23:03.004365+00	E36WvB	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
323	7373995699	\N	Егоров Игорь	USER	RU	0	0	f	f	\N	2026-04-20 14:23:03.052005+00	2026-04-20 14:23:03.052005+00	LpdPJs	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
325	7274312327	\N	Шумаков Игорь	USER	RU	0	0	f	f	\N	2026-04-20 14:23:03.105779+00	2026-04-20 14:23:03.105779+00	bh17gK	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
326	5155080588	\N	Эльмира Хамидулина	USER	RU	0	0	f	f	\N	2026-04-20 14:23:03.14659+00	2026-04-20 14:23:03.14659+00	bbIDOc	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
385	7250506501	\N	Иванов Игорь Вадимович	USER	RU	0	0	f	f	\N	2026-04-20 14:23:04.507708+00	2026-04-20 14:23:04.507708+00	brs7MB	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
444	7256806485	\N	Якубова И.И	USER	RU	0	0	f	f	\N	2026-04-20 14:23:06.181251+00	2026-04-20 14:23:06.181251+00	HGcGUO	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
503	7419121243	\N	Александр Вилорович	USER	RU	0	0	f	f	\N	2026-04-20 14:23:08.100754+00	2026-04-20 14:23:08.100754+00	xld6RS	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
820	932097426	\N	Qosim	USER	RU	0	0	f	t	200	2026-05-06 05:52:33.177608+00	2026-05-14 05:29:39.13204+00	lzM3qd	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
756	6701078776	dimaa2131	Дима	USER	RU	0	0	f	t	\N	2026-04-30 20:09:21.351726+00	2026-04-30 20:09:32.564757+00	fEoW9B	0	t	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
328	7097624059	\N	Сергей Булах	USER	RU	0	0	f	f	\N	2026-04-20 14:23:03.23625+00	2026-04-20 14:23:03.23625+00	q9d4s2	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
387	7384759645	klhxthreshjchekh7	Анна	USER	RU	0	0	f	f	\N	2026-04-20 14:23:04.565016+00	2026-04-20 14:23:04.565016+00	FkSbRQ	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
446	6942709232	pwckjfusuxob5	Миха	USER	RU	0	0	f	f	\N	2026-04-20 14:23:06.189478+00	2026-04-20 14:23:06.189478+00	bkGB7j	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
505	6304941998	\N	Аркадий Литвин	USER	RU	0	0	f	f	\N	2026-04-20 14:23:08.118829+00	2026-04-20 14:23:08.118829+00	Tjuwvh	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
757	8478756589	\N	Шах	USER	RU	0	0	f	t	\N	2026-05-01 04:42:46.070255+00	2026-05-01 04:43:00.795155+00	nSbEbp	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
331	7468010344	\N	Никитина Алина Алексеевна	USER	RU	0	0	f	f	\N	2026-04-20 14:23:03.267281+00	2026-04-20 14:23:03.267281+00	S8aG5C	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
390	7034119483	milenaindulissovna	Милена Калачева	USER	RU	0	0	f	f	\N	2026-04-20 14:23:04.580489+00	2026-04-20 14:23:04.580489+00	ql0f0R	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
449	7381145937	kxelzjlkhamw7	Samir	USER	RU	0	0	f	f	\N	2026-04-20 14:23:06.277626+00	2026-04-20 14:23:06.277626+00	vqPTZ0	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
508	7287003838	ugozothflqch7	Chris Lai	USER	RU	0	0	f	f	\N	2026-04-20 14:23:08.209714+00	2026-04-20 14:23:08.209714+00	bi0217	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
758	8288903567	p41n1	8288903567	USER	RU	0	0	f	f	160	2026-05-01 06:09:00.736927+00	2026-05-01 06:09:07.963863+00	XNSDAs	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
333	7495540807	\N	Федулов Михаил	USER	RU	0	0	f	f	\N	2026-04-20 14:23:03.41896+00	2026-04-20 14:23:03.41896+00	Lqv1pM	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
392	7196450715	fjzhthkhdoq7	Миха	USER	RU	0	0	f	f	\N	2026-04-20 14:23:04.72921+00	2026-04-20 14:23:04.72921+00	bgbUBX	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
451	6608027146	\N	Алексей Шубин	USER	RU	0	0	f	f	\N	2026-04-20 14:23:06.365577+00	2026-04-20 14:23:06.365577+00	MCOVlG	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
510	7081185112	obchbpgashk1	Zakir	USER	RU	0	0	f	f	\N	2026-04-20 14:23:08.244489+00	2026-04-20 14:23:08.244489+00	W0mPHF	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
759	8597265677	\N	Smaller	USER	RU	0	0	f	t	161	2026-05-01 06:13:05.87607+00	2026-05-03 15:55:28.93546+00	blUSXx	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
337	7251997613	\N	Панков Олег	USER	RU	0	0	f	f	\N	2026-04-20 14:23:03.457441+00	2026-04-20 14:23:03.457441+00	461Ijz	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
396	7419968661	yjykhbhhkhuthob7	Samir	USER	RU	0	0	f	f	\N	2026-04-20 14:23:04.7778+00	2026-04-20 14:23:04.7778+00	SuNApH	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
455	7085680005	\N	Гонтарь Наталья	USER	RU	0	0	f	f	\N	2026-04-20 14:23:06.415198+00	2026-04-20 14:23:06.415198+00	4PtqwQ	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
514	7309003219	\N	Тадеуш Станкевич	USER	RU	0	0	f	f	\N	2026-04-20 14:23:08.494557+00	2026-04-20 14:23:08.494557+00	HdS8cL	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
338	7354137905	\N	Николай Горлач	USER	RU	0	0	f	f	\N	2026-04-20 14:23:03.483361+00	2026-04-20 14:23:03.483361+00	ryesgT	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
397	7431685292	\N	Ермоленко В.А	USER	RU	0	0	f	f	\N	2026-04-20 14:23:04.783087+00	2026-04-20 14:23:04.783087+00	BjqBGG	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
456	7284593691	Svetlan_Plygun	Светлана Плыгун	USER	RU	0	0	f	f	\N	2026-04-20 14:23:06.428109+00	2026-04-20 14:23:06.428109+00	ghlt61	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
515	6809238946	\N	Волков Вячеслав	USER	RU	0	0	f	f	\N	2026-04-20 14:23:08.507407+00	2026-04-20 14:23:08.507407+00	sA1oN1	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
761	675794841	EXleis	THS	USER	RU	0	0	f	f	163	2026-05-01 12:34:23.916767+00	2026-05-01 12:34:27.66969+00	bf5ZPM	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
339	7154852056	\N	Панков Олег	USER	RU	0	0	f	f	\N	2026-04-20 14:23:03.489785+00	2026-04-20 14:23:03.489785+00	XloI1j	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
398	1469153541	\N	Евгений Кодаченко	USER	RU	0	0	f	f	\N	2026-04-20 14:23:04.789319+00	2026-04-20 14:23:04.789319+00	K1nav7	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
457	6428401153	rzhpthyxzl1	Натали	USER	RU	0	0	f	f	\N	2026-04-20 14:23:06.448737+00	2026-04-20 14:23:06.448737+00	D02hwz	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
516	7383184988	xsbchyqyshith2	Рем	USER	RU	0	0	f	f	\N	2026-04-20 14:23:08.512398+00	2026-04-20 14:23:08.512398+00	jO4ggh	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
762	167545420	Kat_korsak	Ekaterina	USER	RU	0	0	f	t	\N	2026-05-01 13:18:20.514514+00	2026-05-01 13:18:42.064705+00	wmgS8I	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
763	5222459400	\N	Про	USER	RU	0	0	f	t	165	2026-05-01 13:26:16.668937+00	2026-05-01 16:30:26.994733+00	bld5wk	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
340	7185062327	\N	Сергей Медведев	USER	RU	0	0	f	f	\N	2026-04-20 14:23:03.500003+00	2026-04-20 14:23:03.500003+00	bfZT4P	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
399	7095580222	\N	Дмитрий Геннадьевич	USER	RU	0	0	f	f	\N	2026-04-20 14:23:04.821588+00	2026-04-20 14:23:04.821588+00	JjKDNw	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
458	7446429372	umazejbmof5	Рем	USER	RU	0	0	f	f	\N	2026-04-20 14:23:06.529386+00	2026-04-20 14:23:06.529386+00	T5q2I8	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
517	7069608183	\N	ТЕНЬ СУКА	USER	RU	0	0	f	f	\N	2026-04-20 14:23:08.521309+00	2026-04-20 14:23:08.521309+00	bojqfK	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
764	1422360630	maaaaerk	Karpiza Mark	USER	RU	0	0	f	f	164	2026-05-01 14:46:26.628521+00	2026-05-01 14:46:34.530318+00	bbvlP7	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
341	7243330578	\N	Абрамкин А.П	USER	RU	0	0	f	f	\N	2026-04-20 14:23:03.523768+00	2026-04-20 14:23:03.523768+00	bjpAeU	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
400	7288951735	exuzehqpzwo1	oxxxqp	USER	RU	0	0	f	f	\N	2026-04-20 14:23:04.838387+00	2026-04-20 14:23:04.838387+00	VI7KnS	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
460	7310233717	\N	Николай Кузнецов	USER	RU	0	0	f	f	\N	2026-04-20 14:23:06.533914+00	2026-04-20 14:23:06.533914+00	hZ5Kpy	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
518	7494052497	\N	ТЕНЬ	USER	RU	0	0	f	f	\N	2026-04-20 14:23:08.52759+00	2026-04-20 14:23:08.52759+00	X5RFpx	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
342	7261834773	kbychokhikhyf2	Anatoliy	USER	RU	0	0	f	f	\N	2026-04-20 14:23:03.607045+00	2026-04-20 14:23:03.607045+00	banXN2	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
401	7422936014	\N	Николай Воронцов	USER	RU	0	0	f	f	\N	2026-04-20 14:23:04.891995+00	2026-04-20 14:23:04.891995+00	g8iJ50	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
459	7308801729	\N	Андрей Ипполитов	USER	RU	0	0	f	f	\N	2026-04-20 14:23:06.533717+00	2026-04-20 14:23:06.533717+00	QaTtFM	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
519	7020983929	akcboshodxgn3	A	USER	RU	0	0	f	f	\N	2026-04-20 14:23:08.528224+00	2026-04-20 14:23:08.528224+00	baMvck	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
767	5960998575	\N	.	USER	RU	0	0	f	f	167	2026-05-01 17:15:20.376169+00	2026-05-01 17:15:24.343203+00	0ZAE10	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
766	5317462197	A580BB181	Даниил Аброщенков	USER	RU	0	0	f	t	166	2026-05-01 16:47:22.9789+00	2026-05-03 17:37:57.13405+00	CL5tfJ	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
343	7256246595	\N	Anastasiya	USER	RU	0	0	f	f	\N	2026-04-20 14:23:03.650364+00	2026-04-20 14:23:03.650364+00	b0CNUf	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
402	7373852535	\N	Поддержка Яндекс Такси	USER	RU	0	0	f	f	\N	2026-04-20 14:23:04.925621+00	2026-04-20 14:23:04.925621+00	brhlym	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
461	6733784728	\N	Зарипов Айрат	USER	RU	0	0	f	f	\N	2026-04-20 14:23:06.540169+00	2026-04-20 14:23:06.540169+00	B5CK91	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
520	7243499323	\N	Лариса Калинченко	USER	RU	0	0	f	f	\N	2026-04-20 14:23:08.531052+00	2026-04-20 14:23:08.531052+00	BG59zL	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
768	5337995620	Lantana03	5337995620	USER	RU	0	0	f	t	\N	2026-05-01 17:52:40.437069+00	2026-05-01 17:54:59.332887+00	bf8Z2y	0	t	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
344	6824852392	\N	Анна Елагина	USER	RU	0	0	f	f	\N	2026-04-20 14:23:03.679178+00	2026-04-20 14:23:03.679178+00	YxNxDt	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
403	7012629137	dsholbbedof4	Ira	USER	RU	0	0	f	f	\N	2026-04-20 14:23:04.93619+00	2026-04-20 14:23:04.93619+00	KasJjM	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
462	7289375783	\N	Дмитрий Сидякин	USER	RU	0	0	f	f	\N	2026-04-20 14:23:06.658963+00	2026-04-20 14:23:06.658963+00	kGx4Ve	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
521	7419850022	ufjzblxchupi1	Dappaaaa	USER	RU	0	0	f	f	\N	2026-04-20 14:23:08.679566+00	2026-04-20 14:23:08.679566+00	O8fVgQ	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
769	709558403	Andrelebedew	KitKat Skat	USER	RU	0	0	f	f	168	2026-05-01 18:13:08.29049+00	2026-05-01 18:13:25.70094+00	bdD0ys	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
345	1733848029	\N	Грищук Ирина	USER	RU	0	0	f	f	\N	2026-04-20 14:23:03.699489+00	2026-04-20 14:23:03.699489+00	Ap0ExD	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
404	7492588621	\N	Михаил Рыбников	USER	RU	0	0	f	f	\N	2026-04-20 14:23:04.979248+00	2026-04-20 14:23:04.979248+00	c2SeBU	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
463	7398894464	nlaztqthgnswr9	Dina	USER	RU	0	0	f	f	\N	2026-04-20 14:23:06.659251+00	2026-04-20 14:23:06.659251+00	bfF4sb	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
522	7366857168	akhchveqldunb5	Chush	USER	RU	0	0	f	f	\N	2026-04-20 14:23:08.679847+00	2026-04-20 14:23:08.679847+00	bc76NW	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
770	352528406	\N	Alexx Lenin	USER	RU	0	0	f	f	\N	2026-05-01 18:57:55.497121+00	2026-05-01 18:57:58.275009+00	oAZSbA	0	t	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
346	7499812563	\N	Панков Олег	USER	RU	0	0	f	f	\N	2026-04-20 14:23:03.73656+00	2026-04-20 14:23:03.73656+00	pwEF7T	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
405	7427086431	\N	Воронцов Виктор	USER	RU	0	0	f	f	\N	2026-04-20 14:23:05.008414+00	2026-04-20 14:23:05.008414+00	qmJnNF	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
464	6992993264	\N	Вячеслав Ефанов	USER	RU	0	0	f	f	\N	2026-04-20 14:23:06.666634+00	2026-04-20 14:23:06.666634+00	13gx9E	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
523	6798530185	\N	Додо пицца	USER	RU	0	0	f	f	\N	2026-04-20 14:23:08.681954+00	2026-04-20 14:23:08.681954+00	bl2Z5o	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
771	1345408323	\N	Николай	USER	RU	0	0	f	f	\N	2026-05-01 19:25:12.791501+00	2026-05-01 19:25:33.966544+00	nyc2ME	0	t	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
772	5029805473	bezdar_8	bezdar	USER	RU	0	0	f	f	\N	2026-05-01 19:51:59.498304+00	2026-05-01 19:52:01.36423+00	hB3ZWY	0	t	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
347	7437049904	bzhizobyru7	Миха	USER	RU	0	0	f	f	\N	2026-04-20 14:23:03.753148+00	2026-04-20 14:23:03.753148+00	W1kO1U	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
406	7072122551	\N	Перфилов Игорь	USER	RU	0	0	f	f	\N	2026-04-20 14:23:05.028361+00	2026-04-20 14:23:05.028361+00	lCULNq	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
465	7309536805	\N	Виктор Кажанов	USER	RU	0	0	f	f	\N	2026-04-20 14:23:06.749123+00	2026-04-20 14:23:06.749123+00	bplPz7	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
524	7056083171	MaryanaAhmatova	Марьяна Ахматова	USER	RU	0	0	f	f	\N	2026-04-20 14:23:08.691364+00	2026-04-20 14:23:08.691364+00	edfOAb	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
773	5313599796	\N	Максим	USER	RU	0	0	f	f	169	2026-05-01 20:09:30.033885+00	2026-05-04 08:57:41.191789+00	c764Vo	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
349	7243825400	\N	Дарья Синицына	USER	RU	0	0	f	f	\N	2026-04-20 14:23:03.781442+00	2026-04-20 14:23:03.781442+00	Ayp5ao	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
408	7280187785	\N	Востротин Александр	USER	RU	0	0	f	f	\N	2026-04-20 14:23:05.062917+00	2026-04-20 14:23:05.062917+00	bfXzd1	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
467	6853150279	ishhdashshzhyvf5	Дамир Black Box	USER	RU	0	0	f	f	\N	2026-04-20 14:23:06.77783+00	2026-04-20 14:23:06.77783+00	Oj6kAm	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
774	8469159321	Gogolmogolin	Саня	USER	RU	0	0	f	f	170	2026-05-01 20:50:12.442878+00	2026-05-01 20:50:15.90511+00	A5qLhH	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
350	7421741513	ArtemKhachatryal	Артём Хачатрян	USER	RU	0	0	f	f	\N	2026-04-20 14:23:03.786811+00	2026-04-20 14:23:03.786811+00	bkTncV	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
409	6673900884	\N	Александр	USER	RU	0	0	f	f	\N	2026-04-20 14:23:05.084113+00	2026-04-20 14:23:05.084113+00	mmTZmw	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
468	7382148216	\N	Макаров Николай	USER	RU	0	0	f	f	\N	2026-04-20 14:23:06.842096+00	2026-04-20 14:23:06.842096+00	KTOvJK	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
775	1105671913	\N	Эльнара	USER	RU	0	0	f	f	\N	2026-05-02 00:55:35.386476+00	2026-05-02 00:55:40.651198+00	JWo9qm	0	t	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
352	7300324897	\N	Олег Хархан	USER	RU	0	0	f	f	\N	2026-04-20 14:23:03.86475+00	2026-04-20 14:23:03.86475+00	2eJYOZ	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
411	7279155897	\N	Романова Татьяна	USER	RU	0	0	f	f	\N	2026-04-20 14:23:05.141153+00	2026-04-20 14:23:05.141153+00	bcz6tZ	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
470	7224855820	shktkhjzhpdzh3	Zakir	USER	RU	0	0	f	f	\N	2026-04-20 14:23:06.894088+00	2026-04-20 14:23:06.894088+00	AQLgo1	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
776	5445379994	nameless10463835	Nameless	USER	RU	0	0	f	t	171	2026-05-02 05:08:43.354428+00	2026-05-03 08:52:03.272385+00	F3oWxF	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
353	7248915665	txilbshaplq5	Chush	USER	RU	0	0	f	f	\N	2026-04-20 14:23:03.885334+00	2026-04-20 14:23:03.885334+00	M5eyKL	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
412	6937459770	\N	Фатима Ухажова	USER	RU	0	0	f	f	\N	2026-04-20 14:23:05.159655+00	2026-04-20 14:23:05.159655+00	Ho0748	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
471	6976190975	\N	Ирлица Леонид	USER	RU	0	0	f	f	\N	2026-04-20 14:23:06.961095+00	2026-04-20 14:23:06.961095+00	OPz0Mm	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
777	1028687205	Zhurav1ev88	Zhurav1ev	USER	RU	0	0	f	f	172	2026-05-02 05:38:31.0968+00	2026-05-02 05:38:43.59997+00	blNr1U	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
354	6751043630	\N	Полина Шумова	USER	RU	0	0	f	f	\N	2026-04-20 14:23:03.952029+00	2026-04-20 14:23:03.952029+00	eecGW2	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
413	7158831461	\N	Александр Алиев	USER	RU	0	0	f	f	\N	2026-04-20 14:23:05.208864+00	2026-04-20 14:23:05.208864+00	mTJDOq	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
472	7335363341	ipfthykorithyj2	Ilya	USER	RU	0	0	f	f	\N	2026-04-20 14:23:06.962433+00	2026-04-20 14:23:06.962433+00	bqFuwZ	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
778	5389963337	kirieshka404XD	kииешkаム чоч	USER	RU	0	0	f	f	173	2026-05-02 07:10:05.76617+00	2026-05-02 07:10:14.945288+00	SYCZ4E	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
355	7290974807	\N	Томилин Алексей Николаевич	USER	RU	0	0	f	f	\N	2026-04-20 14:23:03.978082+00	2026-04-20 14:23:03.978082+00	bkZ8es	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
414	7135579755	\N	Горбунов Александр	USER	RU	0	0	f	f	\N	2026-04-20 14:23:05.238531+00	2026-04-20 14:23:05.238531+00	blNMHq	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
473	7361827579	\N	Алексей Трухов	USER	RU	0	0	f	f	\N	2026-04-20 14:23:06.974367+00	2026-04-20 14:23:06.974367+00	NeZ5OS	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
779	6509123418	\N	Gehrman Sparrow	USER	RU	0	0	f	t	\N	2026-05-02 09:02:28.327787+00	2026-05-02 09:02:53.218131+00	qO08IF	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
360	7293495542	\N	Наталья Орловская	USER	RU	0	0	f	f	\N	2026-04-20 14:23:04.055229+00	2026-04-20 14:23:04.055229+00	OlWfXq	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
419	6315175943	\N	Приступа Татьяна	USER	RU	0	0	f	f	\N	2026-04-20 14:23:05.325648+00	2026-04-20 14:23:05.325648+00	tqtSLj	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
478	7283104880	khnytupewi8	Рем	USER	RU	0	0	f	f	\N	2026-04-20 14:23:07.134644+00	2026-04-20 14:23:07.134644+00	qX8fJJ	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
780	454283996	Lucky_SL23	Lucky	USER	RU	0	0	f	f	\N	2026-05-02 09:03:16.329953+00	2026-05-02 09:03:16.329953+00	4r2sWB	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
375	7427274222	\N	Харченко Владимир Федорович	USER	RU	0	0	f	f	\N	2026-04-20 14:23:04.391239+00	2026-04-20 14:23:04.391239+00	29XkA2	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
434	7012594799	ydacmwjwth8	icon_finance_sale_TR	USER	RU	0	0	f	f	\N	2026-04-20 14:23:06.021957+00	2026-04-20 14:23:06.021957+00	bfLpYC	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
493	7445387747	\N	Вячеслав Латыпов	USER	RU	0	0	f	f	\N	2026-04-20 14:23:07.710306+00	2026-04-20 14:23:07.710306+00	bcqecO	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
781	6707485988	aaaoo9	ᅠᅠ	USER	RU	0	0	f	f	183	2026-05-02 10:29:57.053407+00	2026-05-03 06:59:55.295798+00	pPO2e0	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
378	6963760432	\N	Мальцев Дмитрий	USER	RU	0	0	f	f	\N	2026-04-20 14:23:04.409107+00	2026-04-20 14:23:04.409107+00	DID5gz	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
437	7245932268	\N	Екатерина Владимировна	USER	RU	0	0	f	f	\N	2026-04-20 14:23:06.026115+00	2026-04-20 14:23:06.026115+00	V8SxTq	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
496	7232242227	\N	Терентьев Сергей	USER	RU	0	0	f	f	\N	2026-04-20 14:23:07.839627+00	2026-04-20 14:23:07.839627+00	eF2sDv	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
379	7412173814	\N	Романова Татьяна	USER	RU	0	0	f	f	\N	2026-04-20 14:23:04.424052+00	2026-04-20 14:23:04.424052+00	yS4MU7	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
438	6676770295	\N	Сергей Федоров	USER	RU	0	0	f	f	\N	2026-04-20 14:23:06.105732+00	2026-04-20 14:23:06.105732+00	JH3pWG	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
497	7261246795	\N	Александр Агафонов	USER	RU	0	0	f	f	\N	2026-04-20 14:23:07.867497+00	2026-04-20 14:23:07.867497+00	z2n6bW	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
783	5552137646	Muhammed97x	Muhammed	USER	RU	0	0	f	f	176	2026-05-02 11:39:51.990652+00	2026-05-02 11:39:55.504642+00	AVko6k	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
380	6544143443	\N	Кычева Елена	USER	RU	0	0	f	f	\N	2026-04-20 14:23:04.44894+00	2026-04-20 14:23:04.44894+00	yZhaWB	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
439	6419629922	\N	Владимир Морозов	USER	RU	0	0	f	f	\N	2026-04-20 14:23:06.129307+00	2026-04-20 14:23:06.129307+00	t2gfDh	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
498	7361469081	\N	Владимир Чекалкин	USER	RU	0	0	f	f	\N	2026-04-20 14:23:07.939314+00	2026-04-20 14:23:07.939314+00	bdkIYz	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
784	8275047119	\N	Dasha sugar	USER	RU	0	0	f	f	177	2026-05-02 11:44:20.49436+00	2026-05-02 11:44:30.987161+00	Zahkpy	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
382	7264732300	\N	Алексей Кондрашкин	USER	RU	0	0	f	f	\N	2026-04-20 14:23:04.452187+00	2026-04-20 14:23:04.452187+00	sEO0B9	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
441	6897613313	\N	Владимир Викторович	USER	RU	0	0	f	f	\N	2026-04-20 14:23:06.165093+00	2026-04-20 14:23:06.165093+00	bgwbIB	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
499	7081094475	\N	Алексей Кононов	USER	RU	0	0	f	f	\N	2026-04-20 14:23:08.0557+00	2026-04-20 14:23:08.0557+00	tcTTrk	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
785	1221520522	\N	Юлия Тихонова	USER	RU	0	0	f	f	178	2026-05-02 14:34:04.681792+00	2026-05-02 14:34:53.587818+00	RFpPvf	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
384	7316858968	\N	Белан Сергей	USER	RU	0	0	f	f	\N	2026-04-20 14:23:04.470731+00	2026-04-20 14:23:04.470731+00	be4UD1	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
443	7442336632	\N	Максим Папушенко	USER	RU	0	0	f	f	\N	2026-04-20 14:23:06.174908+00	2026-04-20 14:23:06.174908+00	DtXfGs	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
502	7429463934	\N	Александр Олифиренко	USER	RU	0	0	f	f	\N	2026-04-20 14:23:08.09578+00	2026-04-20 14:23:08.09578+00	bf2Fok	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
526	7329338730	ovFrcgKC	Jarvelbyok Hottobsowerrds	USER	RU	0	0	f	f	\N	2026-04-20 14:28:08.898708+00	2026-04-20 14:28:08.898708+00	HE2sPu	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
527	7854702179	Nikita22kripto	Nikita	USER	RU	0	0	f	f	\N	2026-04-20 14:28:08.932182+00	2026-04-20 14:28:08.932182+00	bTUF7f	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
528	5426883646	\N	Frunze Navoyan	USER	RU	0	0	f	f	\N	2026-04-20 14:28:10.756261+00	2026-04-20 14:28:10.756261+00	xpSMY1	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
529	8009219593	Kozninyh	Аня	USER	RU	0	0	f	f	\N	2026-04-20 14:28:13.326144+00	2026-04-20 14:28:13.326144+00	wLlPqn	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
530	8516357412	Yurix_Teor1a	Сергей Перепечёнов	USER	RU	0	0	f	f	\N	2026-04-20 14:28:14.038618+00	2026-04-20 14:28:14.038618+00	zBLWiU	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
531	7807708092	AnastasiaPrudnik0va91	Анастасия	USER	RU	0	0	f	f	\N	2026-04-20 14:28:14.089802+00	2026-04-20 14:28:14.089802+00	bbX4vW	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
532	8000780567	mar1atriers	Мария Триерс Психолог	USER	RU	0	0	f	f	\N	2026-04-20 14:28:14.12711+00	2026-04-20 14:28:14.12711+00	HnB7uP	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
533	8355295916	baskakov599589	Павел Баскаков	USER	RU	0	0	f	f	\N	2026-04-20 14:28:16.348244+00	2026-04-20 14:28:16.348244+00	OSFFtB	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
534	5829264272	\N	Катерина	USER	RU	0	0	f	f	41	2026-04-20 16:55:13.455186+00	2026-04-20 16:55:21.163068+00	SBysCt	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
535	7467672955	karakulovkirill41390	Kirill	USER	RU	0	0	f	f	\N	2026-04-20 19:39:27.102834+00	2026-04-20 19:39:27.102834+00	UuJSII	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
536	7250005250	dashunya_krae372	Dashunya Kraeva	USER	RU	0	0	f	f	\N	2026-04-20 19:39:27.215921+00	2026-04-20 19:39:27.215921+00	19s69y	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
537	6461777900	lu_den53447	Den	USER	RU	0	0	f	f	\N	2026-04-20 19:39:27.400544+00	2026-04-20 19:39:27.400544+00	2gmbYk	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
538	7983414106	so_maksimka73	Maksimka	USER	RU	0	0	f	f	\N	2026-04-20 19:39:27.402472+00	2026-04-20 19:39:27.402472+00	p2RvyW	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
539	6706211091	dhramchenkova921	Dashulya	USER	RU	0	0	f	f	\N	2026-04-20 19:39:27.504757+00	2026-04-20 19:39:27.504757+00	NyLfzU	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
540	6433762255	al_borovkova25984	Alishka	USER	RU	0	0	f	f	\N	2026-04-20 19:39:27.383122+00	2026-04-20 19:39:27.383122+00	bu02HN	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
541	8491023535	dima_mo2068	Dima Moshonkin	USER	RU	0	0	f	f	\N	2026-04-20 19:39:27.599936+00	2026-04-20 19:39:27.599936+00	4iUyy1	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
542	7121154402	pe_lus3752	Lusine	USER	RU	0	0	f	f	\N	2026-04-20 19:39:27.50615+00	2026-04-20 19:39:27.50615+00	vYIkkh	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
543	6885513166	burov_dim29	Dimko	USER	RU	0	0	f	f	\N	2026-04-20 19:39:27.599646+00	2026-04-20 19:39:27.599646+00	yTJxPf	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
544	7516765087	elismihaleva723	Elis	USER	RU	0	0	f	f	\N	2026-04-20 19:39:27.656988+00	2026-04-20 19:39:27.656988+00	bm3iDA	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
545	8140161679	romka_gi22920	Romka Girin	USER	RU	0	0	f	f	\N	2026-04-20 19:39:27.67809+00	2026-04-20 19:39:27.67809+00	bqEIeM	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
546	8171678958	lesha_stoyanov46901	Lesha Stoyanov	USER	RU	0	0	f	f	\N	2026-04-20 19:39:27.70193+00	2026-04-20 19:39:27.70193+00	MRN02j	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
547	7848871738	skvorcova_kri11394	Kristyushka	USER	RU	0	0	f	f	\N	2026-04-20 19:39:27.779976+00	2026-04-20 19:39:27.779976+00	carwPQ	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
548	7046491058	tokarevva31	Vadik Tokarev	USER	RU	0	0	f	f	\N	2026-04-20 19:39:27.918188+00	2026-04-20 19:39:27.918188+00	baa7np	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
549	7336674839	vl_deni24223	Vlada	USER	RU	0	0	f	f	\N	2026-04-20 19:39:27.97285+00	2026-04-20 19:39:27.97285+00	P89hug	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
550	7734412686	leo_tk486e	Leo Tkachev	USER	RU	0	0	f	f	\N	2026-04-20 19:39:27.973113+00	2026-04-20 19:39:27.973113+00	1yxXHz	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
551	7040106645	pop_amaliya91	Amaliya	USER	RU	0	0	f	f	\N	2026-04-20 19:39:27.986262+00	2026-04-20 19:39:27.986262+00	sjive5	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
552	8151044917	lip_egor37446	Egor	USER	RU	0	0	f	f	\N	2026-04-20 19:39:28.038129+00	2026-04-20 19:39:28.038129+00	broTGh	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
553	7598472648	lozdanil13418	Danil	USER	RU	0	0	f	f	\N	2026-04-20 19:39:28.038611+00	2026-04-20 19:39:28.038611+00	QySub6	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
554	7153167875	roman_putin76375	Roman	USER	RU	0	0	f	f	\N	2026-04-20 19:39:28.139941+00	2026-04-20 19:39:28.139941+00	ba4cru	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
555	7282296280	vla_kary14015	Vlada Karyakina	USER	RU	0	0	f	f	\N	2026-04-20 19:39:28.140275+00	2026-04-20 19:39:28.140275+00	iy6xeT	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
556	7080463218	bog_guba6988	Bogdan	USER	RU	0	0	f	f	\N	2026-04-20 19:39:28.150666+00	2026-04-20 19:39:28.150666+00	L7oVP4	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
557	8376046597	al_sam6705	Alya Samokhina	USER	RU	0	0	f	f	\N	2026-04-20 19:39:28.169937+00	2026-04-20 19:39:28.169937+00	bjKUy6	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
558	7164256686	udalova_dana834	Dana Udalova	USER	RU	0	0	f	f	\N	2026-04-20 19:39:28.233944+00	2026-04-20 19:39:28.233944+00	RfjcGc	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
559	8084408762	merk_lenok475	Lenok	USER	RU	0	0	f	f	\N	2026-04-20 19:39:28.253783+00	2026-04-20 19:39:28.253783+00	27Yj1L	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
560	7177394111	fed_katyushka785	Katyushka Fedotova	USER	RU	0	0	f	f	\N	2026-04-20 19:39:28.379856+00	2026-04-20 19:39:28.379856+00	b4JR0u	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
561	7149529652	boc_serezha379	Seryozha	USER	RU	0	0	f	f	\N	2026-04-20 19:39:28.436672+00	2026-04-20 19:39:28.436672+00	4lLcZi	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
562	7933045332	sla_rya58592	Sladkaya Ryabtseva	USER	RU	0	0	f	f	\N	2026-04-20 19:39:28.491948+00	2026-04-20 19:39:28.491948+00	bdD0Tb	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
563	6684017436	ermoa96391	Askar	USER	RU	0	0	f	f	\N	2026-04-20 19:39:28.625706+00	2026-04-20 19:39:28.625706+00	tgDHTr	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
564	8254035931	nurlan_pet53790	Nurlan	USER	RU	0	0	f	f	\N	2026-04-20 19:39:28.692072+00	2026-04-20 19:39:28.692072+00	CZAdyr	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
565	6502292993	sadreginka6003	Reginka	USER	RU	0	0	f	f	\N	2026-04-20 19:39:28.692566+00	2026-04-20 19:39:28.692566+00	Annsaf	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
566	7293674242	y_vin5953r	Yurets	USER	RU	0	0	f	f	\N	2026-04-20 19:39:28.743974+00	2026-04-20 19:39:28.743974+00	bncVWC	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
567	6963098061	tosha_leskov65726	Tosha	USER	RU	0	0	f	f	\N	2026-04-20 19:39:28.744839+00	2026-04-20 19:39:28.744839+00	jhBhvE	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
568	6831880540	glebovayuliya82	Yuliya	USER	RU	0	0	f	f	\N	2026-04-20 19:39:28.78266+00	2026-04-20 19:39:28.78266+00	ucxMpy	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
569	8571110267	to_ple14ty	Tonya	USER	RU	0	0	f	f	\N	2026-04-20 19:39:28.844347+00	2026-04-20 19:39:28.844347+00	PbG7qz	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
570	7983605104	lotfullina_fa92420	Faina	USER	RU	0	0	f	f	\N	2026-04-20 19:39:28.894801+00	2026-04-20 19:39:28.894801+00	Xx5LUU	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
571	7298974125	yam32imkoy	Miron	USER	RU	0	0	f	f	\N	2026-04-20 19:39:28.999882+00	2026-04-20 19:39:28.999882+00	27eh79	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
572	7053514879	silaevato69956	Toma	USER	RU	0	0	f	f	\N	2026-04-20 19:39:29.208868+00	2026-04-20 19:39:29.208868+00	bgKcVq	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
573	7242206399	rozalina_el36	Rozalina	USER	RU	0	0	f	f	\N	2026-04-20 19:39:29.230679+00	2026-04-20 19:39:29.230679+00	M2XucQ	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
574	7054013745	kas_katerina131	Katerina Kasatkina	USER	RU	0	0	f	f	\N	2026-04-20 19:39:29.299671+00	2026-04-20 19:39:29.299671+00	o5b1cj	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
575	7030287724	ko_liliana18513	Liliana	USER	RU	0	0	f	f	\N	2026-04-20 19:39:30.905189+00	2026-04-20 19:39:30.905189+00	ALSEB0	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
576	7001124531	sadz_anr940	Igor Lebedev	USER	RU	0	0	f	f	\N	2026-04-20 19:39:31.301663+00	2026-04-20 19:39:31.301663+00	okKDx9	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
577	8373230461	valiullina_flyuza472	Flyuza	USER	RU	0	0	f	f	\N	2026-04-20 19:39:38.834889+00	2026-04-20 19:39:38.834889+00	nT1u04	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
578	7192492417	barminvo46	Vovka	USER	RU	0	0	f	f	\N	2026-04-20 19:39:38.836509+00	2026-04-20 19:39:38.836509+00	66YJyS	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
579	5117923037	osin_alisher50	Alisher	USER	RU	0	0	f	f	\N	2026-04-20 19:39:40.012255+00	2026-04-20 19:39:40.012255+00	s7Z2Fp	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
580	7195029425	mi_muhamadieva512	Milya	USER	RU	0	0	f	f	\N	2026-04-20 19:39:40.045254+00	2026-04-20 19:39:40.045254+00	bibcOB	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
581	7018221713	glazkovaalinka25960	Alinka Glazkova	USER	RU	0	0	f	f	\N	2026-04-20 19:39:40.798805+00	2026-04-20 19:39:40.798805+00	bpfhpp	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
786	6408197699	iloveyoyul	find	USER	RU	0	0	f	f	180	2026-05-02 16:28:24.144584+00	2026-05-02 16:28:33.5398+00	brz2Bs	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
582	7091331892	a_gap58rtg	Artem	USER	RU	0	0	f	f	\N	2026-04-20 19:39:42.86687+00	2026-04-20 19:39:42.86687+00	GMiOAu	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
787	6588223613	aa_aaa_01	6588223613	USER	RU	0	0	f	f	181	2026-05-02 16:51:24.11706+00	2026-05-02 16:51:27.153155+00	ic6Av9	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
583	8498235621	guto_sne763	Snezhana	USER	RU	0	0	f	f	\N	2026-04-20 19:39:42.968666+00	2026-04-20 19:39:42.968666+00	FB06w6	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
788	8107450501	Zx_485	حماده	USER	RU	0	0	f	f	\N	2026-05-03 01:05:40.909876+00	2026-05-03 01:06:12.321003+00	lL6bAW	0	t	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
584	8162704132	shindina_yas46679	Yasmina	USER	RU	0	0	f	f	\N	2026-04-20 19:39:46.32416+00	2026-04-20 19:39:46.32416+00	oYoEEQ	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
585	8162181674	OnlipaySupport2	Виолетта Onlipay	USER	RU	0	0	f	t	\N	2026-04-21 02:13:08.117731+00	2026-04-21 02:16:51.407719+00	bkmn8A	0	t	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
600	7800678139	Kaw1d_666	ᅠᅠᅠᅠᅠ	USER	RU	0	0	f	f	56	2026-04-24 17:10:54.594666+00	2026-04-24 17:11:00.89147+00	3xo9SK	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
591	7672696820	Aleks39V	Aleks	USER	RU	0	0	f	f	140	2026-04-23 06:35:13.20173+00	2026-04-29 11:06:24.623775+00	zDATpX	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
588	1350241293	\N	Николай Эсипов	USER	RU	0	0	f	f	44	2026-04-21 18:16:17.623756+00	2026-04-21 18:18:38.414941+00	wKOQ2e	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
602	916452371	\N	Наталья Орлова	USER	RU	0	0	f	f	\N	2026-04-24 20:19:39.58245+00	2026-04-24 20:19:43.571274+00	I2pK1o	0	t	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
589	7855055693	Moderator242	Moderator	USER	RU	0	0	f	f	45	2026-04-22 07:23:10.384176+00	2026-04-22 07:59:45.788583+00	voRTBo	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
590	8282971952	\N	Gulnura Muhamedali	USER	RU	0	0	f	f	48	2026-04-22 12:36:50.086623+00	2026-04-22 12:37:14.826877+00	ldGsqh	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
605	6307415263	\N	Anna	USER	RU	0	0	f	f	\N	2026-04-24 20:39:58.949072+00	2026-04-24 20:39:58.949072+00	plbxGU	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
606	527518219	qe_mist	Егор	USER	RU	0	0	f	f	\N	2026-04-24 20:41:15.029614+00	2026-04-24 20:41:17.135022+00	huZXWO	0	t	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
592	1091125294	poluxzzv	poly	USER	RU	0	0	f	f	49	2026-04-23 10:33:43.405312+00	2026-04-23 10:33:49.434343+00	eLCzip	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
607	6765325326	shhpavel	Pavel	USER	RU	0	0	f	f	\N	2026-04-24 20:55:23.229599+00	2026-04-24 20:55:59.960061+00	YYHw24	0	t	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
599	7394523714	lie_must_die	red flag	USER	RU	0	0	f	t	\N	2026-04-24 17:07:58.967184+00	2026-04-24 21:02:55.993266+00	OrIFcP	0	t	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
594	5579251958	snk50ms	jv.k8𐤀	USER	RU	0	0	f	f	\N	2026-04-23 10:50:58.015185+00	2026-04-23 10:50:58.047863+00	brkFQn	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
595	1069618544	kskswz	ксеньчик	USER	RU	0	0	f	f	\N	2026-04-23 11:37:29.812404+00	2026-04-23 11:37:31.415215+00	bn3WeD	0	t	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
601	474089002	vedmochka_1319	Vedmochka	USER	RU	0	0	f	t	57	2026-04-24 20:18:25.137535+00	2026-04-27 20:21:41.58683+00	UcezpZ	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
789	7974183527	\N	.	USER	RU	0	0	f	f	\N	2026-05-03 02:22:56.910175+00	2026-05-03 02:22:58.458219+00	bmMRAj	0	t	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
596	8385366235	Arboretum18k_YT	Arboretum18k	USER	RU	0	0	f	f	53	2026-04-24 05:41:15.332927+00	2026-04-24 05:41:21.355216+00	bfzsib	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
603	1283310992	TamaraZotova	Тамара Зотова	USER	RU	0	0	f	f	213	2026-04-24 20:27:27.947309+00	2026-05-11 18:37:23.494156+00	O9HusT	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
608	2088580170	\N	Александр Юсупов	USER	RU	0	0	f	f	217	2026-04-24 20:58:17.738594+00	2026-05-13 12:38:18.251071+00	6FcmyU	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
597	1500199751	Mutenshtain	Daimons	USER	RU	0	0	f	f	54	2026-04-24 09:25:21.720623+00	2026-04-24 09:28:20.913059+00	beEyhN	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
598	1673513385	VioMaxi	Виктория	USER	RU	0	0	f	f	\N	2026-04-24 10:21:12.957592+00	2026-04-24 10:21:17.119104+00	IPred6	0	t	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
609	1126913612	ermolin_max	Mакс	USER	RU	0	0	f	f	58	2026-04-24 21:07:24.723033+00	2026-04-24 21:07:33.354956+00	Sjz0Rk	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
611	6330812062	\N	Алтай	USER	RU	0	0	f	f	60	2026-04-24 21:30:33.153102+00	2026-04-24 21:31:53.887842+00	WXVFlr	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
612	7604284279	onecarats	7604284279	USER	RU	0	0	f	f	61	2026-04-24 21:47:29.824889+00	2026-04-24 21:48:18.329318+00	bp9aV8	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
613	7490558524	korojlb_1	Крыш	USER	RU	0	0	f	t	62	2026-04-24 22:18:00.917223+00	2026-04-24 22:19:44.979958+00	QHVGL0	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
614	1337990151	Sashafrolove	Jimmy Osborne	USER	RU	0	0	f	f	\N	2026-04-25 01:50:03.63634+00	2026-04-25 01:50:03.63634+00	j66Zm7	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
593	1828274009	jk7kkkk	lina	USER	RU	0	0	f	f	245	2026-04-23 10:35:42.558666+00	2026-05-24 11:38:11.015281+00	bhNwFI	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
604	1391604133	aldoshin_ae	Александр Алдошин	USER	RU	0	0	f	t	\N	2026-04-24 20:35:08.32649+00	2026-06-23 20:45:03.527434+00	u2Jo7d	0	t	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
615	494365884	\N	Никита	USER	RU	0	0	f	f	\N	2026-04-25 02:21:43.702967+00	2026-04-25 02:22:42.380537+00	EUvxLJ	0	t	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
618	780723842	lip4sip	SWIFT	USER	RU	0	0	f	f	\N	2026-04-25 03:25:52.883332+00	2026-04-25 03:25:56.029828+00	rZ5B7n	0	t	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
620	5164550236	\N	VaHanch	USER	RU	0	0	f	f	\N	2026-04-25 04:58:30.148094+00	2026-04-25 04:58:30.148094+00	5MAgx3	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
621	509319013	molova_yana	Яна Молова	USER	RU	0	0	f	f	64	2026-04-25 05:18:27.317611+00	2026-04-25 05:18:35.466681+00	kbEPl0	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
622	795774629	barinAK4444	Алексей Казаков	USER	RU	0	0	f	t	\N	2026-04-25 05:19:38.598128+00	2026-04-25 05:20:23.112981+00	beM6vC	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
623	5566793783	MaksimB071	Максим	USER	RU	0	0	f	f	\N	2026-04-25 05:51:26.163556+00	2026-04-25 05:51:30.101038+00	xxHDZo	0	t	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
624	1192575129	msveeeq	софья	USER	RU	0	0	f	t	\N	2026-04-25 06:10:48.952735+00	2026-04-25 06:11:07.986419+00	EVHjtx	0	t	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
625	628021852	Dimka3232	Дима Корнилов	USER	RU	0	0	f	f	\N	2026-04-25 06:11:54.189596+00	2026-04-25 06:11:59.904141+00	zwmiSy	0	t	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
626	7634526866	\N	V P	USER	RU	0	0	f	t	\N	2026-04-25 06:40:40.045153+00	2026-04-25 06:40:45.86856+00	br4uCm	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
627	5403644730	\N	Татьяна	USER	RU	0	0	f	f	66	2026-04-25 07:01:08.8838+00	2026-04-25 07:02:29.470948+00	H9MsAf	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
629	761481167	zajimerr	zajimer	USER	RU	0	0	f	f	68	2026-04-25 07:18:22.707904+00	2026-04-25 07:18:26.986637+00	t8lb5l	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
630	255376395	cccp81	AW	USER	RU	0	0	f	f	69	2026-04-25 07:29:34.881144+00	2026-04-25 07:31:24.079612+00	lg8EMi	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
631	7360577294	Gz62283	Кто-то	USER	RU	0	0	f	f	\N	2026-04-25 07:33:41.972515+00	2026-04-25 07:33:46.260331+00	VLilB8	0	t	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
632	27408918	myawesomenick	Павел	USER	RU	0	0	f	t	\N	2026-04-25 07:44:19.196868+00	2026-04-25 07:44:38.68604+00	k8xCkF	0	t	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
633	485045145	ungreen	Павел	USER	RU	0	0	f	f	70	2026-04-25 08:01:25.616958+00	2026-04-25 08:01:55.443661+00	kLTqcj	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
640	1289864167	Rogue52ru	Павел К	USER	RU	0	0	f	t	199	2026-04-25 10:06:57.199451+00	2026-05-05 18:20:48.606591+00	tmqHoA	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
634	8517090474	ggg_fynn	𒁇𒐕𒐏𒀼𒐖𒆸𒐞	USER	RU	0	0	f	t	71	2026-04-25 08:03:59.231751+00	2026-04-25 08:04:40.242071+00	bcTzJ6	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
635	6268271665	\N	Yuri	USER	RU	0	0	f	f	72	2026-04-25 08:05:22.431306+00	2026-04-25 08:05:35.374046+00	QyXH6J	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
636	5019945972	dmn_170	dmn_170	USER	RU	0	0	f	t	\N	2026-04-25 08:07:58.916108+00	2026-04-25 08:08:09.694538+00	jSvDuc	0	t	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
637	5192559473	\N	Юляшка	USER	RU	0	0	f	f	\N	2026-04-25 08:31:43.419628+00	2026-04-25 08:31:43.419628+00	bpz0nT	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
638	480670330	\N	Serega	USER	RU	0	0	f	t	\N	2026-04-25 09:49:50.547257+00	2026-04-25 09:50:51.798053+00	wRxlou	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
639	8241602716	\N	.	USER	RU	0	0	f	f	\N	2026-04-25 09:53:23.896995+00	2026-04-25 09:53:23.896995+00	beehpm	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
641	540695260	Tsybah	VLd	USER	RU	0	0	f	t	73	2026-04-25 10:08:11.187689+00	2026-04-25 10:09:14.134642+00	ne4weo	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
642	6820158858	Istorik56	Prosto	USER	RU	0	0	f	t	74	2026-04-25 10:19:58.17986+00	2026-04-25 10:20:42.510182+00	X5AUsh	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
617	860312541	n11011952	ната хилько	USER	RU	0	0	f	t	65	2026-04-25 03:07:52.907158+00	2026-04-25 10:34:04.640012+00	IVFLm0	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
643	281014544	sensorika19	Наталья Sensorika	USER	RU	0	0	f	f	\N	2026-04-25 10:34:18.251812+00	2026-04-25 10:34:41.45827+00	be3WnK	0	t	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
644	5742548647	rTmzucchini	Olga	USER	RU	0	0	f	f	75	2026-04-25 10:46:17.240371+00	2026-04-25 10:46:41.65692+00	RUwhnb	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
645	7810685909	Angell_Falllen	Fallen Angel	USER	RU	0	0	f	t	76	2026-04-25 11:05:05.302394+00	2026-04-25 11:05:20.40315+00	Z5THLA	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
616	6629717496	\N	Дмитрий	USER	RU	0	0	f	t	77	2026-04-25 02:58:41.089178+00	2026-04-25 12:11:59.222172+00	Lj3yUG	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
647	6249311845	\N	Евгения	USER	RU	0	0	f	t	\N	2026-04-25 12:12:18.792389+00	2026-04-25 12:12:49.135985+00	RQxeOK	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
648	810347542	ROman_tobeCool	Rom	USER	RU	0	0	f	t	\N	2026-04-25 12:14:07.467894+00	2026-04-25 12:16:49.781897+00	NdiOAt	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
650	6411014685	Ecs79	Ecstasy	USER	RU	0	0	f	f	\N	2026-04-25 12:42:31.293155+00	2026-04-25 12:42:33.125457+00	FtJL4q	0	t	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
651	320231603	Anasteisha1472	Анастасия Тамарова	USER	RU	0	0	f	f	79	2026-04-25 12:46:15.299676+00	2026-04-25 12:46:22.772888+00	xZr7iL	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
655	700676133	qwa123321	qwa123	USER	RU	0	0	f	t	81	2026-04-25 14:18:34.502565+00	2026-05-18 08:30:21.276633+00	bbV0MX	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
652	7350620147	stalo_pohuy	Артём	USER	RU	0	0	f	f	\N	2026-04-25 12:46:21.143196+00	2026-04-25 12:46:23.675897+00	8aPQc6	0	t	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
653	887017110	\N	М...	USER	RU	0	0	f	f	\N	2026-04-25 13:08:03.225033+00	2026-04-25 13:08:05.014544+00	lrOyEE	0	t	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
654	7755964210	Islm1k	ISLAM1K	USER	RU	0	0	f	f	80	2026-04-25 13:24:10.930515+00	2026-04-25 13:24:16.144566+00	Q29yeN	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
656	6256454832	\N	ᅠ	USER	RU	0	0	f	t	\N	2026-04-25 14:21:40.899557+00	2026-04-25 14:21:52.518769+00	7v8Gnu	0	t	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
657	8215202594	wwwwikk	доброе утро	USER	RU	0	0	f	f	\N	2026-04-25 14:31:47.64221+00	2026-04-25 14:31:50.887195+00	bdn3QA	0	t	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
658	6423801290	maytreya_boddhi	Valery Strahov	USER	RU	0	0	f	f	\N	2026-04-25 14:39:53.44681+00	2026-04-25 14:39:53.44681+00	Dp3e7a	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
659	1100663269	\N	oLeGaN	USER	RU	0	0	f	f	\N	2026-04-25 14:45:40.931554+00	2026-04-25 14:45:40.931554+00	qer49P	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
660	5769471083	xxxxxxxxxxxxxxxxxxxzzzzzzzzzzzzz	Фома	USER	RU	0	0	f	f	\N	2026-04-25 15:01:21.998667+00	2026-04-25 15:01:23.507188+00	qBUKY4	0	t	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
661	5133983597	Stubs1	Stubs1	USER	RU	0	0	f	f	\N	2026-04-25 15:47:22.136623+00	2026-04-25 15:47:23.659648+00	bdVlSX	0	t	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
662	5154699858	Ketrin1585	Кэтрин	USER	RU	0	0	f	t	82	2026-04-25 15:58:45.91179+00	2026-04-25 16:12:58.784371+00	BOcB7a	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
790	1210716406	Zl31l	عطور ليالي دبي	USER	RU	0	0	f	t	184	2026-05-03 07:40:38.711034+00	2026-06-15 16:44:35.586471+00	xYNjx2	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
646	6664864212	Vivi195924	Ирина Вишнева	USER	RU	0	0	f	t	\N	2026-04-25 11:15:49.754089+00	2026-06-23 19:40:24.235728+00	beDTND	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
628	1338122293	\N	НН	USER	RU	0	0	f	t	67	2026-04-25 07:07:13.573846+00	2026-06-24 03:34:49.280071+00	boQfaS	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
843	1029563012	taesiza	Iza	USER	RU	0	0	f	f	\N	2026-05-19 10:41:07.560656+00	2026-05-19 10:41:12.737254+00	X4BrZq	0	t	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
886	6964140786	suleym14	.	USER	RU	0	0	f	f	277	2026-06-18 10:26:52.3424+00	2026-06-18 10:26:57.466997+00	kHeGD3	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
2	465784461	innagoryaynova	Inna Goryaynova	USER	RU	0	0	f	f	230	2026-04-16 16:45:25.229022+00	2026-05-19 15:33:56.068459+00	3iwm5l	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
889	5312611499	\N	wang	USER	RU	0	0	f	t	\N	2026-06-20 09:23:37.592558+00	2026-06-20 09:23:43.009466+00	cIH9xW	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
848	7133535965	Begematy	P	USER	RU	0	0	f	f	240	2026-05-23 14:09:50.653328+00	2026-05-23 14:10:01.469688+00	CWQdq3	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
893	5979860592	x5mad	Denis Makeev	USER	RU	0	0	f	t	\N	2026-06-22 05:34:20.129324+00	2026-06-22 05:34:29.87161+00	jxJoUb	0	t	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
851	7922261988	\N	Barsi	USER	RU	0	0	f	t	244	2026-05-24 11:31:34.710402+00	2026-05-24 11:32:08.703995+00	boLJpN	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
854	6579846580	pon_x_x_pon	ᅠ	USER	RU	0	0	f	t	247	2026-05-26 14:59:55.408235+00	2026-05-26 15:00:48.36745+00	beURsJ	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
699	883048779	Inna_chiginskaya	Инна Чигинская	USER	RU	0	0	f	f	251	2026-04-27 09:38:18.105846+00	2026-05-30 10:34:46.39851+00	znXsMY	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
845	7400410400	DmitriyKorolchenko	Корольченко Дмитрий	USER	RU	0	0	f	f	255	2026-05-21 12:29:31.655986+00	2026-06-01 15:44:39.916358+00	xwxqRO	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
860	8751699166	\N	Иван	USER	RU	0	0	f	f	\N	2026-06-01 19:19:37.191024+00	2026-06-01 19:19:41.034414+00	bbjmQH	0	t	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
862	6764064054	ByFoxed	Егор	USER	RU	0	0	f	f	\N	2026-06-01 19:43:58.293663+00	2026-06-01 19:44:00.169719+00	bqIPF4	0	t	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
895	\N	\N	Ксения	USER	RU	0	0	f	f	\N	2026-06-23 06:10:56.534328+00	2026-06-23 06:11:58.87178+00	RWsLvh	0	f	t	ksuscharik@gmail.com	scrypt$16384$8$1$YpOw8R_OOiO0npOVsiZ8lw$C_TN362MFejadXDgfONhwRLbdDhsexCb4Oc4x2cj54sQuze0PCdLlOClL_hviZNEf1_gF1Prr0jkhAvpHknXLg	t	\N	\N	\N	email	\N	\N
815	547092424	\N	Витали1	USER	RU	0	0	f	t	\N	2026-05-05 04:06:46.328849+00	2026-06-23 19:43:22.357771+00	PrWH00	0	t	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
865	8161379502	Mellstroy_75	ツMellstroyツ	USER	RU	0	0	f	t	259	2026-06-02 13:35:27.235211+00	2026-06-02 13:43:25.311504+00	msNtTl	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
897	949373608	lemon4ik31	М	USER	RU	0	0	f	f	\N	2026-06-24 12:16:07.796348+00	2026-06-24 12:16:09.358767+00	onfgg2	0	t	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
898	\N	\N	Орм	USER	RU	0	0	f	f	\N	2026-06-24 17:13:47.129402+00	2026-06-24 17:13:47.129402+00	YENk4h	0	f	t	daniil.shanaurov@gmail.com	scrypt$16384$8$1$Hmu9j2Lnp07vcIZfAeyLbg$VlvLBPVueb7ffmWPzDNBxNIpNDNOC1f_bU8WFE0yLd9ZnAFdSrK8WWNP3IFpW5Tx9qMcTIIb6hfDeGx_8Y5mSw	f	\N	\N	\N	email	\N	\N
868	731175585	Tema_Proshin	Тёма Прошин	USER	RU	0	0	f	f	261	2026-06-03 11:01:37.359894+00	2026-06-03 11:01:42.293567+00	bo7fgM	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
899	7033970512	adoremariiie	Mariiie S	USER	RU	0	0	f	f	\N	2026-06-25 03:19:00.612793+00	2026-06-25 03:19:01.911089+00	0Dd93t	0	t	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
872	1437773848	Yusef9998	YuSef	USER	RU	0	0	f	t	\N	2026-06-07 08:11:43.374657+00	2026-06-07 21:06:36.079955+00	INAYge	0	t	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
876	5478660660	Edakly	Неизвестный	USER	RU	0	0	f	f	266	2026-06-09 03:49:00.269391+00	2026-06-09 03:49:08.024321+00	bmzPeC	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
880	6942038979	money_abuse	директор	USER	RU	0	0	f	f	\N	2026-06-09 14:37:39.081032+00	2026-06-09 14:37:40.87892+00	2hAwI2	0	t	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
903	1008271599	k_a_p_k_e14	Kapchёnka	USER	RU	0	0	f	f	281	2026-06-26 15:42:00.446171+00	2026-06-26 15:44:37.730632+00	ZXHgFC	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
882	5148232689	Mtdpt28	Димас	USER	RU	0	0	f	f	271	2026-06-12 08:55:13.236771+00	2026-06-12 08:55:17.598038+00	9LjGlb	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
894	\N	\N	Александр	USER	RU	0	0	f	f	282	2026-06-22 15:06:54.822096+00	2026-06-27 03:52:42.493355+00	uNXiCp	0	f	f	alex161rus2024@gmail.com	scrypt$16384$8$1$1e-e9O6tkg7AzXvRReWnOw$LPzAWcvGtSoabhz6B7WkIp1HfF32Qsq3gpEMoWRe8zHtxgkdmH2_tXRVWFN0hY1ZR96tfftpUf0fhCVCPEtqJA	t	\N	\N	\N	email	\N	\N
844	702329152	wqrxssfgha	Анастасия	USER	RU	0	0	f	f	\N	2026-05-19 13:19:03.217659+00	2026-05-19 13:19:05.459436+00	beEdYd	0	t	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
6	287221365	\N	Маргарита	USER	RU	0	0	f	f	232	2026-04-16 20:28:46.966365+00	2026-05-19 15:48:12.255809+00	qGBf56	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
904	8125768884	Lamiks67	.	USER	RU	0	0	f	f	\N	2026-06-26 16:38:40.466125+00	2026-06-26 16:38:42.59959+00	omt2Bl	0	t	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
846	8328912240	BOPK_KAZIK	Марк	USER	RU	0	0	f	t	239	2026-05-22 08:22:57.514848+00	2026-05-22 08:24:49.980538+00	pMudMm	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
586	1748186781	rivosbarberlab	RIVOS barberlab	USER	RU	0	0	f	f	241	2026-04-21 12:21:28.801878+00	2026-05-23 19:20:25.435751+00	beuD4I	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
857	1074834722	Majorsky_goose	Alexander Laktionov	USER	RU	0	0	f	f	253	2026-05-31 17:01:04.774669+00	2026-05-31 17:01:10.582222+00	bhzePD	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
861	8728809415	\N	Ахмед Бачаев	USER	RU	0	0	f	f	256	2026-06-01 19:34:27.022459+00	2026-06-01 19:34:32.960365+00	bg5clL	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
669	5814345235	Vainsez	tg 悖论 июнь	USER	RU	0	0	f	t	105	2026-04-26 00:02:29.426081+00	2026-06-02 17:06:45.658954+00	Qx8vxY	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
873	8412209882	YvfaHVLhBfeO	Имя Фамилия	USER	RU	0	0	f	f	\N	2026-06-07 15:34:01.222086+00	2026-06-07 15:34:01.222086+00	s4ap2d	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
5	523781269	Monika6317	Моника Махароблидзе	USER	RU	0	0	f	f	268	2026-04-16 20:24:58.085876+00	2026-06-11 16:32:59.193719+00	biy10R	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
883	8516050684	\N	Избранный	USER	RU	0	0	f	t	272	2026-06-14 14:54:21.112544+00	2026-06-14 14:58:21.537242+00	RWoiuI	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
887	887602580	fkwalletwin	FK Pay	USER	RU	0	0	f	f	\N	2026-06-19 09:27:00.594346+00	2026-06-19 09:27:43.825989+00	WkiMog	0	t	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
869	1950531935	Tom67aura	1950531935	USER	RU	0	0	f	t	262	2026-06-04 20:48:49.044107+00	2026-06-20 15:02:02.213407+00	4tAZoH	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
890	8204657005	\N	Викуся	USER	RU	0	0	f	t	\N	2026-06-20 20:11:21.423708+00	2026-06-20 20:11:53.562874+00	oHrLE0	0	t	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
760	689317410	massetrouzenn	Рафаэль	USER	RU	0	0	f	t	\N	2026-05-01 10:42:24.440571+00	2026-06-23 20:26:47.312707+00	be3ljf	0	t	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
677	6601748619	\N	Павел Волков	USER	RU	0	0	f	t	\N	2026-04-26 04:34:25.804998+00	2026-06-23 20:36:43.802613+00	o0okUf	0	t	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
852	5165656284	Dropovipartner	Dropovipartner	USER	RU	0	0	f	t	\N	2026-05-25 12:46:50.013211+00	2026-06-24 05:20:27.509671+00	N0pTWk	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
877	8649242665	Noryx_vpn	Noryx	USER	RU	0	0	f	f	280	2026-06-09 09:04:04.608616+00	2026-06-24 07:14:44.179578+00	kaL5Ip	0	t	f	\N	\N	f	sdffsdf@gmail.com	d3c9e130e478ededf70ae7e4d655fd991130b7a3c47b46db862b9127044430f7	2026-06-24 07:29:44.181252+00	telegram	\N	\N
793	415662533	My_event_horizon	My event Horizon	USER	RU	0	0	f	t	279	2026-05-03 10:34:25.673307+00	2026-06-24 12:52:31.752373+00	5RO15y	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
900	8065007749	OnlipaySupport	Андрей Onlipay	USER	RU	0	0	f	t	\N	2026-06-25 15:36:31.611555+00	2026-06-25 15:45:14.879775+00	KosJPg	0	t	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
888	7348059757	QWXDXD	Sasha Kirilov	USER	RU	0	0	f	t	278	2026-06-19 10:44:39.934352+00	2026-06-19 10:46:38.067705+00	JNFdjb	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
24	8694347942	VPN_Begemot	SUPPORT	DEV	RU	0	0	f	f	231	2026-04-18 19:22:11.40763+00	2026-05-19 15:37:09.63544+00	bbIebM	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
587	1869012621	K_sabina26	sabina	USER	RU	0	0	f	f	234	2026-04-21 14:34:07.571346+00	2026-05-19 19:20:26.971613+00	MpR65G	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
735	6756887941	Cocidlb	BARACUDA	USER	RU	0	0	f	t	144	2026-04-29 17:05:54.499818+00	2026-05-22 09:38:44.714841+00	WmSFvZ	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
891	7388690934	pupichun	Michigun	USER	RU	0	0	f	f	\N	2026-06-21 17:48:38.73645+00	2026-06-21 17:48:45.360926+00	XiZEyI	0	t	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
849	7151220198	nenadoze	автостоп лив	USER	RU	0	0	f	f	242	2026-05-24 08:24:51.583223+00	2026-05-24 08:24:56.61873+00	bpR3Cw	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
744	519693553	lotos555	alimbekov lotos	USER	RU	0	0	f	t	162	2026-04-30 11:52:03.130957+00	2026-05-26 02:09:10.717118+00	beLPkK	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
896	5770084734	dnx88	Pavel	USER	RU	0	0	f	f	\N	2026-06-23 13:06:28.927524+00	2026-06-23 13:10:14.225753+00	fhwJDb	0	t	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
7	1771582738	MaxxxVik	Максим Бут	USER	RU	0	0	f	f	235	2026-04-16 20:31:14.558197+00	2026-06-24 07:06:59.718766+00	N4BvsR	0	t	f	\N	\N	f	maxxxunvik@gmail.com	a76cd0f1e0e47ece29ab2c435dfef011dc418cf4a837b82ddf984bba68262b78	2026-06-24 07:21:59.720479+00	telegram	\N	\N
901	7869990085	nfkdkz	molder tvink	USER	RU	0	0	f	f	\N	2026-06-25 17:35:34.069908+00	2026-06-25 17:35:35.498428+00	PmdBcq	0	t	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
855	6342212781	Artem19912304	Artem	USER	RU	0	0	f	t	249	2026-05-28 17:09:23.124419+00	2026-05-28 17:14:23.427744+00	Loz3q7	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
905	6129838421	Kaspermode	Kasper	USER	RU	0	0	f	f	\N	2026-06-26 17:31:31.281597+00	2026-06-26 17:31:32.633747+00	xWKPHk	0	t	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
858	8694557811	\N	Vaharabey Goldov	USER	RU	0	0	f	t	254	2026-05-31 18:43:34.684735+00	2026-05-31 18:45:43.941998+00	Ud3JUf	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
863	6546168168	durovoriginalpro	Kaki Romance	USER	RU	0	0	f	f	257	2026-06-02 07:53:52.504051+00	2026-06-02 07:53:57.769183+00	OmLaXR	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
866	8355507541	Propavshiy287	propavshiy287	USER	RU	0	0	f	f	260	2026-06-02 18:52:11.114823+00	2026-06-02 18:52:14.934116+00	NbkEcX	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
870	8215599980	Khasanchic_09	حسن	USER	RU	0	0	f	f	263	2026-06-05 15:58:21.085586+00	2026-06-05 15:58:26.163435+00	gC3doD	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
874	8801320487	\N	Tioo	USER	RU	0	0	f	f	265	2026-06-07 22:54:32.708302+00	2026-06-07 22:55:59.342024+00	1TSt2L	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
878	5839065733	cvedc	ᄂꜰʀᴏᴇᴢユアン CVEDC	USER	RU	0	0	f	f	\N	2026-06-09 09:06:29.729107+00	2026-06-09 09:06:31.622757+00	fYDM4t	0	t	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
881	8096535121	Arman4ikGamingYT	Arman4ik	USER	RU	0	0	f	f	269	2026-06-11 19:31:46.801513+00	2026-06-11 19:32:12.899424+00	Rd39hz	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
884	2085723465	Titul543	добрейший	USER	RU	0	0	f	f	275	2026-06-17 08:36:58.493859+00	2026-06-17 08:37:02.056443+00	OSjRJ2	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
867	8997925575	\N	Малика Мусаева	USER	RU	0	0	f	t	\N	2026-06-03 06:22:37.208307+00	2026-06-24 17:23:28.118088+00	GE2AmB	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
1	473315171	Aleksandr_Goriainov	Александр	OWNER	RU	0	0	f	f	238	2026-04-16 09:59:38.043906+00	2026-06-25 08:24:27.118896+00	7Fskkq	0	f	f	alexdsndr161rus2015@gmail.com	scrypt$16384$8$1$nRTWup8OfiWUSzr3pBahKg$Yj-zDiKVwOkTCcH7heiB1wFbBlHBdUWqNz-CvTIEtlJ31l9W-WHG8OQiFVMFCQF29BRxZ06XUb5EOorsgjSUYw	t	\N	\N	\N	telegram	\N	\N
847	1154744011	arina_vault	Арина	USER	RU	0	0	f	f	\N	2026-05-22 15:56:06.537054+00	2026-05-22 15:56:08.995666+00	O8GUjP	0	t	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
902	7446882213	\N	KoIya	USER	RU	0	0	f	f	\N	2026-06-26 12:40:42.636388+00	2026-06-26 12:40:44.566883+00	IMdkfq	0	t	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
906	5734960254	\N	wong wu	USER	RU	0	0	f	t	\N	2026-06-28 08:08:52.211538+00	2026-06-28 08:08:57.581326+00	GhbnIH	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
850	5689271324	Prokuror64	PROKUROR	USER	RU	0	0	f	f	243	2026-05-24 09:22:46.548656+00	2026-05-24 09:23:29.799409+00	5CcALK	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
853	1658016034	gusein_7	...18	USER	RU	0	0	f	f	246	2026-05-26 08:35:10.937374+00	2026-05-26 08:35:26.395082+00	bgv2LP	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
856	7981061131	skkypeee	машкаа	USER	RU	0	0	f	f	250	2026-05-29 22:40:44.903778+00	2026-05-29 22:40:50.628465+00	LKGse6	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
859	8061051155	Zetyrka716	Evgen Samurai	USER	RU	0	0	f	t	\N	2026-06-01 05:58:02.729897+00	2026-06-01 05:58:11.60628+00	CnBxMy	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
864	8572141190	\N	Я	USER	RU	0	0	f	f	258	2026-06-02 07:57:34.658581+00	2026-06-02 07:57:37.14763+00	bj52vh	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
871	7974909704	\N	Антон Чернов	USER	RU	0	0	f	f	264	2026-06-07 07:55:20.620124+00	2026-06-07 07:55:29.797356+00	OOhESY	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
875	895474770	\N	Терра	USER	RU	0	0	f	f	\N	2026-06-08 17:13:04.493287+00	2026-06-08 17:13:11.026232+00	X0GOig	0	t	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
879	286183586	atadzh	Комрон	USER	RU	0	0	f	f	267	2026-06-09 10:33:58.782947+00	2026-06-09 10:34:03.845962+00	tvhQY4	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
885	6152569431	Dahed72	نيتبمبوتخذ	USER	RU	0	0	f	f	276	2026-06-17 19:20:38.456852+00	2026-06-17 19:20:44.878386+00	ZkdtIg	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
892	1178178774	Zhenyapikmi	Женя	USER	RU	0	0	f	f	\N	2026-06-21 19:19:00.639842+00	2026-06-21 19:19:02.047738+00	GT71t0	0	t	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
782	5128813849	Jester_q1	jester	USER	RU	0	0	f	t	174	2026-05-02 11:30:10.671138+00	2026-06-23 19:26:13.842018+00	7Ois1b	0	t	f	\N	\N	f	\N	\N	\N	telegram	\N	\N
765	752733455	AntonFFly	Anton Fomin	USER	RU	0	0	f	t	\N	2026-05-01 15:31:10.867094+00	2026-06-23 19:29:46.184426+00	bnrjHH	0	f	t	\N	\N	f	\N	\N	\N	telegram	\N	\N
\.


--
-- Name: ad_links_id_seq; Type: SEQUENCE SET; Schema: public; Owner: remnashop
--

SELECT pg_catalog.setval('public.ad_links_id_seq', 1, false);


--
-- Name: admin_audit_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: remnashop
--

SELECT pg_catalog.setval('public.admin_audit_log_id_seq', 2, true);


--
-- Name: broadcast_messages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: remnashop
--

SELECT pg_catalog.setval('public.broadcast_messages_id_seq', 934, true);


--
-- Name: broadcasts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: remnashop
--

SELECT pg_catalog.setval('public.broadcasts_id_seq', 6, true);


--
-- Name: payment_gateways_id_seq; Type: SEQUENCE SET; Schema: public; Owner: remnashop
--

SELECT pg_catalog.setval('public.payment_gateways_id_seq', 14, true);


--
-- Name: plan_durations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: remnashop
--

SELECT pg_catalog.setval('public.plan_durations_id_seq', 491, true);


--
-- Name: plan_prices_id_seq; Type: SEQUENCE SET; Schema: public; Owner: remnashop
--

SELECT pg_catalog.setval('public.plan_prices_id_seq', 1473, true);


--
-- Name: plans_id_seq; Type: SEQUENCE SET; Schema: public; Owner: remnashop
--

SELECT pg_catalog.setval('public.plans_id_seq', 19, true);


--
-- Name: promocode_activations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: remnashop
--

SELECT pg_catalog.setval('public.promocode_activations_id_seq', 1, false);


--
-- Name: promocodes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: remnashop
--

SELECT pg_catalog.setval('public.promocodes_id_seq', 1, false);


--
-- Name: referral_rewards_id_seq; Type: SEQUENCE SET; Schema: public; Owner: remnashop
--

SELECT pg_catalog.setval('public.referral_rewards_id_seq', 1, false);


--
-- Name: referrals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: remnashop
--

SELECT pg_catalog.setval('public.referrals_id_seq', 4, true);


--
-- Name: settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: remnashop
--

SELECT pg_catalog.setval('public.settings_id_seq', 1, true);


--
-- Name: subscriptions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: remnashop
--

SELECT pg_catalog.setval('public.subscriptions_id_seq', 282, true);


--
-- Name: support_messages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: remnashop
--

SELECT pg_catalog.setval('public.support_messages_id_seq', 2, true);


--
-- Name: support_tickets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: remnashop
--

SELECT pg_catalog.setval('public.support_tickets_id_seq', 1, true);


--
-- Name: transactions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: remnashop
--

SELECT pg_catalog.setval('public.transactions_id_seq', 132, true);


--
-- Name: user_oauth_providers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: remnashop
--

SELECT pg_catalog.setval('public.user_oauth_providers_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: remnashop
--

SELECT pg_catalog.setval('public.users_id_seq', 906, true);


--
-- Name: ad_links ad_links_pkey; Type: CONSTRAINT; Schema: public; Owner: remnashop
--

ALTER TABLE ONLY public.ad_links
    ADD CONSTRAINT ad_links_pkey PRIMARY KEY (id);


--
-- Name: admin_audit_log admin_audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: remnashop
--

ALTER TABLE ONLY public.admin_audit_log
    ADD CONSTRAINT admin_audit_log_pkey PRIMARY KEY (id);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: remnashop
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: broadcast_messages broadcast_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: remnashop
--

ALTER TABLE ONLY public.broadcast_messages
    ADD CONSTRAINT broadcast_messages_pkey PRIMARY KEY (id);


--
-- Name: broadcasts broadcasts_pkey; Type: CONSTRAINT; Schema: public; Owner: remnashop
--

ALTER TABLE ONLY public.broadcasts
    ADD CONSTRAINT broadcasts_pkey PRIMARY KEY (id);


--
-- Name: broadcasts broadcasts_task_id_key; Type: CONSTRAINT; Schema: public; Owner: remnashop
--

ALTER TABLE ONLY public.broadcasts
    ADD CONSTRAINT broadcasts_task_id_key UNIQUE (task_id);


--
-- Name: payment_gateways payment_gateways_pkey; Type: CONSTRAINT; Schema: public; Owner: remnashop
--

ALTER TABLE ONLY public.payment_gateways
    ADD CONSTRAINT payment_gateways_pkey PRIMARY KEY (id);


--
-- Name: payment_gateways payment_gateways_type_key; Type: CONSTRAINT; Schema: public; Owner: remnashop
--

ALTER TABLE ONLY public.payment_gateways
    ADD CONSTRAINT payment_gateways_type_key UNIQUE (type);


--
-- Name: plan_durations plan_durations_pkey; Type: CONSTRAINT; Schema: public; Owner: remnashop
--

ALTER TABLE ONLY public.plan_durations
    ADD CONSTRAINT plan_durations_pkey PRIMARY KEY (id);


--
-- Name: plan_prices plan_prices_pkey; Type: CONSTRAINT; Schema: public; Owner: remnashop
--

ALTER TABLE ONLY public.plan_prices
    ADD CONSTRAINT plan_prices_pkey PRIMARY KEY (id);


--
-- Name: plans plans_pkey; Type: CONSTRAINT; Schema: public; Owner: remnashop
--

ALTER TABLE ONLY public.plans
    ADD CONSTRAINT plans_pkey PRIMARY KEY (id);


--
-- Name: promocode_activations promocode_activations_pkey; Type: CONSTRAINT; Schema: public; Owner: remnashop
--

ALTER TABLE ONLY public.promocode_activations
    ADD CONSTRAINT promocode_activations_pkey PRIMARY KEY (id);


--
-- Name: promocodes promocodes_code_key; Type: CONSTRAINT; Schema: public; Owner: remnashop
--

ALTER TABLE ONLY public.promocodes
    ADD CONSTRAINT promocodes_code_key UNIQUE (code);


--
-- Name: promocodes promocodes_pkey; Type: CONSTRAINT; Schema: public; Owner: remnashop
--

ALTER TABLE ONLY public.promocodes
    ADD CONSTRAINT promocodes_pkey PRIMARY KEY (id);


--
-- Name: referral_rewards referral_rewards_pkey; Type: CONSTRAINT; Schema: public; Owner: remnashop
--

ALTER TABLE ONLY public.referral_rewards
    ADD CONSTRAINT referral_rewards_pkey PRIMARY KEY (id);


--
-- Name: referrals referrals_pkey; Type: CONSTRAINT; Schema: public; Owner: remnashop
--

ALTER TABLE ONLY public.referrals
    ADD CONSTRAINT referrals_pkey PRIMARY KEY (id);


--
-- Name: settings settings_pkey; Type: CONSTRAINT; Schema: public; Owner: remnashop
--

ALTER TABLE ONLY public.settings
    ADD CONSTRAINT settings_pkey PRIMARY KEY (id);


--
-- Name: subscriptions subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: remnashop
--

ALTER TABLE ONLY public.subscriptions
    ADD CONSTRAINT subscriptions_pkey PRIMARY KEY (id);


--
-- Name: support_messages support_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: remnashop
--

ALTER TABLE ONLY public.support_messages
    ADD CONSTRAINT support_messages_pkey PRIMARY KEY (id);


--
-- Name: support_tickets support_tickets_pkey; Type: CONSTRAINT; Schema: public; Owner: remnashop
--

ALTER TABLE ONLY public.support_tickets
    ADD CONSTRAINT support_tickets_pkey PRIMARY KEY (id);


--
-- Name: transactions transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: remnashop
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_pkey PRIMARY KEY (id);


--
-- Name: ad_links uq_ad_links_code; Type: CONSTRAINT; Schema: public; Owner: remnashop
--

ALTER TABLE ONLY public.ad_links
    ADD CONSTRAINT uq_ad_links_code UNIQUE (code);


--
-- Name: user_oauth_providers uq_user_oauth_providers_provider_id; Type: CONSTRAINT; Schema: public; Owner: remnashop
--

ALTER TABLE ONLY public.user_oauth_providers
    ADD CONSTRAINT uq_user_oauth_providers_provider_id UNIQUE (provider, provider_id);


--
-- Name: user_oauth_providers uq_user_oauth_providers_user_provider; Type: CONSTRAINT; Schema: public; Owner: remnashop
--

ALTER TABLE ONLY public.user_oauth_providers
    ADD CONSTRAINT uq_user_oauth_providers_user_provider UNIQUE (user_id, provider);


--
-- Name: user_oauth_providers user_oauth_providers_pkey; Type: CONSTRAINT; Schema: public; Owner: remnashop
--

ALTER TABLE ONLY public.user_oauth_providers
    ADD CONSTRAINT user_oauth_providers_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: remnashop
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: ix_ad_links_code; Type: INDEX; Schema: public; Owner: remnashop
--

CREATE INDEX ix_ad_links_code ON public.ad_links USING btree (code);


--
-- Name: ix_ad_links_name; Type: INDEX; Schema: public; Owner: remnashop
--

CREATE INDEX ix_ad_links_name ON public.ad_links USING btree (name);


--
-- Name: ix_admin_audit_created; Type: INDEX; Schema: public; Owner: remnashop
--

CREATE INDEX ix_admin_audit_created ON public.admin_audit_log USING btree (created_at DESC);


--
-- Name: ix_broadcast_messages_broadcast_id; Type: INDEX; Schema: public; Owner: remnashop
--

CREATE INDEX ix_broadcast_messages_broadcast_id ON public.broadcast_messages USING btree (broadcast_id);


--
-- Name: ix_broadcast_messages_status; Type: INDEX; Schema: public; Owner: remnashop
--

CREATE INDEX ix_broadcast_messages_status ON public.broadcast_messages USING btree (status);


--
-- Name: ix_broadcast_messages_user_id; Type: INDEX; Schema: public; Owner: remnashop
--

CREATE INDEX ix_broadcast_messages_user_id ON public.broadcast_messages USING btree (user_id);


--
-- Name: ix_broadcasts_status; Type: INDEX; Schema: public; Owner: remnashop
--

CREATE INDEX ix_broadcasts_status ON public.broadcasts USING btree (status);


--
-- Name: ix_payment_gateways_order_index; Type: INDEX; Schema: public; Owner: remnashop
--

CREATE INDEX ix_payment_gateways_order_index ON public.payment_gateways USING btree (order_index);


--
-- Name: ix_plan_durations_order_index; Type: INDEX; Schema: public; Owner: remnashop
--

CREATE INDEX ix_plan_durations_order_index ON public.plan_durations USING btree (order_index);


--
-- Name: ix_plan_durations_plan_id; Type: INDEX; Schema: public; Owner: remnashop
--

CREATE INDEX ix_plan_durations_plan_id ON public.plan_durations USING btree (plan_id);


--
-- Name: ix_plan_prices_plan_duration_id; Type: INDEX; Schema: public; Owner: remnashop
--

CREATE INDEX ix_plan_prices_plan_duration_id ON public.plan_prices USING btree (plan_duration_id);


--
-- Name: ix_plans_name; Type: INDEX; Schema: public; Owner: remnashop
--

CREATE UNIQUE INDEX ix_plans_name ON public.plans USING btree (name);


--
-- Name: ix_plans_order_index; Type: INDEX; Schema: public; Owner: remnashop
--

CREATE INDEX ix_plans_order_index ON public.plans USING btree (order_index);


--
-- Name: ix_plans_public_code; Type: INDEX; Schema: public; Owner: remnashop
--

CREATE UNIQUE INDEX ix_plans_public_code ON public.plans USING btree (public_code);


--
-- Name: ix_promocode_activations_promocode_id; Type: INDEX; Schema: public; Owner: remnashop
--

CREATE INDEX ix_promocode_activations_promocode_id ON public.promocode_activations USING btree (promocode_id);


--
-- Name: ix_promocode_activations_user_id; Type: INDEX; Schema: public; Owner: remnashop
--

CREATE INDEX ix_promocode_activations_user_id ON public.promocode_activations USING btree (user_id);


--
-- Name: ix_promocodes_code; Type: INDEX; Schema: public; Owner: remnashop
--

CREATE UNIQUE INDEX ix_promocodes_code ON public.promocodes USING btree (code);


--
-- Name: ix_referral_rewards_referral_id; Type: INDEX; Schema: public; Owner: remnashop
--

CREATE INDEX ix_referral_rewards_referral_id ON public.referral_rewards USING btree (referral_id);


--
-- Name: ix_referral_rewards_user_id; Type: INDEX; Schema: public; Owner: remnashop
--

CREATE INDEX ix_referral_rewards_user_id ON public.referral_rewards USING btree (user_id);


--
-- Name: ix_referrals_referred_id; Type: INDEX; Schema: public; Owner: remnashop
--

CREATE UNIQUE INDEX ix_referrals_referred_id ON public.referrals USING btree (referred_id);


--
-- Name: ix_referrals_referrer_id; Type: INDEX; Schema: public; Owner: remnashop
--

CREATE INDEX ix_referrals_referrer_id ON public.referrals USING btree (referrer_id);


--
-- Name: ix_subscriptions_expire_at; Type: INDEX; Schema: public; Owner: remnashop
--

CREATE INDEX ix_subscriptions_expire_at ON public.subscriptions USING btree (expire_at);


--
-- Name: ix_subscriptions_status; Type: INDEX; Schema: public; Owner: remnashop
--

CREATE INDEX ix_subscriptions_status ON public.subscriptions USING btree (status);


--
-- Name: ix_subscriptions_user_id; Type: INDEX; Schema: public; Owner: remnashop
--

CREATE INDEX ix_subscriptions_user_id ON public.subscriptions USING btree (user_id);


--
-- Name: ix_subscriptions_user_remna_id; Type: INDEX; Schema: public; Owner: remnashop
--

CREATE INDEX ix_subscriptions_user_remna_id ON public.subscriptions USING btree (user_remna_id);


--
-- Name: ix_support_messages_ticket_id; Type: INDEX; Schema: public; Owner: remnashop
--

CREATE INDEX ix_support_messages_ticket_id ON public.support_messages USING btree (ticket_id);


--
-- Name: ix_support_tickets_user_id; Type: INDEX; Schema: public; Owner: remnashop
--

CREATE INDEX ix_support_tickets_user_id ON public.support_tickets USING btree (user_id);


--
-- Name: ix_transactions_payment_id; Type: INDEX; Schema: public; Owner: remnashop
--

CREATE UNIQUE INDEX ix_transactions_payment_id ON public.transactions USING btree (payment_id);


--
-- Name: ix_transactions_status; Type: INDEX; Schema: public; Owner: remnashop
--

CREATE INDEX ix_transactions_status ON public.transactions USING btree (status);


--
-- Name: ix_transactions_user_id; Type: INDEX; Schema: public; Owner: remnashop
--

CREATE INDEX ix_transactions_user_id ON public.transactions USING btree (user_id);


--
-- Name: ix_user_oauth_providers_user_id; Type: INDEX; Schema: public; Owner: remnashop
--

CREATE INDEX ix_user_oauth_providers_user_id ON public.user_oauth_providers USING btree (user_id);


--
-- Name: ix_users_ad_link_id; Type: INDEX; Schema: public; Owner: remnashop
--

CREATE INDEX ix_users_ad_link_id ON public.users USING btree (ad_link_id);


--
-- Name: ix_users_current_subscription_id; Type: INDEX; Schema: public; Owner: remnashop
--

CREATE INDEX ix_users_current_subscription_id ON public.users USING btree (current_subscription_id);


--
-- Name: ix_users_email; Type: INDEX; Schema: public; Owner: remnashop
--

CREATE UNIQUE INDEX ix_users_email ON public.users USING btree (email);


--
-- Name: ix_users_referral_code; Type: INDEX; Schema: public; Owner: remnashop
--

CREATE UNIQUE INDEX ix_users_referral_code ON public.users USING btree (referral_code);


--
-- Name: ix_users_role; Type: INDEX; Schema: public; Owner: remnashop
--

CREATE INDEX ix_users_role ON public.users USING btree (role);


--
-- Name: ix_users_telegram_id; Type: INDEX; Schema: public; Owner: remnashop
--

CREATE UNIQUE INDEX ix_users_telegram_id ON public.users USING btree (telegram_id);


--
-- Name: ix_users_username; Type: INDEX; Schema: public; Owner: remnashop
--

CREATE INDEX ix_users_username ON public.users USING btree (username);


--
-- Name: broadcast_messages broadcast_messages_broadcast_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: remnashop
--

ALTER TABLE ONLY public.broadcast_messages
    ADD CONSTRAINT broadcast_messages_broadcast_id_fkey FOREIGN KEY (broadcast_id) REFERENCES public.broadcasts(id) ON DELETE CASCADE;


--
-- Name: broadcast_messages broadcast_messages_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: remnashop
--

ALTER TABLE ONLY public.broadcast_messages
    ADD CONSTRAINT broadcast_messages_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: users fk_users_ad_link_id; Type: FK CONSTRAINT; Schema: public; Owner: remnashop
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT fk_users_ad_link_id FOREIGN KEY (ad_link_id) REFERENCES public.ad_links(id) ON DELETE SET NULL;


--
-- Name: users fk_users_current_subscription_id; Type: FK CONSTRAINT; Schema: public; Owner: remnashop
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT fk_users_current_subscription_id FOREIGN KEY (current_subscription_id) REFERENCES public.subscriptions(id) ON DELETE SET NULL;


--
-- Name: plan_durations plan_durations_plan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: remnashop
--

ALTER TABLE ONLY public.plan_durations
    ADD CONSTRAINT plan_durations_plan_id_fkey FOREIGN KEY (plan_id) REFERENCES public.plans(id) ON DELETE CASCADE;


--
-- Name: plan_prices plan_prices_plan_duration_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: remnashop
--

ALTER TABLE ONLY public.plan_prices
    ADD CONSTRAINT plan_prices_plan_duration_id_fkey FOREIGN KEY (plan_duration_id) REFERENCES public.plan_durations(id) ON DELETE CASCADE;


--
-- Name: promocode_activations promocode_activations_promocode_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: remnashop
--

ALTER TABLE ONLY public.promocode_activations
    ADD CONSTRAINT promocode_activations_promocode_id_fkey FOREIGN KEY (promocode_id) REFERENCES public.promocodes(id) ON DELETE CASCADE;


--
-- Name: promocode_activations promocode_activations_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: remnashop
--

ALTER TABLE ONLY public.promocode_activations
    ADD CONSTRAINT promocode_activations_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: referral_rewards referral_rewards_referral_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: remnashop
--

ALTER TABLE ONLY public.referral_rewards
    ADD CONSTRAINT referral_rewards_referral_id_fkey FOREIGN KEY (referral_id) REFERENCES public.referrals(id) ON DELETE CASCADE;


--
-- Name: referral_rewards referral_rewards_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: remnashop
--

ALTER TABLE ONLY public.referral_rewards
    ADD CONSTRAINT referral_rewards_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: referrals referrals_referred_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: remnashop
--

ALTER TABLE ONLY public.referrals
    ADD CONSTRAINT referrals_referred_id_fkey FOREIGN KEY (referred_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: referrals referrals_referrer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: remnashop
--

ALTER TABLE ONLY public.referrals
    ADD CONSTRAINT referrals_referrer_id_fkey FOREIGN KEY (referrer_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: subscriptions subscriptions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: remnashop
--

ALTER TABLE ONLY public.subscriptions
    ADD CONSTRAINT subscriptions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: support_messages support_messages_ticket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: remnashop
--

ALTER TABLE ONLY public.support_messages
    ADD CONSTRAINT support_messages_ticket_id_fkey FOREIGN KEY (ticket_id) REFERENCES public.support_tickets(id) ON DELETE CASCADE;


--
-- Name: support_tickets support_tickets_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: remnashop
--

ALTER TABLE ONLY public.support_tickets
    ADD CONSTRAINT support_tickets_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: transactions transactions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: remnashop
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_oauth_providers user_oauth_providers_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: remnashop
--

ALTER TABLE ONLY public.user_oauth_providers
    ADD CONSTRAINT user_oauth_providers_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: remnashop
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

\unrestrict GHr4FT6Q3Ov0iGZlUVgjFynHeFkLdjbP2mRXv6VdUCCxwilZ7P2Mqn2TyHqgLrH

